# SSPACE V6 — audit statique et correctifs

- IDs HTML dupliqués : 0.
- Références directes à des IDs absents : aucune (le conteneur `liveBanners` est créé à la demande).
- JavaScript inline : syntaxe vérifiée avec `node --check`.
- Service worker : cache incrémenté à v18; promo ajoutée au pré-cache pour que l'écran promo fonctionne aussi hors connexion après installation.
- Écran promo : durée ajustée à 13,5 s pour correspondre à sa boucle; délai de secours de 4,5 s si l'iframe ne charge pas, puis logo/fallback affiché au lieu d'un écran vide.
- ZIP : vérification d'intégrité effectuée.

## Limites
Audit statique seulement. Les connexions Supabase, permissions microphone/caméra, appels WebRTC, tests multi-comptes et déploiement Netlify n'ont pas été exécutés sur un appareil ni contre le backend réel. La clé GIPHY est visible côté client : vérifier quotas/restrictions; ne pas y placer de secrets. La sécurité dépend des politiques RLS et des fonctions serveur.
