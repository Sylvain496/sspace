-- SSPACE profile visibility/activity scaffold (review and apply only after schema audit)
-- Adds explicit visibility controls for public profile attributes.
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS age_visibility text NOT NULL DEFAULT 'private' CHECK (age_visibility IN ('private','friends','public'));
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS region_visibility text NOT NULL DEFAULT 'private' CHECK (region_visibility IN ('private','friends','public'));
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS relationship_status text;
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS relationship_visibility text NOT NULL DEFAULT 'private' CHECK (relationship_visibility IN ('private','friends','public'));
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS favorite_topics text;
ALTER TABLE public.profile_private_details ADD COLUMN IF NOT EXISTS favorite_topics_visibility text NOT NULL DEFAULT 'private' CHECK (favorite_topics_visibility IN ('private','friends','public'));
-- Existing RLS policies on this private-details table are intentionally preserved.
-- Do NOT expose this table publicly via broad SELECT policies. Build a permission-aware RPC/view before public profile rendering.
