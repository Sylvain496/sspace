-- SSPACE Live Direct : sessions visibles dans le fil et sécurisées par RLS.
create table if not exists public.sspace_live_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null default 'En direct sur SSPACE' check (char_length(title) between 1 and 100),
  status text not null default 'live' check (status in ('live','ended')),
  created_at timestamptz not null default now(),
  ended_at timestamptz
);
create index if not exists sspace_live_sessions_status_created_idx
  on public.sspace_live_sessions(status, created_at desc);
alter table public.sspace_live_sessions enable row level security;
revoke all on table public.sspace_live_sessions from anon, public;
grant select, insert, update on table public.sspace_live_sessions to authenticated;
drop policy if exists "Members can view live sessions" on public.sspace_live_sessions;
create policy "Members can view live sessions"
  on public.sspace_live_sessions for select to authenticated using (true);
drop policy if exists "Members can start their own live sessions" on public.sspace_live_sessions;
create policy "Members can start their own live sessions"
  on public.sspace_live_sessions for insert to authenticated
  with check ((select auth.uid()) = user_id and status = 'live');
drop policy if exists "Hosts can end their own live sessions" on public.sspace_live_sessions;
create policy "Hosts can end their own live sessions"
  on public.sspace_live_sessions for update to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);
do $$
begin
  alter publication supabase_realtime add table public.sspace_live_sessions;
exception when duplicate_object then null;
when undefined_object then
  raise notice 'Publication supabase_realtime absente : activer Realtime pour sspace_live_sessions dans Supabase.';
end $$;
