# SSPACE V6 + Bowling 3D

Le contenu de SSPACE-V6-NETLIFY-DEPLOY est conservé comme base. Le module Bowling 3D et la récupération de mot de passe du paquet SSPACE-Bowling-Login-Update ont été intégrés.

## Déploiement Netlify
Publier le contenu de ce dossier à la racine du site Netlify (ou pousser ces fichiers à la racine du dépôt connecté à Netlify). Le fichier `netlify.toml` publie `.`.

## À vérifier après publication
- Ouvrir `Mini-jeux` puis lancer le Bowling 3D en mode solo.
- Tester le lancer, la direction, la puissance et l'effet.
- Depuis une conversation, ouvrir `···` puis « Commencer un jeu multijoueur ».
- Tester la création et la jonction d'un salon avec deux comptes.
- Tester « Mot de passe oublié »; dans Supabase, ajouter le domaine Netlify à Authentication > URL Configuration > Redirect URLs.
- Recharger le site après fermeture complète du navigateur si l'ancien cache apparaît.

Le multijoueur utilise Supabase Realtime et reste un prototype non certifié anti-triche. Le rendu 3D nécessite WebGL et les modules Three.js/cannon-es chargés depuis jsDelivr.
