# SSPACE V6 — profil, photos et activité

- Icône d'application SSPACE générée localement et remplacée dans les tailles 192, 512, maskable et Apple touch.
- Style: retrait des bordures/cadres des avatars; album sans bordure externe.
- Demande UX: ouvrir avatars, photos de publications, photos d'album et médias de chat en vue agrandie (à intégrer/valider dans le JS).
- Profil: âge, région, statut relationnel, sujets favoris et musique avec contrôles de visibilité distincts (private/friends/public).
- Albums: description et date affichable par photo.
- Activité publique opt-in: événements de profil/commentaires et recommandations contextuelles; les changements d'informations privées ne doivent jamais publier automatiquement sans consentement.

## Important
Cette archive contient les ajustements visuels et un scaffold SQL de visibilité. Le code d'ouverture média, le formulaire profil/albums, le flux d'activité et le moteur de suggestions nécessitent encore une intégration JavaScript/UI et des tests avec comptes réels. Le scaffold SQL doit être vérifié et appliqué manuellement après audit des politiques RLS.
