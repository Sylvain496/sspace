# SSPACE Live Direct — installation

## Ce qui est ajouté
- Bouton « Démarrer un LIVE » dans le fil d’actualité.
- Capture caméra + micro avec aperçu avant diffusion.
- Carte de direct dans le fil avec badge rouge LIVE.
- Lecture du direct et arrêt/quitter côté spectateur.
- Commandes micro et caméra côté diffuseur.
- Signalisation WebRTC via Supabase Realtime.

## Étape obligatoire dans Supabase
1. Ouvrir le projet Supabase associé à SSPACE.
2. Aller dans SQL Editor.
3. Ouvrir et exécuter `supabase/migrations/20261120190000_sspace_live_direct.sql`.
4. Vérifier que Realtime est activé pour `public.sspace_live_sessions` (la migration tente de l’ajouter à la publication `supabase_realtime`).

## Déploiement Netlify
Déployer le contenu du ZIP à la racine du site, en conservant les dossiers `supabase/`, `icons/` et `assets/`. Le cache du Service Worker est passé à `sspace-static-v20`.

## Conditions et limites techniques
- L’accès caméra/micro exige HTTPS et l’autorisation du navigateur. Netlify fournit HTTPS.
- Le transport vidéo utilise WebRTC pair-à-pair et les serveurs STUN publics Google. Selon les réseaux mobiles, routeurs ou pare-feu, certains spectateurs peuvent ne pas réussir à se connecter; un serveur TURN dédié serait alors nécessaire.
- Le diffuseur envoie un flux direct à chaque spectateur (topologie mesh); pour un grand auditoire, il faudra un serveur média SFU (ex. LiveKit/mediasoup) afin d’éviter une forte consommation de bande passante.
- La migration SQL est obligatoire : sans elle, le bouton affichera une erreur expliquant que Live n’est pas activé.
