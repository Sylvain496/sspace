# SSPACE V6 — Correctif accès au chat privé
- Mobile: une discussion ouverte masque la liste et priorise la fenêtre de chat.
- Bouton « ← Conversations » pour revenir à la liste.
- Retour désactive le plein écran.
- Cache PWA augmenté à v17.

## Validation
- Syntaxe JS inline via node --check: PASS.
- Aucun test Supabase réel, appareil physique ou déploiement effectué.
