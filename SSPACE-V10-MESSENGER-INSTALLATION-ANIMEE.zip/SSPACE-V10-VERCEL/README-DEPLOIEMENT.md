# SSPACE V10 — Vercel (Social + Messenger + Jeux + WebRTC)

## Architecture livrée dans ce paquet

- Réseau social SSPACE : `/`
- SSPACE Messenger : `/messenger/`
- Espace de jeux : `/jeux-espace/`
- Signalisation d'appels : Supabase Realtime via `public.call_signals`
- Médias audio/vidéo : WebRTC pair-à-pair (`getUserMedia`, `RTCPeerConnection`, SDP et ICE)

## Configuration Vercel

- Root Directory : racine du dépôt
- Install Command : `npm install`
- Build Command : `npm run build`
- Output Directory : `dist`

Le script `scripts/copy-site.mjs` copie d'abord le site social et les jeux dans `dist/`. Vite construit ensuite Messenger dans `dist/messenger/` sans effacer le site déjà copié. La configuration Vite fixe explicitement sa racine au dossier `messenger/` et sa base publique à `/messenger/`.

## WebRTC

Le code conserve le système d'appels déjà présent dans `site/index.html`. Messenger possède aussi une interface d'appel audio/vidéo et utilise la même table `call_signals`.

Pour que deux personnes puissent se joindre :

1. Les deux utilisateurs doivent avoir des comptes SSPACE distincts et être amis (demande acceptée).
2. La migration `site/supabase/migrations/20261120130000_private_video_audio_call_signals.sql` doit être appliquée dans le projet Supabase SIKX utilisé par SSPACE.
3. La table `call_signals` doit être activée dans la publication `supabase_realtime`.
4. Les deux appareils doivent utiliser HTTPS et accorder les permissions micro/caméra.
5. Configurer un serveur TURN avec des identifiants éphémères est fortement recommandé pour les réseaux mobiles, CGNAT, Wi-Fi d'entreprise et NAT stricts. STUN seul ne garantit pas une connexion entre tous les réseaux.

Variables Vercel optionnelles pour le relais TURN de Messenger :

- `VITE_TURN_URLS`
- `VITE_TURN_USERNAME`
- `VITE_TURN_CREDENTIAL`

Les valeurs `VITE_*` sont incorporées au code client. N'y place jamais de secret permanent, clé `service_role` ou mot de passe d'administration. Utilise des identifiants TURN temporaires/renouvelables.

## Vérification et limites de cette archive

- Intégrité ZIP : vérifiée.
- Fichiers de configuration JSON : vérifiés.
- Correction de la racine Vite Messenger : effectuée (la précédente configuration lançait Vite depuis la racine du dépôt, où il n'y a pas de `index.html`).
- Appels entrants : le gestionnaire de signaux Messenger ne jette plus les appels lorsque l'onglet est en arrière-plan.
- Build TypeScript/Vite : non exécuté ici, car l'installation des dépendances n'a pas abouti dans l'environnement de préparation.
- Appel audio réel entre deux appareils : non testé.
- Appel vidéo réel entre deux appareils : non testé.
- Déploiement Vercel : non effectué.
- Publication GitHub : non effectuée.

Ne promeus pas cette version en production avant un déploiement Preview réussi et un essai avec deux comptes SSPACE sur deux appareils distincts. Si l'appel échoue malgré la signalisation, vérifie d'abord la migration/Realtime Supabase, les permissions HTTPS, puis TURN.
