import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { MessageCircle, Search, Phone, Video, Plus, Send, Paperclip, Smile, LogOut, ShieldCheck, ArrowLeft, CheckCheck, ExternalLink, Bell, BellRing, Mic, MicOff, VideoOff, PhoneOff, Minimize2, Maximize2, Download, Smartphone } from 'lucide-react';

type Profile = { id: string; username: string | null; display_name: string | null; avatar_url: string | null; last_seen_at?: string | null; show_online?: boolean | null };
type Conversation = { id: string; user_one: string; user_two: string; updated_at: string; other?: Profile; last_message?: Message | null; unread_count?: number };
type Message = { id: string; conversation_id: string; sender_id: string; body: string; created_at: string; read_at: string | null; message_type?: string; media_path?: string | null; link_url?: string | null };
type CallKind = 'audio' | 'video';
type CallState = {
  callId: string; peerId: string; peerName: string; peerAvatar: string; mediaType: CallKind;
  role: 'caller' | 'callee'; phase: 'ringing-in' | 'ringing-out' | 'connecting' | 'active';
  pc: RTCPeerConnection | null; localStream: MediaStream | null; remoteStream: MediaStream | null;
  pendingIce: RTCIceCandidateInit[]; startedAt: number | null; muted: boolean; cameraEnabled: boolean; minimized: boolean;
};

const STUN_SERVERS: RTCIceServer[] = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }
];
const turnUrls = (import.meta.env.VITE_TURN_URLS as string | undefined)?.split(',').map(v => v.trim()).filter(Boolean) ?? [];
if (turnUrls.length) STUN_SERVERS.push({ urls: turnUrls, username: import.meta.env.VITE_TURN_USERNAME as string | undefined, credential: import.meta.env.VITE_TURN_CREDENTIAL as string | undefined });
const RING_TIMEOUT_MS = 45_000;

function urlBase64ToUint8Array(value: string): Uint8Array {
  const padding = '='.repeat((4 - value.length % 4) % 4);
  const base64 = (value + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = window.atob(base64);
  return Uint8Array.from([...raw].map(char => char.charCodeAt(0)));
}

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState(''); const [notice, setNotice] = useState('');
  const [conversations, setConversations] = useState<Conversation[]>([]); const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]); const [draft, setDraft] = useState(''); const [search, setSearch] = useState('');
  const [profile, setProfile] = useState<Profile | null>(null); const [showMobileChat, setShowMobileChat] = useState(false);
  const [unreadTotal, setUnreadTotal] = useState(0); const [call, setCall] = useState<CallState | null>(null);
  const callRef = useRef<CallState | null>(null); const callSeen = useRef(new Set<string>());
  const audioContextRef = useRef<AudioContext | null>(null); const notifiedMessageIds = useRef(new Set<string>());
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(() => ('Notification' in window ? Notification.permission : 'denied')); const [soundEnabled, setSoundEnabled] = useState(() => localStorage.getItem('sspace_messenger_sound') !== 'off');
  const [installPrompt, setInstallPrompt] = useState<any>(null); const [isInstalled, setIsInstalled] = useState(() => window.matchMedia?.('(display-mode: standalone)').matches || (navigator as any).standalone === true); const [installHelp, setInstallHelp] = useState(false); const [showLinkConfirm, setShowLinkConfirm] = useState(false);
  const callTimeoutRef = useRef<number | null>(null); const callClockRef = useRef<number | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null); const remoteVideoRef = useRef<HTMLVideoElement | null>(null); const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const activeConversation = conversations.find(c => c.id === activeId) ?? null;
  const filtered = useMemo(() => conversations.filter(c => (c.other?.display_name ?? c.other?.username ?? '').toLowerCase().includes(search.toLowerCase())), [conversations, search]);

  useEffect(() => {
    // Arrivée depuis le bouton Messenger du réseau social : mettre en évidence l'installation gratuite.
    if (new URLSearchParams(window.location.search).get('install') === '1') setInstallHelp(true);
    const onPrompt = (event: Event) => { event.preventDefault(); setInstallPrompt(event); };
    const onInstalled = () => { setIsInstalled(true); setInstallPrompt(null); setInstallHelp(false); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    const media = window.matchMedia?.('(display-mode: standalone)');
    const onDisplayMode = () => setIsInstalled(!!media?.matches || (navigator as any).standalone === true);
    media?.addEventListener?.('change', onDisplayMode);
    return () => { window.removeEventListener('beforeinstallprompt', onPrompt); window.removeEventListener('appinstalled', onInstalled); media?.removeEventListener?.('change', onDisplayMode); };
  }, []);

  async function installMessenger() {
    if (installPrompt) {
      try { await installPrompt.prompt(); const choice = await installPrompt.userChoice; if (choice?.outcome === 'accepted') setNotice('Installation lancée. Une fois terminée, ouvre SSPACE Messenger depuis son icône.'); }
      catch (error) { console.warn('Installation PWA:', error); setInstallHelp(true); }
      finally { setInstallPrompt(null); }
    } else if (!isInstalled) setInstallHelp(value => !value);
  }

  const unlockNotificationAudio = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      if (!audioContextRef.current) audioContextRef.current = new AudioCtx();
      if (audioContextRef.current.state === 'suspended') void audioContextRef.current.resume();
    } catch { /* Audio non disponible sur cet appareil */ }
  };
  const playIncomingSound = () => {
    if (!soundEnabled || !audioContextRef.current) return;
    try {
      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') void ctx.resume();
      const start = ctx.currentTime;
      [740, 988].forEach((frequency, index) => {
        const oscillator = ctx.createOscillator(); const gain = ctx.createGain();
        oscillator.type = 'sine'; oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, start + index * 0.13);
        gain.gain.exponentialRampToValueAtTime(0.075, start + index * 0.13 + 0.025);
        gain.gain.exponentialRampToValueAtTime(0.0001, start + index * 0.13 + 0.19);
        oscillator.connect(gain); gain.connect(ctx.destination);
        oscillator.start(start + index * 0.13); oscillator.stop(start + index * 0.13 + 0.21);
      });
    } catch { /* Sonnerie facultative */ }
  };
  async function enableNotifications() {
    unlockNotificationAudio();
    localStorage.setItem('sspace_messenger_sound', 'on'); setSoundEnabled(true);
    if (!('Notification' in window)) { setNotice('Les notifications système ne sont pas prises en charge par ce navigateur.'); return; }
    const permission = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission;
    setNotificationPermission(permission);
    if (permission === 'granted') {
      let pushReady = false;
      const vapidKey = import.meta.env.VITE_WEB_PUSH_PUBLIC_KEY as string | undefined;
      if (session && supabase && vapidKey && 'serviceWorker' in navigator && 'PushManager' in window) {
        try {
          const registration = await navigator.serviceWorker.ready;
          const existing = await registration.pushManager.getSubscription();
          const subscription = existing ?? await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(vapidKey) as BufferSource });
          const { error } = await supabase.from('push_subscriptions').upsert({ user_id: session.user.id, endpoint: subscription.endpoint, subscription: subscription.toJSON(), updated_at: new Date().toISOString() }, { onConflict: 'endpoint' });
          if (!error) pushReady = true; else console.warn('Enregistrement push SSPACE:', error.message);
        } catch (error) { console.warn('Push SSPACE indisponible:', error); }
      }
      setNotice(pushReady ? 'Notifications et alertes push activées, y compris lorsque Messenger est fermé (si le service push est déployé).' : 'Sonnerie et notifications activées lorsque Messenger fonctionne. Pour les alertes lorsque l’application est fermée, la clé VAPID et le service push doivent aussi être configurés.');
    } else setNotice('Autorise les notifications SSPACE Messenger dans les réglages du navigateur ou du téléphone.');
  }
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    void navigator.serviceWorker.ready.then(registration => {
      const badgeApi = (registration as any).setAppBadge;
      if (typeof badgeApi === 'function') return unreadTotal > 0 ? badgeApi.call(registration, unreadTotal) : (registration as any).clearAppBadge?.();
      return undefined;
    }).catch(() => {});
  }, [unreadTotal]);

  const publishCall = (next: CallState | null) => { callRef.current = next; setCall(next ? { ...next } : null); };
  const isCurrentCall = (id: string) => callRef.current?.callId === id;

  useEffect(() => {
    if (!supabase || !window.opener) return;
    const nonce = new URLSearchParams(window.location.search).get('sspace_link_nonce');
    if (!nonce) return;
    const socialOrigin = window.location.origin;
    const receiveSession = async (event: MessageEvent) => {
      if (event.origin !== socialOrigin || event.source !== window.opener || event.data?.type !== 'SSPACE_SESSION' || event.data?.nonce !== nonce) return;
      const sessionData = event.data.session;
      if (!sessionData?.access_token || !sessionData?.refresh_token) return;
      const { error } = await supabase!.auth.setSession({ access_token: sessionData.access_token, refresh_token: sessionData.refresh_token });
      if (error) setAuthError('La liaison automatique a échoué : ' + error.message);
      else { window.history.replaceState({}, document.title, window.location.pathname); setNotice('Compte SSpace connecté automatiquement.'); }
      window.removeEventListener('message', receiveSession);
    };
    window.addEventListener('message', receiveSession);
    window.opener.postMessage({ type: 'SSPACE_MESSENGER_READY', nonce }, socialOrigin);
    return () => window.removeEventListener('message', receiveSession);
  }, []);

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return; }
    let settled = false;
    const timeoutId = window.setTimeout(() => {
      if (!settled) {
        setAuthLoading(false);
        setNotice('La connexion à SSPACE prend trop de temps. Vérifie Internet puis réessaie; Messenger reste accessible sans bloquer l’écran.');
      }
    }, 12000);
    supabase.auth.getSession()
      .then(({ data, error }) => {
        if (error) setAuthError('Connexion SSPACE : ' + error.message);
        setSession(data.session);
      })
      .catch((error: unknown) => {
        setAuthError('Connexion SSPACE impossible : ' + (error instanceof Error ? error.message : 'erreur réseau'));
      })
      .finally(() => {
        settled = true;
        window.clearTimeout(timeoutId);
        setAuthLoading(false);
      });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    const unlock = () => unlockNotificationAudio();
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => { window.removeEventListener('pointerdown', unlock); window.removeEventListener('keydown', unlock); };
  }, []);

  async function loadConversations() {
    if (!supabase || !session) return;
    const me = session.user.id;
    const { data: rows, error } = await supabase.from('conversations').select('id,user_one,user_two,updated_at').or(`user_one.eq.${me},user_two.eq.${me}`).order('updated_at', {ascending:false});
    if (error) { setNotice('Chargement des conversations impossible : ' + error.message); return; }
    const convs = rows ?? [];
    if (!convs.length) { setConversations([]); setUnreadTotal(0); return; }
    const otherIds = [...new Set(convs.map((c:any) => c.user_one === me ? c.user_two : c.user_one))];
    const ids = convs.map((c:any) => c.id);
    const [{data: people}, {data: recent}, {data: unread}] = await Promise.all([
      supabase.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').in('id', otherIds),
      supabase.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').in('conversation_id', ids).order('created_at',{ascending:false}).limit(Math.min(500, Math.max(100, ids.length * 10))),
      supabase.from('messages').select('id,conversation_id').in('conversation_id', ids).neq('sender_id', me).is('read_at', null)
    ]);
    const personMap = new Map((people ?? []).map((p:any) => [p.id, p]));
    const latest = new Map<string, Message>();
    (recent ?? []).forEach((m:any) => { if (!latest.has(m.conversation_id)) latest.set(m.conversation_id, m); });
    const unreadMap = new Map<string, number>();
    (unread ?? []).forEach((m:any) => unreadMap.set(m.conversation_id, (unreadMap.get(m.conversation_id) ?? 0) + 1));
    const enriched: Conversation[] = convs.map((c:any) => ({...c, other:personMap.get(c.user_one === me ? c.user_two : c.user_one), last_message:latest.get(c.id) ?? null, unread_count:unreadMap.get(c.id) ?? 0}));
    enriched.sort((a,b) => Date.parse(b.last_message?.created_at ?? b.updated_at) - Date.parse(a.last_message?.created_at ?? a.updated_at));
    setConversations(enriched); setUnreadTotal(enriched.reduce((n,c) => n + (c.unread_count ?? 0), 0));
  }

  useEffect(() => {
    if (!session || new URLSearchParams(window.location.search).get('from') !== 'sspace') return;
    if (!localStorage.getItem(`sspace_messenger_link_confirmed_${session.user.id}`)) setShowLinkConfirm(true);
  }, [session?.user.id]);

  function confirmAccountLink() {
    if (session) localStorage.setItem(`sspace_messenger_link_confirmed_${session.user.id}`, 'yes');
    setShowLinkConfirm(false);
    const cleanUrl = new URL(window.location.href); cleanUrl.searchParams.delete('from');
    window.history.replaceState({}, document.title, cleanUrl.pathname + cleanUrl.search + cleanUrl.hash);
    setNotice('Liaison confirmée : ton compte, tes contacts et tes conversations SSPACE sont partagés avec Messenger sur cet appareil.');
  }

  useEffect(() => {
    const requestedConversation = new URLSearchParams(window.location.search).get('conversation');
    if (!requestedConversation || !conversations.some(conversation => conversation.id === requestedConversation)) return;
    setActiveId(requestedConversation);
    setShowMobileChat(true);
    const cleanUrl = new URL(window.location.href);
    cleanUrl.searchParams.delete('conversation');
    window.history.replaceState({}, document.title, cleanUrl.pathname + cleanUrl.search + cleanUrl.hash);
  }, [conversations]);

  useEffect(() => {
    if (!session || !supabase) { setProfile(null); setConversations([]); setUnreadTotal(0); return; }
    let alive = true;
    const me = session.user.id;
    supabase.from('profiles').select('id,username,display_name,avatar_url,last_seen_at,show_online').eq('id', session.user.id).maybeSingle().then(({data}) => { if (alive && data) setProfile(data as Profile); });
    loadConversations();
    // SSPACE's canonical notification table is populated by a database trigger
    // and is already included in supabase_realtime. Listen to it instead of
    // messages (which is not guaranteed to be in the Realtime publication).
    const channel = supabase.channel(`sspace-messenger-inbox:${me}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'private_message_notifications', filter: `user_id=eq.${me}` }, payload => {
        if (!alive) return;
        const incoming = payload.new as { id: string; user_id: string; message_id: string; conversation_id: string; sender_id: string };
        if (incoming.sender_id !== me && incoming.message_id && !notifiedMessageIds.current.has(incoming.message_id)) {
          notifiedMessageIds.current.add(incoming.message_id);
          if (notifiedMessageIds.current.size > 250) notifiedMessageIds.current.clear();
          playIncomingSound();
          if (document.visibilityState === 'hidden' && 'Notification' in window && Notification.permission === 'granted') {
            void navigator.serviceWorker?.ready.then(reg => reg.showNotification('Nouveau message · SSPACE', {
              body: 'Tu as reçu un nouveau message.',
              icon: '/messenger/icon.svg', badge: '/messenger/icon.svg', tag: `sspace-message-${incoming.conversation_id}`,
              data: { url: `/messenger/?conversation=${encodeURIComponent(incoming.conversation_id)}`, conversationId: incoming.conversation_id }
            })).catch(() => {});
          }
        }
        void loadConversations();
      }).subscribe();
    const timer = window.setInterval(() => { if (document.visibilityState === 'visible') loadConversations(); }, 15000);
    return () => { alive=false; window.clearInterval(timer); supabase?.removeChannel(channel); };
  }, [session, soundEnabled]);

  async function markConversationRead(id: string) {
    if (!supabase || !session) return;
    const { error } = await supabase.from('messages').update({read_at:new Date().toISOString()}).eq('conversation_id',id).neq('sender_id',session.user.id).is('read_at',null);
    if (error) setNotice('Les messages sont ouverts, mais leur état de lecture n’a pas pu être synchronisé : ' + error.message);
    await loadConversations();
  }

  useEffect(() => {
    if (!activeId || !supabase || !session) { setMessages([]); return; }
    let alive=true;
    const load = async () => {
      const {data,error}=await supabase!.from('messages').select('id,conversation_id,sender_id,body,created_at,read_at,message_type,media_path,link_url').eq('conversation_id',activeId).order('created_at',{ascending:true}).limit(300);
      if (!error && alive) { setMessages((data??[]) as Message[]); await markConversationRead(activeId); }
      else if(error && alive) setNotice('Messages indisponibles : '+error.message);
    };
    load();
    const channel=supabase.channel(`sspace-messenger-chat-${activeId}`).on('postgres_changes',{event:'*',schema:'public',table:'messages',filter:`conversation_id=eq.${activeId}`},()=>load()).subscribe();
    return ()=>{alive=false;supabase?.removeChannel(channel);};
  },[activeId,session]);

  async function authenticate(e:FormEvent) { e.preventDefault(); setAuthError(''); setNotice(''); if(!supabase)return; const {error}=await supabase.auth.signInWithPassword({email,password}); if(error) setAuthError(error.message); }
  async function sendMessage(e:FormEvent) { e.preventDefault(); unlockNotificationAudio(); const body=draft.trim(); if(!body||!activeId||!session||!supabase)return; setDraft(''); const {error}=await supabase.from('messages').insert({conversation_id:activeId,sender_id:session.user.id,body,message_type:'text'}); if(error){setDraft(body);setNotice('Message non envoyé : '+error.message);} }
  async function signOut(){ if(callRef.current) endCall(false); await supabase?.auth.signOut();setActiveId(null);setShowMobileChat(false); }
  async function createConversation(){
    if(!supabase||!session)return;
    const username=window.prompt('Nom d’utilisateur SSpace de la personne à contacter'); if(!username)return;
    const normalized=username.trim().replace(/^@/, '').toLowerCase(); if(!normalized)return;
    const {data:target,error:lookupError}=await supabase.from('profiles').select('id').ilike('username',normalized).maybeSingle();
    if(lookupError||!target){setNotice(lookupError?.message??'Utilisateur introuvable.');return;}
    const {data:friendship,error:friendError}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${session.user.id},receiver_id.eq.${target.id}),and(sender_id.eq.${target.id},receiver_id.eq.${session.user.id})`).maybeSingle();
    if(friendError||!friendship){setNotice('Vous devez être amis sur SSpace pour démarrer une conversation.');return;}
    const pair=[session.user.id,target.id].sort();
    let {data:existing,error}=await supabase.from('conversations').select('id,user_one,user_two').eq('user_one',pair[0]).eq('user_two',pair[1]).maybeSingle();
    if(error){setNotice('Recherche de conversation impossible : '+error.message);return;}
    if(!existing){const created=await supabase.from('conversations').insert({user_one:pair[0],user_two:pair[1]}).select('id,user_one,user_two').single(); existing=created.data; error=created.error;}
    if(error||!existing){setNotice('Création impossible : '+(error?.message??'erreur inconnue'));return;}
    await loadConversations(); setActiveId(existing.id); setShowMobileChat(true);
  }

  function callSupported() { return typeof navigator.mediaDevices?.getUserMedia === 'function' && typeof window.RTCPeerConnection === 'function'; }
  async function areFriends(peerId: string) {
    if (!supabase || !session) return false;
    const me=session.user.id;
    const {data,error}=await supabase.from('friend_requests').select('id').eq('status','accepted').or(`and(sender_id.eq.${me},receiver_id.eq.${peerId}),and(sender_id.eq.${peerId},receiver_id.eq.${me})`).maybeSingle();
    return !error && Boolean(data);
  }
  async function sendCallSignal(kind: string, payload: Record<string,unknown>, to: string, callId: string) {
    if (!supabase || !session || !to || !callId) return false;
    const {error}=await supabase.from('call_signals').insert({call_id:callId,sender_id:session.user.id,receiver_id:to,kind,payload});
    if(error){console.error('WebRTC signal error',kind,error);setNotice(/call_signals|relation|schema cache/i.test(error.message)?'Les appels ne sont pas activés dans Supabase : applique la migration SQL call_signals.':'Signal d’appel impossible : '+error.message);return false;}
    return true;
  }
  function clearCallTimers(){ if(callTimeoutRef.current!==null)window.clearTimeout(callTimeoutRef.current); if(callClockRef.current!==null)window.clearInterval(callClockRef.current); callTimeoutRef.current=null;callClockRef.current=null; }
  function endCall(notifyPeer: boolean, message?: string) {
    const st=callRef.current; if(!st)return;
    clearCallTimers();
    if(notifyPeer) void sendCallSignal('hangup',{},st.peerId,st.callId);
    try{st.pc?.close();}catch{}
    st.localStream?.getTracks().forEach(track=>track.stop());
    if(localVideoRef.current)localVideoRef.current.srcObject=null;
    if(remoteVideoRef.current)remoteVideoRef.current.srcObject=null;
    if(remoteAudioRef.current)remoteAudioRef.current.srcObject=null;
    publishCall(null);
    if(message)setNotice(message);
  }
  async function makePeer(st: CallState) {
    if(st.pc)return st.pc;
    const pc=new RTCPeerConnection({iceServers:STUN_SERVERS}); st.pc=pc;
    st.localStream?.getTracks().forEach(track=>{
      const sender=pc.addTrack(track,st.localStream!);
      if(track.kind==='video'){
        try{const params=sender.getParameters();params.encodings=params.encodings?.length?params.encodings:[{}];params.encodings[0].maxBitrate=4_000_000;params.encodings[0].maxFramerate=30;params.degradationPreference='maintain-resolution';void sender.setParameters(params).catch(()=>{});}catch{}
      }
    });
    pc.onicecandidate=e=>{if(e.candidate)void sendCallSignal('ice',{candidates:[e.candidate.toJSON()]},st.peerId,st.callId);};
    pc.ontrack=e=>{
      const stream=e.streams?.[0]??new MediaStream([e.track]); st.remoteStream=stream; publishCall(st);
      if(st.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=stream;void remoteVideoRef.current.play().catch(()=>{});}
      if(remoteAudioRef.current){remoteAudioRef.current.srcObject=stream;void remoteAudioRef.current.play().catch(()=>{});}
    };
    pc.onconnectionstatechange=()=>{
      if(callRef.current?.callId!==st.callId)return;
      if(pc.connectionState==='connected'){
        st.phase='active';st.startedAt=Date.now();publishCall(st);clearCallTimers();
        callClockRef.current=window.setInterval(()=>{const latest=callRef.current;if(latest?.callId===st.callId)publishCall({...latest});},1000);
      } else if(pc.connectionState==='failed') endCall(true,'Connexion WebRTC échouée. Un serveur TURN peut être nécessaire sur ce réseau.');
      else if(pc.connectionState==='disconnected') { window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&pc.connectionState!=='connected')endCall(true,'Connexion interrompue.');},9000); }
    };
    publishCall(st); return pc;
  }
  async function getCallMediaStream(mediaType: CallKind) {
    const audio: MediaTrackConstraints={echoCancellation:true,noiseSuppression:true,autoGainControl:true};
    if(mediaType==='audio')return navigator.mediaDevices.getUserMedia({audio,video:false});
    const profiles: MediaStreamConstraints[]=[
      {audio,video:{facingMode:'user',width:{ideal:1920},height:{ideal:1080},frameRate:{ideal:30,max:30}}},
      {audio,video:{facingMode:'user',width:{ideal:1280},height:{ideal:720},frameRate:{ideal:30}}},
      {audio,video:{facingMode:'user'}}
    ];
    let lastError:unknown;
    for(const constraints of profiles){try{return await navigator.mediaDevices.getUserMedia(constraints);}catch(error){lastError=error;}}
    throw lastError instanceof Error?lastError:new Error('Caméra inaccessible.');
  }

  async function startCall(mediaType: CallKind) {
    if(!session||!activeConversation?.other||!supabase)return;
    if(!callSupported()){setNotice('Ce navigateur ne prend pas en charge les appels WebRTC. Utilise HTTPS et autorise le micro/la caméra.');return;}
    if(callRef.current){setNotice('Un appel est déjà en cours.');return;}
    const peer=activeConversation.other;
    if(!(await areFriends(peer.id))){setNotice('Les appels sont réservés aux amis SSPACE acceptés.');return;}
    const st:CallState={callId:crypto.randomUUID(),peerId:peer.id,peerName:peer.display_name??peer.username??'Membre SSPACE',peerAvatar:peer.avatar_url??'',mediaType,role:'caller',phase:'ringing-out',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
    publishCall(st);
    try{st.localStream=await getCallMediaStream(mediaType);}
    catch(err){publishCall(null);setNotice(err instanceof Error?`Accès au ${mediaType==='video'?'micro et à la caméra':'micro'} refusé : ${err.message}`:'Impossible d’accéder au micro ou à la caméra.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    const ok=await sendCallSignal('invite',{mediaType},st.peerId,st.callId);
    if(!ok){endCall(false);return;}
    callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-out'){void sendCallSignal('hangup',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Pas de réponse.');}},RING_TIMEOUT_MS);
  }
  async function acceptCall() {
    const st=callRef.current;if(!st||st.phase!=='ringing-in')return;
    clearCallTimers();st.phase='connecting';publishCall(st);
    try{st.localStream=await getCallMediaStream(st.mediaType);}
    catch(err){await sendCallSignal('reject',{reason:'media-permission'},st.peerId,st.callId);endCall(false,err instanceof Error?`Permission micro/caméra refusée : ${err.message}`:'Permission micro/caméra refusée.');return;}
    if(!isCurrentCall(st.callId)){st.localStream.getTracks().forEach(t=>t.stop());return;}
    publishCall(st);
    if(st.mediaType==='video'&&localVideoRef.current){localVideoRef.current.srcObject=st.localStream;void localVideoRef.current.play().catch(()=>{});}
    await makePeer(st);await sendCallSignal('accept',{},st.peerId,st.callId);
  }
  async function handleCallSignal(signal:any) {
    if(!signal?.id||callSeen.current.has(signal.id))return;
    callSeen.current.add(signal.id);if(callSeen.current.size>500)callSeen.current.delete(callSeen.current.values().next().value as string);
    const current=callRef.current;
    const belongs=current&&current.callId===signal.call_id&&current.peerId===signal.sender_id;
    if(signal.kind==='invite'){
      if(!session||!supabase)return;
      if(current){await sendCallSignal('busy',{},signal.sender_id,signal.call_id);return;}
      if(!(await areFriends(signal.sender_id)))return;
      const {data:person}=await supabase.from('profiles').select('id,username,display_name,avatar_url').eq('id',signal.sender_id).maybeSingle();
      if(callRef.current)return;
      const st:CallState={callId:signal.call_id,peerId:signal.sender_id,peerName:person?.display_name??person?.username??'Membre SSPACE',peerAvatar:person?.avatar_url??'',mediaType:signal.payload?.mediaType==='video'?'video':'audio',role:'callee',phase:'ringing-in',pc:null,localStream:null,remoteStream:null,pendingIce:[],startedAt:null,muted:false,cameraEnabled:true,minimized:false};
      publishCall(st);callTimeoutRef.current=window.setTimeout(()=>{if(callRef.current?.callId===st.callId&&st.phase==='ringing-in'){void sendCallSignal('reject',{reason:'timeout'},st.peerId,st.callId);endCall(false,'Appel manqué de '+st.peerName+'.');}},RING_TIMEOUT_MS);return;
    }
    if(!belongs)return;
    if(signal.kind==='accept'&&current.role==='caller'&&current.phase==='ringing-out'){
      clearCallTimers();current.phase='connecting';publishCall(current);
      const pc=await makePeer(current);const offer=await pc.createOffer();await pc.setLocalDescription(offer);
      await sendCallSignal('offer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='offer'&&current.role==='callee'){
      const pc=await makePeer(current);await pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});
      for(const candidate of current.pendingIce.splice(0)){try{await pc.addIceCandidate(candidate);}catch{}}
      const answer=await pc.createAnswer();await pc.setLocalDescription(answer);
      await sendCallSignal('answer',{type:pc.localDescription?.type,sdp:pc.localDescription?.sdp},current.peerId,current.callId);return;
    }
    if(signal.kind==='answer'&&current.role==='caller'&&current.pc){await current.pc.setRemoteDescription({type:signal.payload.type,sdp:signal.payload.sdp});for(const candidate of current.pendingIce.splice(0)){try{await current.pc.addIceCandidate(candidate);}catch{}}return;}
    if(signal.kind==='ice'){
      for(const candidate of signal.payload?.candidates??[]){if(current.pc?.remoteDescription){try{await current.pc.addIceCandidate(candidate);}catch{}}else current.pendingIce.push(candidate);}return;
    }
    if(signal.kind==='reject'){endCall(false,signal.payload?.reason==='timeout'?'Pas de réponse.':'Appel refusé.');return;}
    if(signal.kind==='busy'){endCall(false,current.peerName+' est déjà en appel.');return;}
    if(signal.kind==='hangup'){endCall(false,'Appel terminé.');}
  }

  useEffect(()=>{
    if(!session||!supabase)return;
    const channel=supabase.channel('sspace-messenger-calls:'+session.user.id)
      .on('postgres_changes',{event:'INSERT',schema:'public',table:'call_signals',filter:'receiver_id=eq.'+session.user.id},payload=>{void handleCallSignal(payload.new).catch(err=>{console.error('WebRTC signal handling',err);setNotice('Erreur pendant la négociation de l’appel.');});})
      .subscribe((status,error)=>{if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')console.warn('Canal WebRTC indisponible',error);});
    return ()=>{supabase?.removeChannel(channel);if(callRef.current)endCall(false);};
  },[session?.user.id]);

  useEffect(()=>{
    if(!call)return;
    if(call.localStream&&localVideoRef.current&&call.mediaType==='video'){localVideoRef.current.srcObject=call.localStream;void localVideoRef.current.play().catch(()=>{});}
    if(call.remoteStream){if(call.mediaType==='video'&&remoteVideoRef.current){remoteVideoRef.current.srcObject=call.remoteStream;void remoteVideoRef.current.play().catch(()=>{});}if(remoteAudioRef.current){remoteAudioRef.current.srcObject=call.remoteStream;void remoteAudioRef.current.play().catch(()=>{});}}
  },[call?.localStream,call?.remoteStream,call?.mediaType]);

  function toggleMute(){const st=callRef.current;if(!st?.localStream)return;st.muted=!st.muted;st.localStream.getAudioTracks().forEach(t=>t.enabled=!st.muted);publishCall(st);}
  function toggleCamera(){const st=callRef.current;if(!st?.localStream)return;st.cameraEnabled=!st.cameraEnabled;st.localStream.getVideoTracks().forEach(t=>t.enabled=st.cameraEnabled);publishCall(st);}
  const callDuration=call?.startedAt?Math.max(0,Math.floor((Date.now()-call.startedAt)/1000)):0;
  const durationLabel=`${String(Math.floor(callDuration/60)).padStart(2,'0')}:${String(callDuration%60).padStart(2,'0')}`;

  if(authLoading) return <div className="loading-screen"><div className="brand-mark">S</div><p>Ouverture de SSpace Messenger…</p></div>;
  if(!isSupabaseConfigured) return <SetupScreen/>;
  if(!session) return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">VOTRE COMPTE SSPACE</div><h1>Bienvenue dans Messenger.</h1><p className="muted">Connectez-vous avec le compte que vous utilisez déjà sur le réseau social SSpace. Aucun deuxième compte Messenger n’est créé.</p><form onSubmit={authenticate} className="auth-form"><label>Adresse courriel<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.com" required autoComplete="username"/></label><label>Mot de passe<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Mot de passe SSpace" required autoComplete="current-password"/></label>{authError&&<div className="error">{authError}</div>}<button className="primary full" type="submit">Se connecter à SSpace</button></form><a className="text-button" href="/">Retour au réseau social SSpace <ExternalLink size={14}/></a><div className="auth-foot"><ShieldCheck size={15}/> Même compte SSpace · Conversations partagées</div></div></main>;

  return <div className="app-shell"><aside className={`sidebar ${showMobileChat?'hide-mobile':''}`}><div className="sidebar-top"><Brand/><div className="sidebar-tools">{!isInstalled&&<button className="icon-btn install-app-btn" onClick={()=>void installMessenger()} aria-label="Installer SSPACE Messenger" title="Installer sur cet appareil">{installPrompt?<Download size={18}/>:<Smartphone size={18}/>}</button>}<button className="icon-btn notification-toggle" onClick={()=>void enableNotifications()} aria-label="Activer les notifications et la sonnerie" title="Activer les notifications et la sonnerie"><BellRing size={19}/></button></div></div>{!isInstalled&&<div className="install-card"><strong>Installer Messenger</strong><span>Ajoute l’application à ton écran d’accueil pour y revenir directement.</span><button onClick={()=>void installMessenger()}>{installPrompt?'Installer l’application':'Voir comment installer'}</button>{installHelp&&<small>Sur Android : ouvre le menu ⋮ de Chrome, puis « Installer l’application » ou « Ajouter à l’écran d’accueil ». Accepte l’installation. La connexion SSPACE sera conservée automatiquement.</small>}</div>}<div>{showLinkConfirm&&<div className="install-card link-confirm-card"><strong>Confirmer la liaison du compte</strong><span>Messenger a retrouvé ta session SSPACE sur cet appareil. Confirme pour utiliser le même profil, les mêmes contacts et les mêmes conversations.</span><button onClick={confirmAccountLink}>Accepter et lier mon compte</button></div>}</div><div className="welcome"><div className="eyebrow">MESSAGERIE PRIVÉE</div><h1>Messages<span>.</span></h1><p>Votre monde, vos conversations.</p><div className="inbox-count"><Bell size={14}/> {unreadTotal} message{unreadTotal===1?'':'s'} reçu{unreadTotal===1?'':'s'} non lu{unreadTotal===1?'':'s'}</div><button className="notification-setup" onClick={()=>void enableNotifications()}><BellRing size={14}/> {notificationPermission==='granted'?'Notifications activées':'Activer la sonnerie et les notifications'}</button></div><div className="search-box"><Search size={17}/><input placeholder="Rechercher" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="section-heading"><span>CONVERSATIONS</span><button className="icon-btn small" onClick={createConversation} title="Nouvelle conversation"><Plus size={18}/></button></div><div className="conversation-list">{filtered.length===0?<div className="empty-list"><MessageCircle size={25}/><p>{search?'Aucun résultat':'Vos conversations SSpace apparaîtront ici.'}</p><button className="text-button" onClick={createConversation}>Démarrer une discussion</button></div>:filtered.map(c=><button key={c.id} className={`conversation-item ${activeId===c.id?'selected':''}`} onClick={()=>{setActiveId(c.id);setShowMobileChat(true);}}><div className="avatar">{c.other?.avatar_url?<img src={c.other.avatar_url} alt=""/>:(c.other?.display_name??c.other?.username??'S').slice(0,1).toUpperCase()}</div><div className="conversation-meta"><strong>{c.other?.display_name??(c.other?.username?'@'+c.other.username:'Membre SSpace')}</strong><span>{c.last_message?.body??'Démarrer la conversation'}</span></div>{(c.unread_count??0)>0&&<span className="unread-pill">{c.unread_count}</span>}<span className="time">{c.last_message?new Date(c.last_message.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'}):''}</span></button>)}</div><div className="sidebar-bottom"><div className="profile-chip"><div className="avatar mini">{profile?.avatar_url?<img src={profile.avatar_url} alt=""/>:(profile?.display_name??session.user.email??'S').slice(0,1).toUpperCase()}</div><div><strong>{profile?.display_name??session.user.email}</strong><span>Compte SSpace connecté</span></div><button className="icon-btn" onClick={signOut} title="Déconnexion"><LogOut size={17}/></button></div></div></aside>
  <main className={`chat-panel ${!showMobileChat?'hide-mobile':''}`}>{activeConversation?<><header className="chat-header"><button className="icon-btn back-btn" onClick={()=>setShowMobileChat(false)}><ArrowLeft/></button><div className="avatar">{activeConversation.other?.avatar_url?<img src={activeConversation.other.avatar_url} alt=""/>:(activeConversation.other?.display_name??'S').slice(0,1).toUpperCase()}</div><div className="chat-person"><strong>{activeConversation.other?.display_name??activeConversation.other?.username??'Membre SSpace'}</strong><span>Conversation SSpace partagée</span></div><div className="header-actions"><button className="icon-btn" title="Appel vocal" aria-label="Appel vocal" onClick={()=>void startCall('audio')}><Phone size={19}/></button><button className="icon-btn" title="Appel vidéo" aria-label="Appel vidéo" onClick={()=>void startCall('video')}><Video size={20}/></button><button className="icon-btn" title="Pièces jointes : prochaine étape" disabled><Paperclip size={19}/></button></div></header><div className="messages-area">{messages.length===0?<div className="chat-empty"><div className="empty-icon"><MessageCircle size={28}/></div><h2>La conversation commence ici.</h2><p>Envoyez votre premier message en toute simplicité.</p></div>:messages.map(m=><div key={m.id} className={`message-row ${m.sender_id===session.user.id?'mine':'theirs'}`}><div className="bubble">{m.body}<div className="message-time">{new Date(m.created_at).toLocaleTimeString('fr-CA',{hour:'2-digit',minute:'2-digit'})}{m.sender_id===session.user.id&&<CheckCheck size={13}/>}</div></div></div>)}</div><form className="composer" onSubmit={sendMessage}><button type="button" className="icon-btn attach" title="Pièces jointes : prochaine étape" disabled><Paperclip size={19}/></button><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Écrire un message…"/><button type="button" className="icon-btn attach" title="Émojis : prochaine étape" disabled><Smile size={19}/></button><button className="send-btn" type="submit" disabled={!draft.trim()} aria-label="Envoyer"><Send size={18}/></button></form></>:<div className="welcome-panel"><div className="welcome-art"><div className="art-orbit orbit-one"/><div className="art-orbit orbit-two"/><div className="art-core"><MessageCircle size={48}/></div></div><div className="eyebrow">SSPACE MESSENGER</div><h2>Les bonnes conversations<br/>font les belles connexions.</h2><p>Vos messages sont les mêmes que sur le réseau social SSpace.</p><button className="primary" onClick={createConversation}><Plus size={17}/> Nouvelle conversation</button><div className="secure-note"><ShieldCheck size={15}/> Vos échanges restent privés.</div></div>}</main>
  {call&&<div className={`call-overlay ${call.minimized?'is-minimized':''}`} role="dialog" aria-modal="true" aria-label={call.mediaType==='video'?'Appel vidéo':'Appel vocal'}>
    {call.phase==='ringing-in'?<div className="incoming-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><div className="eyebrow">APPEL {call.mediaType==='video'?'VIDÉO':'VOCAL'} ENTRANT</div><h2>{call.peerName}</h2><p>Appel entrant sur SSPACE Messenger</p><div className="call-actions"><button className="call-decline" onClick={()=>{void sendCallSignal('reject',{reason:'declined'},call.peerId,call.callId);endCall(false);}}><PhoneOff/> Refuser</button><button className="call-accept" onClick={()=>void acceptCall()}><Phone/> Répondre</button></div></div>:<div className={`call-stage ${call.mediaType==='video'?'video-call':'audio-call'}`}>
      {call.mediaType==='video'?<><video ref={remoteVideoRef} className="remote-video" autoPlay muted playsInline/><video ref={localVideoRef} className="local-video" autoPlay muted playsInline/><div className="video-peer-name">{call.peerName} · {call.phase==='active'?durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</div></>:<div className="audio-call-card"><div className="call-avatar">{call.peerAvatar?<img src={call.peerAvatar} alt=""/>:call.peerName.slice(0,1).toUpperCase()}</div><h2>{call.peerName}</h2><p>{call.phase==='active'?'En ligne · '+durationLabel:call.phase==='ringing-out'?'Appel en cours…':'Connexion…'}</p></div>}
      <div className="call-controls"><button title={call.muted?'Activer le micro':'Couper le micro'} onClick={toggleMute}>{call.muted?<MicOff/>:<Mic/>}</button>{call.mediaType==='video'&&<button title={call.cameraEnabled?'Couper la caméra':'Activer la caméra'} onClick={toggleCamera}>{call.cameraEnabled?<Video/>:<VideoOff/>}</button>}<button className="hangup" title="Raccrocher" onClick={()=>endCall(true,'Appel terminé.')}><PhoneOff/></button><button title={call.minimized?'Agrandir':'Réduire'} onClick={()=>{const st=callRef.current;if(st){st.minimized=!st.minimized;publishCall(st);}}}>{call.minimized?<Maximize2/>:<Minimize2/>}</button></div>
    </div>}</div>}
  <audio ref={remoteAudioRef} autoPlay playsInline className="sr-audio"/>
  {notice&&<div className="toast" role="status" onClick={()=>setNotice('')}>{notice}</div>}</div>;
}

function Brand(){return <div className="brand"><div className="brand-mark">S</div><div><strong>SSpace</strong><span>MESSENGER</span></div></div>}
function SetupScreen(){return <main className="auth-shell"><div className="auth-card"><Brand/><div className="eyebrow">CONFIGURATION REQUISE</div><h1>Préparons votre espace.</h1><p className="muted">Ajoutez l’URL et la clé publique du projet Supabase SIKX utilisé par SSpace. Messenger lira les conversations existantes; aucune nouvelle table de messages n’est créée.</p><div className="setup-code"><code>VITE_SUPABASE_URL=https://sikxoyylihsigzirewmi.supabase.co</code><code>VITE_SUPABASE_ANON_KEY=clé_publishable_SIKX</code></div><p className="small-note">N’utilisez jamais une clé service_role dans l’application.</p><div className="auth-foot"><ExternalLink size={15}/> Même base SSpace · messages reçus non lus uniquement</div></div></main>}
