const BASE='/messenger/';
const CACHE='sspace-messenger-v5';
self.addEventListener('install',event=>event.waitUntil((async()=>{const c=await caches.open(CACHE);await c.addAll([BASE,BASE+'manifest.webmanifest',BASE+'icon.svg',BASE+'icons/icon-192.png',BASE+'icons/icon-512.png',BASE+'icons/icon-maskable-512.png']);await self.skipWaiting()})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('sspace-messenger-')&&k!==CACHE).map(k=>caches.delete(k)));await self.clients.claim()})()));
self.addEventListener('fetch',event=>{const req=event.request;if(req.method!=='GET'||new URL(req.url).origin!==self.location.origin)return;const url=new URL(req.url);if(!url.pathname.startsWith(BASE))return;if(req.mode==='navigate'){event.respondWith(fetch(req).then(res=>{if(res.ok)caches.open(CACHE).then(c=>c.put(BASE,res.clone()));return res}).catch(()=>caches.match(BASE)));return}event.respondWith(caches.match(req).then(hit=>hit||fetch(req).then(res=>{if(res.ok)caches.open(CACHE).then(c=>c.put(req,res.clone()));return res}))) });

self.addEventListener('push', event => {
  let payload = {};
  try { payload = event.data ? event.data.json() : {}; } catch { payload = { body: event.data?.text() || 'Tu as reçu un nouveau message.' }; }
  const title = payload.title || 'Nouveau message · SSPACE';
  const options = {
    body: payload.body || 'Tu as reçu un nouveau message.',
    icon: payload.icon || '/messenger/icon.svg',
    badge: payload.badge || '/messenger/icon.svg',
    tag: payload.tag || 'sspace-new-message',
    data: { url: payload.url || '/messenger/' },
    renotify: true,
    actions: [{ action: 'open', title: 'Ouvrir la discussion' }]
  };
  event.waitUntil((async () => {
    await self.registration.showNotification(title, options);
    try { await self.registration.setAppBadge?.(Number(payload.unreadCount) || 1); } catch {}
  })());
});
self.addEventListener('notificationclick', event => {
  event.notification.close();
  let targetUrl;
  try { targetUrl = new URL(event.notification.data?.url || '/messenger/', self.location.origin); } catch { targetUrl = new URL('/messenger/', self.location.origin); }
  if (targetUrl.origin !== self.location.origin || !targetUrl.pathname.startsWith('/messenger/')) targetUrl = new URL('/messenger/', self.location.origin);
  const target = targetUrl.href;
  event.waitUntil((async () => {
    const windows = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const client of windows) {
      if (client.url.startsWith(self.location.origin + '/messenger/')) {
        await client.focus();
        if ('navigate' in client) await client.navigate(target);
        return;
      }
    }
    await clients.openWindow(target);
  })());
});
