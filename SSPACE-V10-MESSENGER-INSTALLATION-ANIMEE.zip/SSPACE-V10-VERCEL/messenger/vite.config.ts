import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const messengerRoot = fileURLToPath(new URL('.', import.meta.url));
const repositoryRoot = resolve(messengerRoot, '..');

export default defineConfig({
  root: messengerRoot,
  base: '/messenger/',
  plugins: [react()],
  build: {
    outDir: resolve(repositoryRoot, 'dist/messenger'),
    emptyOutDir: false,
    sourcemap: false,
  },
});
