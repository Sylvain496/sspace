# SSPACE Messenger — installation PWA et notifications Android

## Ce qui est préparé dans cette version

- Le bouton **Messenger** du réseau social ouvre directement `/messenger/` après vérification de la session SSPACE.
- Les deux interfaces utilisent la même origine web et le même stockage de session Supabase. Le membre n'a donc pas à créer un deuxième compte ni à recopier son mot de passe pour lier les deux interfaces sur le même navigateur/appareil.
- Messenger est préparé comme PWA installable : manifeste avec identifiants et raccourci, icônes PNG 192/512, affichage autonome, invite d'installation Android lorsqu'elle est offerte par Chrome, et instructions manuelles de secours.
- Le service worker affiche les notifications Web Push, ouvre la conversation ciblée et tente d'afficher le badge de messages non lus sur l'icône de l'application lorsque le système le prend en charge.

## Installation sur Android

1. Déployer la version complète sur le même domaine HTTPS que SSPACE.
2. Se connecter à SSPACE puis toucher **Messenger**.
3. Dans Messenger, toucher **Installer l'application** et accepter la demande Android/Chrome.
4. Si Chrome ne présente pas l'invite, ouvrir le menu ⋮ de Chrome et choisir **Installer l'application** ou **Ajouter à l'écran d'accueil**.
5. Ouvrir Messenger depuis sa nouvelle icône. La session SSPACE du même navigateur/profil est partagée. À la première ouverture depuis le réseau social, accepter **Lier mon compte**; sinon, se connecter une fois avec le même compte.
6. Dans Messenger, toucher **Activer la sonnerie et les notifications** et autoriser les notifications.

## Configuration distante toujours obligatoire pour les notifications quand Messenger est fermé

- Appliquer la migration `site/supabase/migrations/20261121120000_messenger_push_subscriptions.sql` au projet Supabase.
- Déployer `site/supabase/functions/send-messenger-push`.
- Définir les secrets VAPID et `PUSH_WEBHOOK_SECRET` dans Supabase Edge Functions.
- Créer le Database Webhook `public.messages` / `INSERT` vers la fonction, avec l'en-tête secret attendu.
- Définir `VITE_WEB_PUSH_PUBLIC_KEY` dans les variables de build Vercel et redéployer.
- Tester avec deux appareils/comptes, écran verrouillé, Messenger fermé et permissions autorisées.

La clé VAPID publique est dans `messenger/.env.production`; la clé privée et le secret webhook ne doivent jamais être publiés dans GitHub, dans le ZIP de code ou dans une variable publique `VITE_*`.

## Limite importante : bulles flottantes Android

Une PWA peut afficher une notification système, une notification sur l'écran verrouillé et parfois un badge sur son icône. Elle ne peut pas garantir une **bulle flottante de conversation Android** qui reste au-dessus des autres applications comme les bulles de Facebook Messenger. Android réserve cette fonction aux applications natives qui implémentent les notifications de conversation/bubble, les raccourcis dynamiques et les autorisations Android requises. Cela demanderait un véritable paquet Android (APK/AAB) et une intégration native supplémentaire.

Aucune application Web ne peut garantir la livraison si l'utilisateur bloque les notifications, désactive les données, force l'arrêt du navigateur, active certaines restrictions d'économie d'énergie ou si le service push du fournisseur est indisponible. Les notifications en arrière-plan ne sont donc pas considérées comme activées avant le déploiement et les essais réels de Supabase et Vercel.

## Vérification

Les fichiers JavaScript inline, le service worker et les manifestes sont vérifiés syntaxiquement. La compilation complète Vite/TypeScript et le test sur deux téléphones doivent encore être exécutés dans un environnement avec les dépendances installées et après le déploiement distant.
