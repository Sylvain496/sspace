# SSPACE + SSPACE Messenger : intégration et notifications

## Liaison entre les deux applications

- Le réseau social et Messenger utilisent le même projet Supabase SIKX et la même clé publique `sb_publishable_`.
- Les deux interfaces utilisent les mêmes tables `profiles`, `conversations` et `messages` : aucun compte, profil ou historique parallèle n'est créé.
- Le bouton Messenger transmet la session Supabase au nouvel onglet via `postMessage`, avec vérification de l'origine et d'un nonce.
- Messenger écoute `private_message_notifications`, table créée par le déclencheur SSPACE et publiée dans `supabase_realtime`. Il ne dépend pas de l'activation Realtime de la table `messages`.
- Si la récupération de session dépasse 12 secondes, l'écran quitte l'état de chargement et affiche une erreur récupérable plutôt que de rester bloqué.

## Notifications push lorsque Messenger est fermé

Le code client et la fonction Edge sont préparés. L'activation distante nécessite les opérations suivantes dans le projet Supabase `sikxoyylihsigzirewmi` et dans Vercel. Elles ne peuvent pas être exécutées depuis cette archive sans accès administrateur au projet.

1. Dans Supabase SQL Editor, exécuter `site/supabase/SSPACE-MESSENGER-PUSH.sql`. La même création est aussi incluse comme migration `migrations/20261121120000_messenger_push_subscriptions.sql` pour les déploiements par migrations.
2. Dans le dossier `site/supabase`, déployer la fonction :
   `supabase functions deploy send-messenger-push --project-ref sikxoyylihsigzirewmi`
3. Ouvrir le fichier séparé `SSPACE-PUSH-SECRETS-PRIVE.txt` et exécuter la commande `supabase secrets set` qu'il contient. Ce fichier contient une clé privée VAPID et un secret webhook : le garder confidentiel, ne pas l'ajouter au dépôt GitHub ou à Vercel.
4. Dans Supabase > Database > Webhooks, créer un webhook :
   - table : `public.messages`
   - événement : `INSERT`
   - méthode : `POST`
   - URL : `https://sikxoyylihsigzirewmi.supabase.co/functions/v1/send-messenger-push`
   - en-tête HTTP : `x-push-secret` avec la valeur `PUSH_WEBHOOK_SECRET` du fichier privé
   - corps : payload standard du webhook Supabase, contenant l'objet `record`
5. La clé publique VAPID est dans `messenger/.env.production` sous `VITE_WEB_PUSH_PUBLIC_KEY`. Pour Vercel, ajouter la même valeur comme variable d'environnement de build `VITE_WEB_PUSH_PUBLIC_KEY`, puis redéployer.
6. Sur chaque téléphone, ouvrir SSPACE Messenger, choisir « Activer la sonnerie et les notifications » et accepter l'autorisation Android/navigateur.

Supabase fournit normalement `SUPABASE_URL` et `SUPABASE_SERVICE_ROLE_KEY` à la fonction Edge. La clé `service_role` ne doit jamais être copiée dans le client ou dans Vercel.

## Limites et tests indispensables

- Les notifications push après fermeture dépendent de l'exécution effective du webhook, de l'abonnement push du téléphone, du réseau et des réglages Android (économie d'énergie, silencieux, Ne pas déranger).
- Une sonnerie dans l'application ne garantit pas une sonnerie audible lorsque le téléphone est verrouillé; le son de notification dépend des réglages du système.
- Tester avec deux comptes distincts : ouvrir Messenger depuis SSPACE, envoyer un message depuis SSPACE, vérifier la conversation, le compteur non lu, la sonnerie, la notification en arrière-plan et le push après fermeture.
- La compilation n'a pas été confirmée dans cet environnement : l'installation des dépendances npm n'a pas abouti faute d'accès réseau. Les tests sur deux appareils et le déploiement distant restent à faire.
