import { createClient } from 'npm:@supabase/supabase-js@2';
import webpush from 'npm:web-push@3.6.7';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type' };
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  const secret = Deno.env.get('PUSH_WEBHOOK_SECRET');
  if (!secret || req.headers.get('x-push-secret') !== secret) return new Response('Unauthorized', { status: 401, headers: cors });

  try {
    const payload = await req.json();
    const message = payload.record ?? payload;
    if (!message?.id || !message?.conversation_id || !message?.sender_id) return new Response('Missing message record', { status: 400, headers: cors });

    const supabase = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const [{ data: conversation, error: conversationError }, { data: sender }] = await Promise.all([
      supabase.from('conversations').select('user_one,user_two').eq('id', message.conversation_id).single(),
      supabase.from('profiles').select('display_name,username').eq('id', message.sender_id).maybeSingle()
    ]);
    if (conversationError || !conversation) throw conversationError ?? new Error('Conversation not found');
    const recipientId = conversation.user_one === message.sender_id ? conversation.user_two : conversation.user_one;
    const { data: subscriptions, error } = await supabase.from('push_subscriptions').select('endpoint,subscription').eq('user_id', recipientId);
    if (error) throw error;
    if (!subscriptions?.length) return new Response(JSON.stringify({ sent: 0, reason: 'No push subscriptions' }), { headers: { ...cors, 'Content-Type': 'application/json' } });

    const publicKey = Deno.env.get('VAPID_PUBLIC_KEY')!;
    const privateKey = Deno.env.get('VAPID_PRIVATE_KEY')!;
    const subject = Deno.env.get('VAPID_SUBJECT') || 'mailto:admin@sspace.app';
    webpush.setVapidDetails(subject, publicKey, privateKey);
    const senderName = sender?.display_name || (sender?.username ? `@${sender.username}` : 'SSPACE');
    const body = String(message.body || 'Tu as reçu un nouveau message.').slice(0, 140);
    const { count: unreadCount } = await supabase.from('messages').select('id', { count: 'exact', head: true })
      .eq('conversation_id', message.conversation_id).neq('sender_id', recipientId).is('read_at', null);
    const notification = JSON.stringify({
      title: `Message de ${senderName}`,
      body,
      icon: '/messenger/icons/icon-192.png',
      badge: '/messenger/icons/icon-192.png',
      unreadCount: unreadCount ?? 1,
      tag: `sspace-message-${message.conversation_id}`, 
      url: `/messenger/?conversation=${encodeURIComponent(message.conversation_id)}`
    });

    const results = await Promise.all(subscriptions.map(async (row) => {
      try {
        await webpush.sendNotification(row.subscription, notification);
        return true;
      } catch (pushError) {
        const status = (pushError as { statusCode?: number }).statusCode;
        if (status === 404 || status === 410) await supabase.from('push_subscriptions').delete().eq('endpoint', row.endpoint);
        console.error('Web Push delivery failed:', status, pushError);
        return false;
      }
    }));
    return new Response(JSON.stringify({ sent: results.filter(Boolean).length, attempted: results.length }), { headers: { ...cors, 'Content-Type': 'application/json' } });
  } catch (error) {
    console.error(error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Push error' }), { status: 500, headers: { ...cors, 'Content-Type': 'application/json' } });
  }
});
