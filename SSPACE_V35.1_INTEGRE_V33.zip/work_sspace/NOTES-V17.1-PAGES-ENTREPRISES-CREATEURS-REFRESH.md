# SSPACE V17.1 — Pages entreprise/créateur et actualisation

- Ajout de « Mes pages » dans la colonne de navigation et le menu SSPACE.
- Deux types de pages : entreprise/commerce et créateur/artiste/influenceur.
- La page est automatiquement associée au membre connecté (`owner_id`) : aucune deuxième connexion ou compte externe n'est requis.
- Outils de personnalisation : nom, catégorie, slogan, description, logo, couverture, site Web, contact, thème et visibilité publique/brouillon.
- Espace de gestion par page, aperçu, modification et lien partageable `/?page=slug`.
- Publications de page stockées dans `business_page_posts`, séparées du fil d'accueil général (`posts`).
- RLS Supabase : pages publiques lisibles, pages privées visibles seulement par leur propriétaire; seules les personnes propriétaires peuvent modifier la page et publier dessus.
- Actualisation mobile par glissement vers le bas au sommet de l'écran; la vue active est rechargée.
- Schéma Supabase vérifié : `business_pages`, `business_page_posts`, `page_type` et index auteur présents. Les tables de prototype inutilisées ont été supprimées.
- Vérification JavaScript : `node --check` réussi. Le build complet du projet n'a pas été exécuté car les dépendances racine ne sont pas installées dans cet environnement.
