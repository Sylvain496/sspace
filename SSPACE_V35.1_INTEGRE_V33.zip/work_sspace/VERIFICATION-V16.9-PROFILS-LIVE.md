# SSPACE V16.9 — Profils LIVE, visites et réputation

## Fonctionnalités ajoutées

- Compteur de visiteurs uniques sur les profils personnels et publics.
- Notification SSPACE avec l'icône œil lorsqu'un membre consulte un profil.
- Anti-spam : un même visiteur ne déclenche pas plus d'une notification par profil sur une période de 24 heures; les visites sont néanmoins comptées dans le total de visiteurs uniques et le nombre de visites est conservé en base.
- Évaluation communautaire du contenu d'un membre avec pouce en l'air / pouce en bas.
- Un vote par membre et par profil; le membre peut modifier son vote.
- Calcul du pourcentage positif : votes positifs / total des votes × 100.
- Statistiques affichées juste sous la photo de couverture; le propriétaire voit aussi ses statistiques se rafraîchir lorsqu'une notification de visite arrive.
- Cliquer sur une notification de visite ouvre le profil du visiteur.

## Supabase

Migrations ajoutées :

- `20261122260000_profile_views_and_reputation.sql`
- `20261122261000_profile_views_fk_indexes.sql`

La première migration a été appliquée au projet Supabase `sikxoyylihsigzirewmi`. Vérification SQL effectuée : tables `profile_visits` et `profile_reputation_votes` présentes, RPC `profile_visit_record` et `profile_vote_cast` présentes, et contrainte de notification `profile_view` active. La seconde migration ajoute les index secondaires sur les colonnes de clés étrangères.

Les tables de détails restent inaccessibles directement aux rôles `anon` et `authenticated` (RLS activé, aucun accès direct accordé). Les opérations passent par les RPC qui vérifient `auth.uid()` et valident le profil cible et le vote. Les avertissements Supabase de type `RLS enabled no policy` sur ces deux tables sont donc intentionnels; les RPC exposent uniquement les statistiques agrégées et les opérations du membre connecté.

## Vérifications effectuées

- `node --check` réussi sur le JavaScript inline de `site/index.html`.
- La migration principale a été appliquée et l'existence des tables, RPC et contrainte de notification a été vérifiée dans Supabase.
- Les tests de navigation réels entre deux comptes et appareils restent à effectuer après déploiement Vercel; ils ne peuvent pas être certifiés depuis l'environnement de préparation.
