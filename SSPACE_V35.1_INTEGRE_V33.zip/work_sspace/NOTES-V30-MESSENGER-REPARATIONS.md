# SSPACE V30 — corrections Messenger, zoom et mémoire privée

## Corrections vérifiées
- Corrige le contrat SQL `messages`: le type `game_invite` était refusé par la contrainte existante et le lien `sspace-game:<UUID>` était bloqué par le contrôle HTTPS. Les deux contraintes acceptent maintenant explicitement les invitations de salle.
- Présence Realtime privée ajoutée au canal de salle. Le bouton Démarrer est réservé à l'hôte et reste désactivé tant que le deuxième joueur n'est pas réellement présent.
- Contrôles tactiles de direction, accélération, frein et nitro avec capture du pointeur.
- Bowling : alternance des joueurs, deux lancers par joueur, 10 frames, score, victoire/égalité corrigés.
- Zoom réglable dans l'interface Messenger (80–120 %) et zoom de la scène de jeu (100–160 %, retour Ajuster). La fenêtre de jeu reste bornée à la taille de l'écran.
- Mémoire : RPC propriétaire pour enregistrer/relire une backstory, extraction de mots-clés, suggestion hebdomadaire et événement associé si les mots-clés correspondent.
- Stockage des backstories dans `private.media_backstories`, schéma non accessible aux rôles anon/authenticated; les RPC vérifient le propriétaire du média. Les colonnes de compatibilité `backstory` et `keywords` sont ajoutées aux tables média mais les données privées ne sont pas stockées dedans.
- Cron Supabase enregistré chaque lundi à 03:00 UTC, en respectant `profiles.memories_enabled`.

## Limites fonctionnelles encore présentes
- Les trois jeux sont des jeux arcade en Canvas 2D avec rendu en perspective, pas des moteurs 3D WebGL. Street Racing et Kart Racing partagent encore le même moteur de course; leur différenciation visuelle et leurs circuits dédiés restent à faire.
- La course est simulée par l'hôte et les entrées du second joueur sont synchronisées par Realtime. Si l'hôte quitte la salle, la simulation ne migre pas automatiquement.
- Le bowling utilise un nombre de quilles calculé à partir de la puissance, pas une simulation physique de collisions. Le score de base est partagé mais les bonus officiels strike/spare ne sont pas encore implémentés.
- Le moteur de suggestions exploite les événements et un défi générique. Les tables de blogs et de clans correspondantes ne sont pas présentes dans le schéma Supabase actuellement consulté; le croisement blogs/clans n'est donc pas activé.
- L'interface mémoire demande l'UUID du média. La sélection directe depuis la galerie du réseau reste à intégrer.

## Validation
- Migrations appliquées sur le projet Supabase SIKX et objets vérifiés.
- Vérification des contraintes `messages_message_type_check` et `messages_link_url_check` : invitations acceptées.
- Vérification des politiques Realtime Broadcast/Presence limitées aux deux joueurs.
- Vérification des privilèges : `anon` et `authenticated` ne peuvent ni utiliser le schéma `private`, ni lire la table privée des backstories.
- Cron `sspace-memory-suggestions-weekly` vérifié, planifié `0 3 * * 1`.
- `npm install` a expiré et l'installation hors-ligne a échoué faute de cache. Donc `npm run build` et les tests réels entre deux appareils n'ont pas pu être validés. Le parseur TypeScript n'a signalé aucune erreur de syntaxe TS1xxx, mais la compilation complète reste non vérifiée.
