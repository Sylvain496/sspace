# SSPACE — préparer la fusion FRIRNN vers SIKX

## État du paquet

- SIKX reste le projet Supabase principal configuré dans `index.html`.
- Les migrations SSPACE déjà présentes dans `supabase/migrations/` sont conservées.
- Le fichier `supabase/FRIRNN_SIKX_MERGE_PREFLIGHT.sql` est un inventaire en lecture seule. Il sert à relever les différences réelles entre les deux bases.
- Aucun export FRIRNN n'était présent dans le ZIP reçu. Il serait dangereux de fabriquer des INSERT/UPDATE en devinant les tables, les colonnes, les identifiants ou les relations de FRIRNN.

## Procédure

1. Ouvrir le projet **FRIRNN** dans Supabase Dashboard > SQL Editor.
2. Exécuter `supabase/FRIRNN_SIKX_MERGE_PREFLIGHT.sql` et exporter les résultats des requêtes (CSV si possible).
3. Répéter exactement la même opération dans le projet **SIKX**.
4. Comparer les inventaires avant de produire une migration de transfert adaptée aux vrais schémas.
5. Sauvegarder les deux projets avant toute écriture. Ne pas supprimer FRIRNN tant que comptes, relations, messages et fichiers Storage n'ont pas été vérifiés dans SIKX.

## Important : limites du transfert

- Ce script ne transfère aucune donnée et ne change pas la base.
- Les utilisateurs `auth.users` et leurs méthodes de connexion nécessitent une procédure dédiée; copier seulement les tables applicatives ne migre pas les comptes Auth.
- Les fichiers Storage doivent être copiés physiquement et leurs chemins/URLs référencés doivent être réconciliés.
- Les IDs UUID et les clés étrangères doivent être préservés ou remappés de façon cohérente.
- Ne jamais coller dans une conversation une clé `service_role`, un mot de passe ou un secret OAuth.

La migration finale ne peut être générée correctement qu'après réception des deux inventaires et, si nécessaire, des exports de données non sensibles.
