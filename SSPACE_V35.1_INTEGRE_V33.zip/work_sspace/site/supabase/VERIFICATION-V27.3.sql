-- SSPACE V27.3 — vérification post-migration (lecture seule)
-- Exécuter dans le SQL Editor du projet Supabase SSPACE.
select expected.object_name,
       case when found.object_name is null then 'MANQUANT' else 'OK' end as status
from (values
 ('table: public.sspace_clans'),
 ('table: public.sspace_clan_members'),
 ('table: public.sspace_clan_messages'),
 ('table: public.sspace_blog_articles'),
 ('table: public.sspace_blog_comments'),
 ('table: public.sspace_blog_comment_votes'),
 ('table: public.sspace_music_tracks'),
 ('table: public.sspace_challenges'),
 ('table: public.sspace_challenge_progress'),
 ('table: public.sspace_daily_activity'),
 ('table: public.sspace_memory_items'),
 ('view: public.sspace_blog_top100'),
 ('function: public.sspace_blog_increment_view(uuid)'),
 ('bucket: sspace-community-media')
) as expected(object_name)
left join lateral (
 select expected.object_name where
 case
  when expected.object_name like 'table:%' then to_regclass(trim(substr(expected.object_name,7))) is not null
  when expected.object_name like 'view:%' then to_regclass(trim(substr(expected.object_name,6))) is not null
  when expected.object_name like 'function:%' then to_regprocedure(trim(substr(expected.object_name,10))) is not null
  when expected.object_name like 'bucket:%' then exists(select 1 from storage.buckets b where b.id=trim(substr(expected.object_name,8)))
  else false
 end
) found on true
order by expected.object_name;

-- Vérifie l'abonnement du chat de Clan à Realtime.
select exists (
 select 1 from pg_publication_tables
 where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_clan_messages'
) as clan_chat_realtime_enabled;

-- Vérifie que les membres ne peuvent s'inscrire qu'avec le rôle membre.
select pg_get_expr(polwithcheck, polrelid) as clan_member_join_check
from pg_policy
where polname='clan_member_join' and polrelid='public.sspace_clan_members'::regclass;
