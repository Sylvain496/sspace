-- SSPACE — signalisation sécurisée des appels audio et vidéo privés.
-- À exécuter sur le projet Supabase SIKX indiqué dans index.html.

create table if not exists public.call_signals (
  id uuid primary key default gen_random_uuid(),
  call_id uuid not null,
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('invite','accept','reject','busy','hangup','offer','answer','ice')),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  constraint call_signals_no_self_call check (sender_id <> receiver_id)
);

create index if not exists call_signals_receiver_created_idx
  on public.call_signals (receiver_id, created_at desc);
create index if not exists call_signals_call_id_idx
  on public.call_signals (call_id);

alter table public.call_signals enable row level security;

revoke all on table public.call_signals from anon, public;
grant select, insert on table public.call_signals to authenticated;

drop policy if exists "Call participants read their signals" on public.call_signals;
create policy "Call participants read their signals"
  on public.call_signals for select to authenticated
  using ((select auth.uid()) = sender_id or (select auth.uid()) = receiver_id);

drop policy if exists "Friends send private call signals" on public.call_signals;
create policy "Friends send private call signals"
  on public.call_signals for insert to authenticated
  with check (
    (select auth.uid()) = sender_id
    and sender_id <> receiver_id
    and exists (
      select 1
      from public.friend_requests fr
      where fr.status = 'accepted'
        and (
          (fr.sender_id = sender_id and fr.receiver_id = receiver_id)
          or
          (fr.sender_id = receiver_id and fr.receiver_id = sender_id)
        )
    )
  );

-- Active le flux Realtime utilisé par le client SSPACE.
do $$
begin
  alter publication supabase_realtime add table public.call_signals;
exception
  when duplicate_object then null;
  when undefined_object then
    raise notice 'Publication supabase_realtime absente : active Realtime pour public.call_signals dans le tableau de bord Supabase.';
end;
$$;
