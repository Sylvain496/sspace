-- Cover the foreign keys identified by Supabase's performance advisor.
CREATE INDEX IF NOT EXISTS content_reports_reporter_id_idx ON public.content_reports(reporter_id);
CREATE INDEX IF NOT EXISTS groups_created_by_idx ON public.groups(created_by);
CREATE INDEX IF NOT EXISTS hidden_posts_post_id_idx ON public.hidden_posts(post_id);
