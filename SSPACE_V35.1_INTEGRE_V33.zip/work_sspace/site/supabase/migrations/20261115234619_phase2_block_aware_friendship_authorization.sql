-- All social read/write policies that call this function now honor blocks in either direction.
-- The caller must be one of the two users; the definer context is limited to this boolean check.
CREATE OR REPLACE FUNCTION private.are_accepted_friends(p_user_one uuid, p_user_two uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = '' AS $$
  SELECT (SELECT auth.uid()) IN (p_user_one, p_user_two)
    AND EXISTS (SELECT 1 FROM public.friend_requests fr WHERE fr.status='accepted' AND
      ((fr.sender_id=p_user_one AND fr.receiver_id=p_user_two) OR (fr.sender_id=p_user_two AND fr.receiver_id=p_user_one)))
    AND NOT EXISTS (SELECT 1 FROM public.user_blocks b WHERE
      (b.blocker_id=p_user_one AND b.blocked_id=p_user_two) OR (b.blocker_id=p_user_two AND b.blocked_id=p_user_one));
$$;
REVOKE ALL ON FUNCTION private.are_accepted_friends(uuid,uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.are_accepted_friends(uuid,uuid) TO authenticated;
