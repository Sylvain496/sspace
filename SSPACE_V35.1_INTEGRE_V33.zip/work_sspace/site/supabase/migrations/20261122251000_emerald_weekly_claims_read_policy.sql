-- Permet à chaque membre de consulter uniquement ses propres récompenses hebdomadaires.
grant select on public.emerald_weekly_claims to authenticated;
drop policy if exists "Members read own weekly gem claims" on public.emerald_weekly_claims;
create policy "Members read own weekly gem claims"
on public.emerald_weekly_claims for select to authenticated
using ((select auth.uid()) = user_id);
