-- Add creator/business distinction to SSPACE pages.
alter table public.business_pages add column if not exists page_type text not null default 'business';
alter table public.business_pages drop constraint if exists business_pages_page_type_check;
alter table public.business_pages add constraint business_pages_page_type_check check (page_type in ('business','creator'));
create index if not exists business_pages_type_owner_idx on public.business_pages(page_type, owner_id);
