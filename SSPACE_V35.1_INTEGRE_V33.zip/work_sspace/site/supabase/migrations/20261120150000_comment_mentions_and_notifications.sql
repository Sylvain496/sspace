-- SSPACE: mentions dans les commentaires et notifications aux membres tagués.
-- À exécuter une seule fois dans le SQL Editor du projet SIKX.

create table if not exists public.comment_mentions (
  id uuid primary key default gen_random_uuid(),
  comment_id uuid not null references public.comments(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  mentioned_user_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  constraint comment_mentions_unique unique (comment_id, mentioned_user_id),
  constraint comment_mentions_not_self check (mentioned_user_id <> actor_id)
);

create index if not exists comment_mentions_recipient_created_idx
  on public.comment_mentions (mentioned_user_id, created_at desc);
create index if not exists comment_mentions_comment_idx
  on public.comment_mentions (comment_id);

alter table public.comment_mentions enable row level security;

drop policy if exists "comment mentions visible to participants" on public.comment_mentions;
create policy "comment mentions visible to participants"
  on public.comment_mentions for select to authenticated
  using (mentioned_user_id = auth.uid() or actor_id = auth.uid());

drop policy if exists "members can create own comment mentions" on public.comment_mentions;
create policy "members can create own comment mentions"
  on public.comment_mentions for insert to authenticated
  with check (
    actor_id = auth.uid()
    and exists (
      select 1 from public.comments c
      where c.id = comment_id and c.user_id = auth.uid() and c.post_id = post_id
    )
  );

create or replace function public.notify_comment_mention()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  actor_name text;
begin
  select coalesce(display_name, username, 'Un membre')
    into actor_name from public.profiles where id = new.actor_id;

  insert into public.user_notifications
    (user_id, actor_id, notif_type, preview_text, entity_id, is_read)
  values
    (new.mentioned_user_id, new.actor_id, 'mention',
     actor_name || ' t’a identifié dans un commentaire.', new.comment_id, false);
  return new;
end;
$$;

drop trigger if exists trg_notify_comment_mention on public.comment_mentions;
create trigger trg_notify_comment_mention
after insert on public.comment_mentions
for each row execute function public.notify_comment_mention();

-- Le compteur du cœur additionne les notifications non lues et les demandes d'amis en attente côté interface.
