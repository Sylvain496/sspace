-- Explicit least-privilege grants. Remove Supabase default broad client grants on new tables.
REVOKE ALL PRIVILEGES ON TABLE public.user_blocks FROM anon, authenticated, PUBLIC;
GRANT SELECT, INSERT, DELETE ON TABLE public.user_blocks TO authenticated;
REVOKE ALL PRIVILEGES ON TABLE public.hidden_posts FROM anon, authenticated, PUBLIC;
GRANT SELECT, INSERT, DELETE ON TABLE public.hidden_posts TO authenticated;
REVOKE ALL PRIVILEGES ON TABLE public.content_reports FROM anon, authenticated, PUBLIC;
GRANT INSERT, SELECT ON TABLE public.content_reports TO authenticated;
REVOKE ALL PRIVILEGES ON TABLE public.store_catalog FROM anon, authenticated, PUBLIC;
GRANT SELECT ON TABLE public.store_catalog TO authenticated;
REVOKE UPDATE ON TABLE public.friend_requests, public.group_members, public.user_notifications FROM anon, authenticated, PUBLIC;
GRANT UPDATE (status) ON TABLE public.friend_requests TO authenticated;
GRANT UPDATE (status) ON TABLE public.group_members TO authenticated;
GRANT UPDATE (is_read) ON TABLE public.user_notifications TO authenticated;
REVOKE TRUNCATE, TRIGGER, REFERENCES ON TABLE public.user_blocks, public.hidden_posts, public.content_reports, public.store_catalog, public.friend_requests, public.group_members, public.user_notifications FROM anon, authenticated, PUBLIC;
