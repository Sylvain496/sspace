-- SSPACE v7 — DÉJÀ APPLIQUÉE au projet Supabase « Sspace » (nom : sspace_store_free_oauth_names). Trace de référence : ne pas rejouer.

-- 1) Thèmes de discussion : autoriser les 5 thèmes animés de la boutique
alter table public.conversation_settings drop constraint if exists conversation_settings_decor_id_check;
alter table public.conversation_settings add constraint conversation_settings_decor_id_check
  check (decor_id = any (array[
    'aurora-night','ocean-glass','sunset-violet','forest-dream','pixel-pop','minimal-mist','galaxy-drift','cherry-blossom','neon-city','paper-stars',
    'premium-fireworks','premium-cosmic','premium-rain','premium-neon-pulse','premium-magic-portal',
    'aurora-glow','crystal-cave','ocean-depths','lavender-dream','solar-flare','emerald-wave',
    'cyber-pulse','nebula-drift','matrix-grid','aurora-storm','void-starlight']::text[]));

-- 2) Comptes créés par Google : reprendre le vrai nom et la photo au lieu de « Nouveau membre »
create or replace function private.handle_new_user()
returns trigger language plpgsql security definer set search_path to '' as $function$
declare v_name text; v_avatar text;
begin
  v_name := left(coalesce(
    nullif(btrim(new.raw_user_meta_data ->> 'display_name'), ''),
    nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''),
    nullif(btrim(new.raw_user_meta_data ->> 'name'), ''),
    nullif(split_part(coalesce(new.email, ''), '@', 1), ''),
    'Nouveau membre'), 60);
  v_avatar := coalesce(nullif(new.raw_user_meta_data ->> 'avatar_url', ''), nullif(new.raw_user_meta_data ->> 'picture', ''));
  if v_avatar is not null and (v_avatar !~ '^https://' or length(v_avatar) > 2048) then v_avatar := null; end if;
  insert into public.profiles (id, username, username_confirmed, display_name, avatar_url)
  values (new.id, 'membre_' || substr(replace(new.id::text, '-', ''), 1, 10), false, v_name, v_avatar)
  on conflict (id) do nothing;
  return new;
end; $function$;

-- 3) Rattrapage des profils restés à « Nouveau membre » (nom lu dans le compte de connexion)
update public.profiles p set display_name = left(coalesce(
      nullif(btrim(u.raw_user_meta_data ->> 'display_name'), ''), nullif(btrim(u.raw_user_meta_data ->> 'full_name'), ''),
      nullif(btrim(u.raw_user_meta_data ->> 'name'), ''), nullif(split_part(coalesce(u.email, ''), '@', 1), '')), 60)
from auth.users u
where u.id = p.id and p.display_name = 'Nouveau membre'
  and coalesce(nullif(btrim(u.raw_user_meta_data ->> 'display_name'), ''), nullif(btrim(u.raw_user_meta_data ->> 'full_name'), ''), nullif(btrim(u.raw_user_meta_data ->> 'name'), ''), nullif(split_part(coalesce(u.email, ''), '@', 1), '')) is not null;

-- 4) Boutique : tout gratuit + 5 décors de discussion intégrés + 10 décors de profil (voir la base pour le détail des lignes)
update public.store_catalog set is_premium = false, active = true;
-- (insertion de 15 lignes « on conflict (id) do update » : premium-fireworks, premium-cosmic, premium-rain, premium-neon-pulse, premium-magic-portal,
--  profile-premium-flame/cosmic/rain/prism/royal, profile-theme-aurora-glow/oasis/lavender/emerald/starlight)
