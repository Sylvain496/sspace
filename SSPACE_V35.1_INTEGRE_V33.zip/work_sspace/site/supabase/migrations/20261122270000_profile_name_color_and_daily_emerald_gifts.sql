-- SSPACE : couleur personnalisée du nom de profil et limite de cadeaux quotidienne.
-- À exécuter dans Supabase SQL Editor.

alter table public.profiles
  add column if not exists username_color text not null default '#000000';

alter table public.profiles
  drop constraint if exists profiles_username_color_check;
alter table public.profiles
  add constraint profiles_username_color_check
  check (username_color ~ '^#[0-9A-Fa-f]{6}$');

-- Un même expéditeur peut offrir au même destinataire au maximum une gemme
-- par jour (heure de Montréal). La gemme est ajoutée si le destinataire ne
-- la possède pas déjà. Le donneur conserve sa gemme, comme dans le système actuel.
create or replace function public.emerald_send(p_recipient uuid, p_emerald int, p_message text default '')
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  msg text := left(btrim(coalesce(p_message, '')), 200);
  nm text;
  gid uuid;
  n int;
  day_start timestamptz := date_trunc('day', now() at time zone 'America/Toronto') at time zone 'America/Toronto';
begin
  if me is null then raise exception 'Connexion requise'; end if;
  if p_recipient is null or p_recipient = me then raise exception 'Choisis un autre membre.'; end if;
  select name into nm from public.emerald_catalog where id = p_emerald;
  if nm is null then raise exception 'Émeraude inconnue.'; end if;
  if not private.are_friends(me, p_recipient) then raise exception 'Tu ne peux envoyer des émeraudes qu’à tes amis.'; end if;
  if public.album_users_blocked(me, p_recipient) then raise exception 'Envoi impossible.'; end if;

  -- Sérialise les envois vers cette personne pour empêcher deux clics simultanés.
  perform pg_advisory_xact_lock(hashtextextended(me::text || ':' || p_recipient::text, 0));
  if exists (
    select 1 from public.emerald_gifts g
    where g.sender_id = me and g.recipient_id = p_recipient
      and g.created_at >= day_start
      and g.created_at < day_start + interval '1 day'
  ) then
    raise exception 'Tu as déjà offert une gemme à cette personne aujourd’hui. Reviens demain.';
  end if;

  if not exists (select 1 from public.emerald_collection where user_id = me and emerald_id = p_emerald) then
    raise exception 'Tu ne possèdes pas encore cette gemme.';
  end if;
  insert into public.emerald_collection(user_id, emerald_id, source)
    values (p_recipient, p_emerald, 'gift') on conflict do nothing;
  get diagnostics n = row_count;
  if n = 0 then raise exception 'Cette personne possède déjà cette gemme.'; end if;

  insert into public.emerald_gifts(sender_id, recipient_id, emerald_id, message)
    values (me, p_recipient, p_emerald, msg) returning id into gid;
  update public.emerald_requests set status = 'filled', filled_at = now()
    where requester_id = p_recipient and emerald_id = p_emerald and status = 'open';
  insert into public.user_notifications(user_id, actor_id, notif_type, entity_id, preview_text)
    values (p_recipient, me, 'emerald_gift', gid,
      't’a envoyé l’émeraude « ' || nm || ' » 💚 Elle est dans ta bibliothèque !' || case when msg <> '' then ' « ' || msg || ' »' else '' end);
  return jsonb_build_object('ok', true, 'emerald_id', p_emerald);
end $$;
revoke all on function public.emerald_send(uuid, int, text) from public, anon;
grant execute on function public.emerald_send(uuid, int, text) to authenticated;
