-- SSPACE : missions hebdomadaires d'émeraudes. À exécuter après 20261122240000_emerald_library.sql.
create table if not exists public.emerald_weekly_claims (
  user_id uuid not null references public.profiles(id) on delete cascade,
  week_start date not null,
  mission_key text not null,
  emerald_id smallint references public.emerald_catalog(id),
  claimed_at timestamptz not null default now(),
  primary key (user_id, week_start, mission_key)
);
alter table public.emerald_weekly_claims enable row level security;
revoke all on public.emerald_weekly_claims from anon, authenticated;

create or replace function public.emerald_weekly_mission_status()
returns jsonb language plpgsql stable security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  wk date := date_trunc('week', now() at time zone 'America/Toronto')::date;
  posts_count int := 0;
  likes_count int := 0;
  reward int;
  claimed boolean := false;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  select count(*)::int into posts_count from public.posts p
   where p.user_id=me and p.image_url is not null and btrim(p.image_url)<>''
     and p.created_at >= (wk::timestamp at time zone 'America/Toronto')
     and p.created_at < ((wk+7)::timestamp at time zone 'America/Toronto');
  select count(*)::int into likes_count from public.likes l
   join public.posts p on p.id=l.post_id
   where p.user_id=me and p.image_url is not null and btrim(p.image_url)<>''
     and p.created_at >= (wk::timestamp at time zone 'America/Toronto')
     and p.created_at < ((wk+7)::timestamp at time zone 'America/Toronto')
     and l.user_id <> me;
  select exists(select 1 from public.emerald_weekly_claims c where c.user_id=me and c.week_start=wk and c.mission_key='double_photo') into claimed;
  return jsonb_build_object('week_start',wk,'posts',posts_count,'likes',likes_count,'complete',posts_count>=2 and likes_count>=1,'claimed',claimed,'mission_key','double_photo');
end $$;
revoke all on function public.emerald_weekly_mission_status() from public, anon;
grant execute on function public.emerald_weekly_mission_status() to authenticated;

create or replace function public.emerald_weekly_mission_claim()
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  me uuid := (select auth.uid());
  wk date := date_trunc('week', now() at time zone 'America/Toronto')::date;
  st jsonb;
  reward int;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  st := public.emerald_weekly_mission_status();
  if coalesce((st->>'complete')::boolean,false)=false then raise exception 'Mission non terminée : publie 2 images et reçois au moins 1 J’aime.'; end if;
  if coalesce((st->>'claimed')::boolean,false) then raise exception 'Récompense déjà récupérée cette semaine.'; end if;
  select c.id into reward from public.emerald_catalog c
   where not exists(select 1 from public.emerald_collection x where x.user_id=me and x.emerald_id=c.id)
   order by random() limit 1;
  if reward is null then raise exception 'Tu possèdes déjà les 80 émeraudes !'; end if;
  insert into public.emerald_weekly_claims(user_id,week_start,mission_key,emerald_id)
   values(me,wk,'double_photo',reward);
  insert into public.emerald_collection(user_id,emerald_id,source) values(me,reward,'pickup') on conflict do nothing;
  return jsonb_build_object('ok',true,'emerald_id',reward);
end $$;
revoke all on function public.emerald_weekly_mission_claim() from public, anon;
grant execute on function public.emerald_weekly_mission_claim() to authenticated;
