-- SSPACE security hardening: a receiver may change only the request status.
-- Prevents authenticated clients from rewriting sender_id/receiver_id or timestamps
-- while accepting/declining a friend request. Safe to re-run.

REVOKE UPDATE ON TABLE public.friend_requests FROM authenticated;
GRANT UPDATE (status) ON TABLE public.friend_requests TO authenticated;

-- Keep the row-level policy explicit and limited to the intended state transition.
DROP POLICY IF EXISTS "Receivers respond to friend requests" ON public.friend_requests;
CREATE POLICY "Receivers respond to friend requests"
  ON public.friend_requests
  FOR UPDATE
  TO authenticated
  USING (
    (SELECT auth.uid()) = receiver_id
    AND status = 'pending'
  )
  WITH CHECK (
    (SELECT auth.uid()) = receiver_id
    AND status IN ('accepted', 'declined')
  );
