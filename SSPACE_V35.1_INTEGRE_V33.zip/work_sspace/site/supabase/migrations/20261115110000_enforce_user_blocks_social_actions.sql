-- SSPACE: enforce user blocks across social entry points.
-- A block prevents new friend requests, conversations and messages in either direction.
-- Existing conversation history is retained; this migration does not delete user data.

CREATE SCHEMA IF NOT EXISTS private;

-- Create the block list before installing triggers that reference it.
-- This keeps a fresh migration run valid from an empty project.
CREATE TABLE IF NOT EXISTS public.user_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_blocks_not_self CHECK (blocker_id <> blocked_id),
  CONSTRAINT user_blocks_unique UNIQUE (blocker_id, blocked_id)
);
CREATE INDEX IF NOT EXISTS user_blocks_blocker_idx ON public.user_blocks(blocker_id);
CREATE INDEX IF NOT EXISTS user_blocks_blocked_idx ON public.user_blocks(blocked_id);
ALTER TABLE public.user_blocks ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.user_blocks FROM anon, authenticated, PUBLIC;
GRANT SELECT, INSERT, DELETE ON TABLE public.user_blocks TO authenticated;
DROP POLICY IF EXISTS "Users read own blocks" ON public.user_blocks;
CREATE POLICY "Users read own blocks" ON public.user_blocks FOR SELECT TO authenticated USING ((SELECT auth.uid()) = blocker_id);
DROP POLICY IF EXISTS "Users add own blocks" ON public.user_blocks;
CREATE POLICY "Users add own blocks" ON public.user_blocks FOR INSERT TO authenticated WITH CHECK ((SELECT auth.uid()) = blocker_id);
DROP POLICY IF EXISTS "Users remove own blocks" ON public.user_blocks;
CREATE POLICY "Users remove own blocks" ON public.user_blocks FOR DELETE TO authenticated USING ((SELECT auth.uid()) = blocker_id);


CREATE OR REPLACE FUNCTION private.reject_blocked_friend_request()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public.user_blocks b
    WHERE (b.blocker_id = NEW.sender_id AND b.blocked_id = NEW.receiver_id)
       OR (b.blocker_id = NEW.receiver_id AND b.blocked_id = NEW.sender_id)
  ) THEN
    RAISE EXCEPTION 'Cette action est impossible : une relation de blocage existe entre ces comptes.'
      USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION private.reject_blocked_conversation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM public.user_blocks b
    WHERE (b.blocker_id = NEW.user_one AND b.blocked_id = NEW.user_two)
       OR (b.blocker_id = NEW.user_two AND b.blocked_id = NEW.user_one)
  ) THEN
    RAISE EXCEPTION 'Cette action est impossible : une relation de blocage existe entre ces comptes.'
      USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION private.reject_blocked_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_user_one uuid;
  v_user_two uuid;
BEGIN
  SELECT c.user_one, c.user_two
    INTO v_user_one, v_user_two
  FROM public.conversations c
  WHERE c.id = NEW.conversation_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Conversation introuvable.' USING ERRCODE = '42501';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.user_blocks b
    WHERE (b.blocker_id = v_user_one AND b.blocked_id = v_user_two)
       OR (b.blocker_id = v_user_two AND b.blocked_id = v_user_one)
  ) THEN
    RAISE EXCEPTION 'Envoi impossible : une relation de blocage existe entre ces comptes.'
      USING ERRCODE = '42501';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION private.reject_blocked_friend_request() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.reject_blocked_conversation() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.reject_blocked_message() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS reject_blocked_friend_request ON public.friend_requests;
CREATE TRIGGER reject_blocked_friend_request
  BEFORE INSERT ON public.friend_requests
  FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_friend_request();

DROP TRIGGER IF EXISTS reject_blocked_conversation ON public.conversations;
CREATE TRIGGER reject_blocked_conversation
  BEFORE INSERT ON public.conversations
  FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_conversation();

DROP TRIGGER IF EXISTS reject_blocked_message ON public.messages;
CREATE TRIGGER reject_blocked_message
  BEFORE INSERT ON public.messages
  FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_message();
