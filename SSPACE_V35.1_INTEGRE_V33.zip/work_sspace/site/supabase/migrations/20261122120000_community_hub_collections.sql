-- SSPACE Community Hub + collections. Apply through Supabase SQL editor/migrations.
create table if not exists public.sspace_collectibles (
 id text primary key, name text not null, category text not null check(category in ('embleme','accessoire','tresor','saisonnier')),
 description text not null default '', rarity text not null default 'commun'
);
insert into public.sspace_collectibles(id,name,category,description,rarity) values
 ('badge-etoile','Étoile SSPACE','embleme','Un emblème lumineux pour les premiers membres.','commun'),
 ('badge-comete','Comète','embleme','Un emblème rare qui traverse le fil.','rare'),
 ('lunettes-neon','Lunettes néon','accessoire','Un accessoire éclatant.','commun'),
 ('couronne-or','Couronne dorée','accessoire','Une couronne prestigieuse.','epique'),
 ('coffre-cosmos','Trésor cosmique','tresor','Un petit trésor venu de l’espace.','rare'),
 ('flocon-hiver','Flocon d’hiver','saisonnier','Une pièce saisonnière.','saisonnier')
on conflict(id) do nothing;
create table if not exists public.sspace_collection_ownership (
 user_id uuid not null references auth.users(id) on delete cascade,
 collectible_id text not null references public.sspace_collectibles(id), copies integer not null default 1 check(copies>=1),
 acquired_at timestamptz not null default now(), primary key(user_id,collectible_id)
);
create table if not exists public.sspace_collection_requests (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 collectible_id text not null references public.sspace_collectibles(id), note text not null default '' check(char_length(note)<=180),
 status text not null default 'open' check(status in ('open','fulfilled','cancelled')), created_at timestamptz not null default now()
);
create table if not exists public.sspace_collection_gifts (
 id uuid primary key default gen_random_uuid(), sender_id uuid not null references auth.users(id), recipient_id uuid not null references auth.users(id),
 collectible_id text not null references public.sspace_collectibles(id), created_at timestamptz not null default now(), check(sender_id<>recipient_id)
);
create table if not exists public.sspace_community_messages (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 body text not null check(char_length(body) between 1 and 1000), created_at timestamptz not null default now()
);
do $$ begin
 if not exists(select 1 from pg_constraint where conname='sspace_ownership_profile_fk') then alter table public.sspace_collection_ownership add constraint sspace_ownership_profile_fk foreign key(user_id) references public.profiles(id) on delete cascade; end if;
 if not exists(select 1 from pg_constraint where conname='sspace_requests_profile_fk') then alter table public.sspace_collection_requests add constraint sspace_requests_profile_fk foreign key(user_id) references public.profiles(id) on delete cascade; end if;
 if not exists(select 1 from pg_constraint where conname='sspace_gifts_sender_profile_fk') then alter table public.sspace_collection_gifts add constraint sspace_gifts_sender_profile_fk foreign key(sender_id) references public.profiles(id) on delete cascade; end if;
 if not exists(select 1 from pg_constraint where conname='sspace_gifts_recipient_profile_fk') then alter table public.sspace_collection_gifts add constraint sspace_gifts_recipient_profile_fk foreign key(recipient_id) references public.profiles(id) on delete cascade; end if;
 if not exists(select 1 from pg_constraint where conname='sspace_messages_profile_fk') then alter table public.sspace_community_messages add constraint sspace_messages_profile_fk foreign key(user_id) references public.profiles(id) on delete cascade; end if;
end $$;
create index if not exists sspace_community_messages_created_idx on public.sspace_community_messages(created_at desc);
create index if not exists sspace_collection_requests_open_idx on public.sspace_collection_requests(status,created_at desc);

alter table public.sspace_collectibles enable row level security;
alter table public.sspace_collection_ownership enable row level security;
alter table public.sspace_collection_requests enable row level security;
alter table public.sspace_collection_gifts enable row level security;
alter table public.sspace_community_messages enable row level security;
grant select on public.sspace_collectibles to authenticated;
grant select on public.sspace_collection_ownership, public.sspace_collection_requests, public.sspace_collection_gifts, public.sspace_community_messages to authenticated;
grant insert on public.sspace_community_messages, public.sspace_collection_requests to authenticated;
drop policy if exists "catalogue visible" on public.sspace_collectibles;
create policy "catalogue visible" on public.sspace_collectibles for select to authenticated using(true);
drop policy if exists "collection visible to members" on public.sspace_collection_ownership;
create policy "collection visible to members" on public.sspace_collection_ownership for select to authenticated using(true);
drop policy if exists "requests visible to members" on public.sspace_collection_requests;
create policy "requests visible to members" on public.sspace_collection_requests for select to authenticated using(true);
drop policy if exists "members create own requests" on public.sspace_collection_requests;
create policy "members create own requests" on public.sspace_collection_requests for insert to authenticated with check(user_id=(select auth.uid()));
drop policy if exists "gift history visible to involved" on public.sspace_collection_gifts;
create policy "gift history visible to involved" on public.sspace_collection_gifts for select to authenticated using(sender_id=(select auth.uid()) or recipient_id=(select auth.uid()));
drop policy if exists "community messages readable" on public.sspace_community_messages;
create policy "community messages readable" on public.sspace_community_messages for select to authenticated using(true);
drop policy if exists "members post own community messages" on public.sspace_community_messages;
create policy "members post own community messages" on public.sspace_community_messages for insert to authenticated with check(user_id=(select auth.uid()));

create or replace function public.sspace_give_collectible(p_recipient uuid,p_collectible text)
returns void language plpgsql security definer set search_path='' as $$
declare v_sender uuid := auth.uid(); v_copies int; v_owned boolean;
begin
 if v_sender is null or p_recipient is null or p_recipient=v_sender then raise exception 'Destinataire invalide.'; end if;
 perform pg_advisory_xact_lock(hashtextextended(v_sender::text,0));
 select copies into v_copies from public.sspace_collection_ownership where user_id=v_sender and collectible_id=p_collectible for update;
 if coalesce(v_copies,0)<2 then raise exception 'Il faut posséder un double pour offrir cet objet.'; end if;
 select exists(select 1 from public.sspace_collection_ownership where user_id=p_recipient and collectible_id=p_collectible) into v_owned;
 if v_owned then raise exception 'Cette personne possède déjà cet objet.'; end if;
 if (select count(distinct recipient_id) from public.sspace_collection_gifts where sender_id=v_sender and created_at>now()-interval '24 hours')>=3
   and not exists(select 1 from public.sspace_collection_gifts where sender_id=v_sender and recipient_id=p_recipient and created_at>now()-interval '24 hours')
 then raise exception 'Limite atteinte : maximum 3 membres aidés par période de 24 h.'; end if;
 update public.sspace_collection_ownership set copies=copies-1 where user_id=v_sender and collectible_id=p_collectible;
 insert into public.sspace_collection_ownership(user_id,collectible_id,copies) values(p_recipient,p_collectible,1);
 insert into public.sspace_collection_gifts(sender_id,recipient_id,collectible_id) values(v_sender,p_recipient,p_collectible);
 update public.sspace_collection_requests set status='fulfilled' where user_id=p_recipient and collectible_id=p_collectible and status='open';
end; $$;
revoke all on function public.sspace_give_collectible(uuid,text) from public, anon;
grant execute on function public.sspace_give_collectible(uuid,text) to authenticated;

create or replace function public.sspace_award_starter_collectible()
returns trigger language plpgsql security definer set search_path='' as $$
declare v_item text;
begin
 select id into v_item from public.sspace_collectibles order by random() limit 1;
 if v_item is not null then insert into public.sspace_collection_ownership(user_id,collectible_id,copies) values(new.id,v_item,1) on conflict do nothing; end if;
 return new;
end; $$;
drop trigger if exists sspace_new_member_starter_collectible on public.profiles;
create trigger sspace_new_member_starter_collectible after insert on public.profiles for each row execute function public.sspace_award_starter_collectible();

do $$ begin
 if exists(select 1 from pg_publication where pubname='supabase_realtime') then
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_community_messages') then alter publication supabase_realtime add table public.sspace_community_messages; end if;
  if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_collection_requests') then alter publication supabase_realtime add table public.sspace_collection_requests; end if;
 end if;
end $$;
