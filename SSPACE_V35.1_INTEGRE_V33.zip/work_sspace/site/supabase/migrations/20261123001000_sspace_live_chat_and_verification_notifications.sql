-- SSPACE V27.1 — salon public temps réel + notifications de vérification.
-- À exécuter une fois dans le projet Supabase avant d'utiliser SSPACE LIVE.

create table if not exists public.sspace_live_chat_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 500),
  message_type text not null default 'text' check (message_type in ('text','gif')),
  created_at timestamptz not null default now()
);
create index if not exists sspace_live_chat_messages_created_idx
  on public.sspace_live_chat_messages(created_at desc);
create index if not exists sspace_live_chat_messages_user_idx
  on public.sspace_live_chat_messages(user_id, created_at desc);

alter table public.sspace_live_chat_messages enable row level security;
drop policy if exists "SSPACE LIVE members read messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE members read messages"
  on public.sspace_live_chat_messages for select to authenticated using (true);
drop policy if exists "SSPACE LIVE members send own messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE members send own messages"
  on public.sspace_live_chat_messages for insert to authenticated
  with check (auth.uid() = user_id and char_length(content) between 1 and 500
    and (message_type <> 'gif' or content like 'https://media%.giphy.com/%' or content like 'https://i.giphy.com/%' or content like 'https://media.tenor.com/%'));
drop policy if exists "SSPACE LIVE authors delete own messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE authors delete own messages"
  on public.sspace_live_chat_messages for delete to authenticated using (auth.uid() = user_id);
grant select, insert, delete on public.sspace_live_chat_messages to authenticated;
revoke all on public.sspace_live_chat_messages from anon;

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_live_chat_messages') then
    alter publication supabase_realtime add table public.sspace_live_chat_messages;
  end if;
end $$;

create table if not exists public.sspace_live_chat_reports (
  id uuid primary key default gen_random_uuid(),
  message_id uuid references public.sspace_live_chat_messages(id) on delete set null,
  reported_user_id uuid not null references public.profiles(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null check (char_length(reason) between 1 and 500),
  created_at timestamptz not null default now(),
  status text not null default 'pending' check (status in ('pending','reviewed','dismissed'))
);
create index if not exists sspace_live_chat_reports_status_idx on public.sspace_live_chat_reports(status,created_at desc);
alter table public.sspace_live_chat_reports enable row level security;
drop policy if exists "Members submit live chat reports" on public.sspace_live_chat_reports;
create policy "Members submit live chat reports" on public.sspace_live_chat_reports for insert to authenticated
  with check (auth.uid()=reporter_id and reporter_id<>reported_user_id and char_length(reason) between 1 and 500);
drop policy if exists "MODO reads live chat reports" on public.sspace_live_chat_reports;
create policy "MODO reads live chat reports" on public.sspace_live_chat_reports for select to authenticated
  using (coalesce(auth.jwt()->'app_metadata'->>'role','')='admin');
grant insert,select on public.sspace_live_chat_reports to authenticated;
revoke all on public.sspace_live_chat_reports from anon;

-- Les membres reçoivent un avis lorsque leur demande de badge est acceptée/refusée.
alter table public.user_notifications drop constraint if exists user_notifications_notif_type_check;
alter table public.user_notifications add constraint user_notifications_notif_type_check
  check (notif_type in ('message','friend_request','friend_accept','mention','comment','like','friend_activity','gem_gift','gem_request','emerald_gift','emerald_request','profile_view','verification_approved','verification_rejected'));

create or replace function public.modo_review_verification_request(p_request_id uuid,p_decision text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=''
as $$
declare v_access jsonb; v_request public.sspace_creator_verification_requests%rowtype; v_actor uuid:=auth.uid();
begin
 if v_actor is null then raise exception 'Authentification requise'; end if;
 v_access:=private.modo_access_snapshot();
 if coalesce(v_access->>'role','member')<>'admin' and coalesce((v_access->'permissions'->>'verification_reviews')::boolean,false) is not true then raise exception 'Permission de vérification refusée'; end if;
 if p_decision not in ('approved','rejected') then raise exception 'Décision invalide'; end if;
 select * into v_request from public.sspace_creator_verification_requests where id=p_request_id for update;
 if not found then raise exception 'Demande introuvable'; end if;
 if v_request.status<>'pending' then raise exception 'Cette demande a déjà été traitée'; end if;
 update public.sspace_creator_verification_requests set status=p_decision,moderator_note=nullif(left(coalesce(p_note,''),1000),''),reviewed_by=v_actor,reviewed_at=now() where id=p_request_id;
 perform set_config('sspace.verification_review','on',true);
 if v_request.request_type='profile' then
   update public.profiles set is_verified_public_figure=(p_decision='approved'),verified_public_figure_at=case when p_decision='approved' then now() else null end where id=v_request.owner_id;
 elsif v_request.business_page_id is not null then
   update public.business_pages set is_verified=(p_decision='approved'),verified_at=case when p_decision='approved' then now() else null end,updated_at=now() where id=v_request.business_page_id;
 end if;
 insert into public.user_notifications(user_id,actor_id,notif_type,entity_id,preview_text)
 values(v_request.owner_id,v_actor,case when p_decision='approved' then 'verification_approved' else 'verification_rejected' end,v_request.id,
   case when p_decision='approved' then 'Ta demande de vérification SSPACE a été approuvée. Ton badge est maintenant actif.' else 'Ta demande de vérification SSPACE a été refusée.' end);
 return jsonb_build_object('success',true,'status',p_decision,'request_type',v_request.request_type);
end;
$$;
revoke all on function public.modo_review_verification_request(uuid,text,text) from public,anon;
grant execute on function public.modo_review_verification_request(uuid,text,text) to authenticated;

create or replace function public.modo_list_live_chat_reports(p_limit integer default 50)
returns table(id uuid,reason text,status text,created_at timestamptz,reported_user_id uuid,reporter_id uuid,message_content text,reported_username text,reporter_username text)
language plpgsql stable security definer set search_path=''
as $$
declare v_access jsonb;
begin
 if auth.uid() is null then raise exception 'Authentification requise'; end if;
 v_access:=private.modo_access_snapshot();
 if coalesce(v_access->>'role','member')<>'admin' and coalesce((v_access->'permissions'->>'reports')::boolean,false) is not true then raise exception 'Permission de signalement refusée'; end if;
 return query select r.id,r.reason,r.status,r.created_at,r.reported_user_id,r.reporter_id,m.content,
   coalesce(rp.display_name,rp.username,'Membre'),coalesce(ap.display_name,ap.username,'Membre')
 from public.sspace_live_chat_reports r
 left join public.sspace_live_chat_messages m on m.id=r.message_id
 left join public.profiles rp on rp.id=r.reported_user_id
 left join public.profiles ap on ap.id=r.reporter_id
 order by case when r.status='pending' then 0 else 1 end,r.created_at desc
 limit greatest(1,least(coalesce(p_limit,50),100));
end;
$$;

create or replace function public.modo_review_live_chat_report(p_report_id uuid,p_decision text)
returns jsonb language plpgsql security definer set search_path=''
as $$
declare v_access jsonb;
begin
 if auth.uid() is null then raise exception 'Authentification requise'; end if;
 v_access:=private.modo_access_snapshot();
 if coalesce(v_access->>'role','member')<>'admin' and coalesce((v_access->'permissions'->>'reports')::boolean,false) is not true then raise exception 'Permission de signalement refusée'; end if;
 if p_decision not in ('reviewed','dismissed') then raise exception 'Décision invalide'; end if;
 update public.sspace_live_chat_reports set status=p_decision where id=p_report_id and status='pending';
 if not found then raise exception 'Signalement introuvable ou déjà traité'; end if;
 return jsonb_build_object('success',true,'status',p_decision);
end;
$$;
revoke all on function public.modo_list_live_chat_reports(integer) from public,anon;
revoke all on function public.modo_review_live_chat_report(uuid,text) from public,anon;
grant execute on function public.modo_list_live_chat_reports(integer) to authenticated;
grant execute on function public.modo_review_live_chat_report(uuid,text) to authenticated;
