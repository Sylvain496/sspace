-- SSPACE: présence en ligne configurable et limite serveur de 60 jours entre les changements de pseudo.
-- Cette version correspond à la migration déjà présente dans le projet Supabase Sspace connecté.

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS show_online boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS username_changed_at timestamptz;

CREATE SCHEMA IF NOT EXISTS private;

CREATE OR REPLACE FUNCTION private.enforce_username_change_cooldown()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = ''
AS $$
BEGIN
  IF NEW.username IS DISTINCT FROM OLD.username THEN
    IF OLD.username_changed_at IS NOT NULL
       AND OLD.username_changed_at > pg_catalog.now() - interval '60 days' THEN
      RAISE EXCEPTION 'USERNAME_CHANGE_COOLDOWN: Tu pourras modifier ton nom d’utilisateur à nouveau le %.',
        pg_catalog.to_char(OLD.username_changed_at + interval '60 days', 'DD/MM/YYYY')
        USING ERRCODE = 'P0001';
    END IF;
    NEW.username_changed_at := pg_catalog.now();
  ELSE
    NEW.username_changed_at := OLD.username_changed_at;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_username_cooldown ON public.profiles;
CREATE TRIGGER profiles_username_cooldown
BEFORE UPDATE OF username ON public.profiles
FOR EACH ROW
EXECUTE FUNCTION private.enforce_username_change_cooldown();

REVOKE ALL ON FUNCTION private.enforce_username_change_cooldown() FROM PUBLIC, anon, authenticated;
