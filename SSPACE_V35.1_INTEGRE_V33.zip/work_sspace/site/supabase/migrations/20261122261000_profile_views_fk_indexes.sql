-- Indexes des FK secondaires des nouvelles tables de profil.
create index if not exists profile_visits_visitor_idx on public.profile_visits(visitor_id);
create index if not exists profile_reputation_votes_voter_idx on public.profile_reputation_votes(voter_id);
