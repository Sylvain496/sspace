-- SSPACE LIVE: missing public chat tables restored with authenticated-only RLS and Realtime.
create table if not exists public.sspace_live_chat_messages (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 content text not null check(char_length(content) between 1 and 500),
 message_type text not null default 'text' check(message_type in ('text','gif')),
 created_at timestamptz not null default now()
);
create index if not exists sspace_live_chat_messages_created_idx on public.sspace_live_chat_messages(created_at desc);
create index if not exists sspace_live_chat_messages_user_idx on public.sspace_live_chat_messages(user_id,created_at desc);
alter table public.sspace_live_chat_messages enable row level security;
drop policy if exists "SSPACE LIVE members read messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE members read messages" on public.sspace_live_chat_messages for select to authenticated using(true);
drop policy if exists "SSPACE LIVE members send own messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE members send own messages" on public.sspace_live_chat_messages for insert to authenticated with check(auth.uid()=user_id and char_length(content) between 1 and 500 and (message_type<>'gif' or content like 'https://media%.giphy.com/%' or content like 'https://i.giphy.com/%' or content like 'https://media.tenor.com/%'));
drop policy if exists "SSPACE LIVE authors delete own messages" on public.sspace_live_chat_messages;
create policy "SSPACE LIVE authors delete own messages" on public.sspace_live_chat_messages for delete to authenticated using(auth.uid()=user_id);
grant select,insert,delete on public.sspace_live_chat_messages to authenticated;
revoke all on public.sspace_live_chat_messages from anon;
do $$ begin if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='sspace_live_chat_messages') then alter publication supabase_realtime add table public.sspace_live_chat_messages; end if; end $$;
create table if not exists public.sspace_live_chat_reports (
 id uuid primary key default gen_random_uuid(),
 message_id uuid references public.sspace_live_chat_messages(id) on delete set null,
 reported_user_id uuid not null references public.profiles(id) on delete cascade,
 reporter_id uuid not null references public.profiles(id) on delete cascade,
 reason text not null check(char_length(reason) between 1 and 500),
 created_at timestamptz not null default now(),
 status text not null default 'pending' check(status in ('pending','reviewed','dismissed'))
);
create index if not exists sspace_live_chat_reports_status_idx on public.sspace_live_chat_reports(status,created_at desc);
alter table public.sspace_live_chat_reports enable row level security;
drop policy if exists "Members submit live chat reports" on public.sspace_live_chat_reports;
create policy "Members submit live chat reports" on public.sspace_live_chat_reports for insert to authenticated with check(auth.uid()=reporter_id and reporter_id<>reported_user_id and char_length(reason) between 1 and 500);
drop policy if exists "MODO reads live chat reports" on public.sspace_live_chat_reports;
create policy "MODO reads live chat reports" on public.sspace_live_chat_reports for select to authenticated using(coalesce(auth.jwt()->'app_metadata'->>'role','')='admin');
grant insert,select on public.sspace_live_chat_reports to authenticated;
revoke all on public.sspace_live_chat_reports from anon;
