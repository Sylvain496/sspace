-- SSPACE : icône du nom de profil (remplace la couronne) + nouveaux effets de texte.
-- Idempotent. À exécuter dans Supabase SQL Editor.

alter table public.profiles add column if not exists name_icon text;
alter table public.profiles drop constraint if exists profiles_name_icon_check;
alter table public.profiles add constraint profiles_name_icon_check
  check (name_icon is null or char_length(name_icon) between 1 and 16);
grant update (name_icon) on public.profiles to authenticated;

alter table public.posts drop constraint if exists posts_text_effect_check;
alter table public.posts add constraint posts_text_effect_check
  check (text_effect in ('none','marquee','roll','typewriter','neon','rainbow','shimmer','wave','bounce','float',
    'glow','fire','ice','gold','glitch','pulse','shake','sparkle','gradient','electric','outline','retro'));
