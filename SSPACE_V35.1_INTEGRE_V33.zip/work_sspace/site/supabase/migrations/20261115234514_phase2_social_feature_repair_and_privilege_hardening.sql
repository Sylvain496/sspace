-- Phase 2: additive repairs for social features and table-level permissions.
REVOKE TRUNCATE, TRIGGER, REFERENCES ON ALL TABLES IN SCHEMA public FROM anon, authenticated, PUBLIC;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS status_text text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS memories_enabled boolean NOT NULL DEFAULT true;
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_status_text_check;
ALTER TABLE public.profiles ADD CONSTRAINT profiles_status_text_check CHECK (char_length(status_text) <= 120);

CREATE TABLE IF NOT EXISTS public.hidden_posts (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  post_id uuid NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, post_id)
);
ALTER TABLE public.hidden_posts ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.hidden_posts FROM anon, authenticated, PUBLIC;
GRANT SELECT, INSERT, DELETE ON TABLE public.hidden_posts TO authenticated;
DROP POLICY IF EXISTS "Users manage own hidden posts" ON public.hidden_posts;
CREATE POLICY "Users manage own hidden posts" ON public.hidden_posts FOR ALL TO authenticated
  USING ((SELECT auth.uid()) = user_id) WITH CHECK ((SELECT auth.uid()) = user_id);

CREATE TABLE IF NOT EXISTS public.user_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  blocked_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT user_blocks_not_self CHECK (blocker_id <> blocked_id),
  CONSTRAINT user_blocks_unique UNIQUE (blocker_id, blocked_id)
);
CREATE INDEX IF NOT EXISTS user_blocks_blocker_idx ON public.user_blocks(blocker_id);
CREATE INDEX IF NOT EXISTS user_blocks_blocked_idx ON public.user_blocks(blocked_id);
ALTER TABLE public.user_blocks ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.user_blocks FROM anon, authenticated, PUBLIC;
GRANT SELECT, INSERT, DELETE ON TABLE public.user_blocks TO authenticated;
DROP POLICY IF EXISTS "Users manage own blocks" ON public.user_blocks;
DROP POLICY IF EXISTS "Users read own blocks" ON public.user_blocks;
DROP POLICY IF EXISTS "Users add own blocks" ON public.user_blocks;
DROP POLICY IF EXISTS "Users remove own blocks" ON public.user_blocks;
CREATE POLICY "Users read own blocks" ON public.user_blocks FOR SELECT TO authenticated USING ((SELECT auth.uid()) = blocker_id);
CREATE POLICY "Users add own blocks" ON public.user_blocks FOR INSERT TO authenticated WITH CHECK ((SELECT auth.uid()) = blocker_id);
CREATE POLICY "Users remove own blocks" ON public.user_blocks FOR DELETE TO authenticated USING ((SELECT auth.uid()) = blocker_id);

CREATE TABLE IF NOT EXISTS public.content_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  target_type text NOT NULL CHECK (target_type IN ('post', 'user', 'comment', 'message')),
  target_id uuid NOT NULL,
  reason text NOT NULL CHECK (char_length(reason) BETWEEN 3 AND 500),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'reviewed', 'dismissed', 'action_taken')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS content_reports_created_idx ON public.content_reports(created_at DESC);
ALTER TABLE public.content_reports ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.content_reports FROM anon, authenticated, PUBLIC;
GRANT INSERT, SELECT ON TABLE public.content_reports TO authenticated;
DROP POLICY IF EXISTS "Users create reports" ON public.content_reports;
CREATE POLICY "Users create reports" ON public.content_reports FOR INSERT TO authenticated WITH CHECK ((SELECT auth.uid()) = reporter_id);
DROP POLICY IF EXISTS "Users read own reports" ON public.content_reports;
CREATE POLICY "Users read own reports" ON public.content_reports FOR SELECT TO authenticated USING ((SELECT auth.uid()) = reporter_id);

CREATE TABLE IF NOT EXISTS public.store_catalog (
  id text PRIMARY KEY,
  category text NOT NULL CHECK (category IN ('chat_theme', 'profile_decor', 'badge', 'bundle')),
  title text NOT NULL,
  description text NOT NULL,
  is_premium boolean NOT NULL DEFAULT true,
  preview_css text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true
);
ALTER TABLE public.store_catalog ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.store_catalog FROM anon, authenticated, PUBLIC;
GRANT SELECT ON TABLE public.store_catalog TO authenticated;
DROP POLICY IF EXISTS "Everyone reads active store catalog" ON public.store_catalog;
CREATE POLICY "Everyone reads active store catalog" ON public.store_catalog FOR SELECT TO authenticated USING (active = true);
INSERT INTO public.store_catalog (id, category, title, description, is_premium, preview_css) VALUES
('cyber-pulse','chat_theme','Cyber Pulse (Animé)','Ondes bleu électrique et violet néon réactives.',true,'linear-gradient(135deg,#090d24,#1d1145,#0a2540)'),
('nebula-drift','chat_theme','Nébuleuse SSPACE (Animé)','Particules cosmiques lentes en arrière-plan.',true,'radial-gradient(circle at 20% 20%,#3b1d7a,#080a15)'),
('matrix-grid','chat_theme','Grille Quantique (Animé)','Lignes de code lumineuses subtiles.',true,'linear-gradient(180deg,#060b19,#101c3d)'),
('aurora-storm','chat_theme','Orage Boréal (Animé)','Vagues lumineuses cyan et magenta.',true,'linear-gradient(120deg,#0c1e3e,#2c1250)'),
('void-starlight','chat_theme','Éclat Stellaire (Animé)','Scintillement profond noir et argent.',true,'radial-gradient(circle,#181c36,#05060c)')
ON CONFLICT (id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.get_sspace_memories()
RETURNS SETOF public.posts LANGUAGE sql STABLE SECURITY INVOKER SET search_path = '' AS $$
  SELECT p.* FROM public.posts p JOIN public.profiles pr ON pr.id = p.user_id
  WHERE p.user_id = (SELECT auth.uid()) AND pr.memories_enabled = true
    AND EXTRACT(MONTH FROM p.created_at) = EXTRACT(MONTH FROM now())
    AND EXTRACT(DAY FROM p.created_at) = EXTRACT(DAY FROM now())
    AND EXTRACT(YEAR FROM p.created_at) < EXTRACT(YEAR FROM now())
  ORDER BY p.created_at DESC;
$$;
REVOKE ALL ON FUNCTION public.get_sspace_memories() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_sspace_memories() TO authenticated;

CREATE SCHEMA IF NOT EXISTS private;
CREATE OR REPLACE FUNCTION private.reject_blocked_friend_request() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  IF (TG_OP = 'INSERT' OR NEW.status = 'accepted') AND EXISTS (
    SELECT 1 FROM public.user_blocks b WHERE
      (b.blocker_id = NEW.sender_id AND b.blocked_id = NEW.receiver_id) OR
      (b.blocker_id = NEW.receiver_id AND b.blocked_id = NEW.sender_id)
  ) THEN RAISE EXCEPTION 'Cette action est impossible : une relation de blocage existe entre ces comptes.' USING ERRCODE = '42501'; END IF;
  RETURN NEW;
END; $$;
CREATE OR REPLACE FUNCTION private.reject_blocked_conversation() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM public.user_blocks b WHERE
    (b.blocker_id = NEW.user_one AND b.blocked_id = NEW.user_two) OR
    (b.blocker_id = NEW.user_two AND b.blocked_id = NEW.user_one)
  ) THEN RAISE EXCEPTION 'Cette action est impossible : une relation de blocage existe entre ces comptes.' USING ERRCODE = '42501'; END IF;
  RETURN NEW;
END; $$;
CREATE OR REPLACE FUNCTION private.reject_blocked_message() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $$
DECLARE v_user_one uuid; v_user_two uuid;
BEGIN
  SELECT c.user_one,c.user_two INTO v_user_one,v_user_two FROM public.conversations c WHERE c.id=NEW.conversation_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Conversation introuvable.' USING ERRCODE = '42501'; END IF;
  IF EXISTS (SELECT 1 FROM public.user_blocks b WHERE
    (b.blocker_id=v_user_one AND b.blocked_id=v_user_two) OR
    (b.blocker_id=v_user_two AND b.blocked_id=v_user_one)
  ) THEN RAISE EXCEPTION 'Envoi impossible : une relation de blocage existe entre ces comptes.' USING ERRCODE = '42501'; END IF;
  RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION private.reject_blocked_friend_request() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.reject_blocked_conversation() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION private.reject_blocked_message() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS reject_blocked_friend_request ON public.friend_requests;
CREATE TRIGGER reject_blocked_friend_request BEFORE INSERT ON public.friend_requests FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_friend_request();
DROP TRIGGER IF EXISTS reject_blocked_friend_request_accept ON public.friend_requests;
CREATE TRIGGER reject_blocked_friend_request_accept BEFORE UPDATE OF status ON public.friend_requests FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_friend_request();
DROP TRIGGER IF EXISTS reject_blocked_conversation ON public.conversations;
CREATE TRIGGER reject_blocked_conversation BEFORE INSERT ON public.conversations FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_conversation();
DROP TRIGGER IF EXISTS reject_blocked_message ON public.messages;
CREATE TRIGGER reject_blocked_message BEFORE INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION private.reject_blocked_message();
