-- SSPACE Android / social experience improvements
ALTER TABLE public.conversation_settings
  ADD COLUMN IF NOT EXISTS friend_nickname text NOT NULL DEFAULT '';
ALTER TABLE public.conversation_settings
  DROP CONSTRAINT IF EXISTS conversation_settings_friend_nickname_check;
ALTER TABLE public.conversation_settings
  ADD CONSTRAINT conversation_settings_friend_nickname_check
  CHECK (char_length(friend_nickname) <= 60);

ALTER TABLE public.conversation_settings
  DROP CONSTRAINT IF EXISTS conversation_settings_decor_id_check;
ALTER TABLE public.conversation_settings
  ADD CONSTRAINT conversation_settings_decor_id_check
  CHECK (decor_id = ANY (ARRAY[
    'aurora-night','ocean-glass','sunset-violet','forest-dream','pixel-pop',
    'minimal-mist','galaxy-drift','cherry-blossom','neon-city','paper-stars',
    'premium-fireworks','premium-cosmic','premium-rain','premium-neon-pulse','premium-magic-portal',
    'aurora-glow','crystal-cave','ocean-depths','lavender-dream','solar-flare','emerald-wave'
  ]));

ALTER TABLE public.conversation_settings
  DROP CONSTRAINT IF EXISTS conversation_settings_text_style_check;
ALTER TABLE public.conversation_settings
  ADD CONSTRAINT conversation_settings_text_style_check
  CHECK (text_style = ANY (ARRAY[
    'classic','serif','rounded','typewriter','elegant','pixel',
    'handwritten','modern','bold','mono'
  ]));

ALTER TABLE public.conversation_settings
  DROP CONSTRAINT IF EXISTS conversation_settings_text_color_check;
ALTER TABLE public.conversation_settings
  ADD CONSTRAINT conversation_settings_text_color_check
  CHECK (text_color = ANY (ARRAY[
    '#f4f6ff','#70d7ff','#b99aff','#ff8fcf','#8fe3b0','#ffd36e','#ff8a8a',
    '#ffb86b','#9cf7f2','#f5a9ff'
  ]));

ALTER TABLE public.messages
  DROP CONSTRAINT IF EXISTS messages_message_type_check;
ALTER TABLE public.messages
  ADD CONSTRAINT messages_message_type_check
  CHECK (message_type = ANY (ARRAY['text','image','video','audio','link']));

ALTER TABLE public.messages
  DROP CONSTRAINT IF EXISTS messages_text_style_check;
ALTER TABLE public.messages
  ADD CONSTRAINT messages_text_style_check
  CHECK (text_style = ANY (ARRAY[
    'classic','serif','rounded','typewriter','elegant','pixel',
    'handwritten','modern','bold','mono'
  ]));

ALTER TABLE public.messages
  DROP CONSTRAINT IF EXISTS messages_text_color_check;
ALTER TABLE public.messages
  ADD CONSTRAINT messages_text_color_check
  CHECK (text_color = ANY (ARRAY[
    '#f4f6ff','#70d7ff','#b99aff','#ff8fcf','#8fe3b0','#ffd36e','#ff8a8a',
    '#ffb86b','#9cf7f2','#f5a9ff'
  ]));

-- Keep a block in place for at least 12 hours before its owner may remove it.
DROP POLICY IF EXISTS "Users remove own blocks" ON public.user_blocks;
CREATE POLICY "Users remove own blocks after 12 hours"
  ON public.user_blocks FOR DELETE TO authenticated
  USING (
    (SELECT auth.uid()) = blocker_id
    AND created_at <= now() - interval '12 hours'
  );

-- Private photo/video/audio attachments remain accessible only to accepted chat participants.
UPDATE storage.buckets
SET file_size_limit = 52428800,
    allowed_mime_types = ARRAY[
      'image/jpeg','image/png','image/webp','image/gif',
      'video/mp4','video/webm',
      'audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav'
    ]
WHERE id = 'chat-attachments';
