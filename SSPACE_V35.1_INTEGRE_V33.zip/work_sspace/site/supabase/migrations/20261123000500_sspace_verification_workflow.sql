-- SSPACE V17.3 — demandes de vérification des profils publics et pages professionnelles
-- La migration est idempotente et s'appuie sur les tables business_pages et profiles de V17.2.

alter table public.business_pages
  add column if not exists is_verified boolean not null default false,
  add column if not exists verified_at timestamptz;

alter table public.profiles
  add column if not exists is_verified_public_figure boolean not null default false,
  add column if not exists verified_public_figure_at timestamptz;

alter table public.sspace_creator_verification_requests
  alter column page_id drop not null,
  add column if not exists business_page_id uuid references public.business_pages(id) on delete cascade;

create unique index if not exists sspace_business_page_one_pending_verification
  on public.sspace_creator_verification_requests(business_page_id)
  where request_type='page' and status='pending' and business_page_id is not null;
create unique index if not exists sspace_profile_one_pending_verification_v2
  on public.sspace_creator_verification_requests(owner_id)
  where request_type='profile' and status='pending';

drop policy if exists "Owners can submit verification requests" on public.sspace_creator_verification_requests;
drop policy if exists "Page owners can submit verification requests" on public.sspace_creator_verification_requests;
drop policy if exists "Members submit their own verification requests" on public.sspace_creator_verification_requests;
create policy "Members submit their own verification requests"
on public.sspace_creator_verification_requests for insert to authenticated
with check (
  auth.uid() = owner_id and status='pending' and reviewed_by is null and reviewed_at is null and page_id is null
  and (
    (request_type='profile' and business_page_id is null and exists(select 1 from public.profiles p where p.id=auth.uid()))
    or
    (request_type='page' and business_page_id is not null and exists(select 1 from public.business_pages p where p.id=business_page_id and p.owner_id=auth.uid()))
  )
);

create or replace function private.modo_access_snapshot()
returns jsonb language plpgsql stable security definer set search_path=''
as $$
declare v_user uuid:=auth.uid(); v_row public.sspace_moderator_team%rowtype;
begin
 if v_user is null then return '{"role":"member","permissions":{}}'::jsonb; end if;
 if coalesce(auth.jwt()->'app_metadata'->>'role','')='admin' then
   return jsonb_build_object('role','admin','permissions','{"warnings":true,"bans":true,"announcements":true,"reports":true,"audit_view":true,"settings_manage":true,"team_manage":true,"verification_reviews":true}'::jsonb);
 end if;
 select * into v_row from public.sspace_moderator_team where user_id=v_user and active=true and role='moderator';
 if not found then return '{"role":"member","permissions":{}}'::jsonb; end if;
 return jsonb_build_object('role','moderator','permissions',v_row.permissions);
end;
$$;

create or replace function private.modo_set_moderator(p_user_id uuid,p_active boolean,p_permissions jsonb default null)
returns jsonb language plpgsql security definer set search_path=''
as $$
declare v_actor uuid:=auth.uid(); v_target_role text; v_permissions jsonb;
 v_allowed text[]:=array['warnings','bans','announcements','reports','audit_view','settings_manage','verification_reviews']; v_key text;
begin
 if v_actor is null or coalesce(auth.jwt()->'app_metadata'->>'role','')<>'admin' then raise exception 'Seul l’administrateur principal peut gérer l’équipe.' using errcode='42501'; end if;
 if p_user_id is null then raise exception 'Membre requis.'; end if;
 select coalesce(raw_app_meta_data->>'role','') into v_target_role from auth.users where id=p_user_id;
 if not found then raise exception 'Membre introuvable.'; end if;
 if v_target_role='admin' then raise exception 'Impossible de modifier un administrateur principal.' using errcode='42501'; end if;
 if p_active then
   v_permissions:=coalesce(p_permissions,'{}'::jsonb);
   if jsonb_typeof(v_permissions)<>'object' then raise exception 'Permissions invalides.'; end if;
   for v_key in select jsonb_object_keys(v_permissions) loop
     if not (v_key=any(v_allowed)) or jsonb_typeof(v_permissions->v_key)<>'boolean' then raise exception 'Permission invalide : %',v_key; end if;
   end loop;
   v_permissions:=jsonb_build_object(
    'warnings',coalesce((v_permissions->>'warnings')::boolean,false),'bans',coalesce((v_permissions->>'bans')::boolean,false),
    'announcements',coalesce((v_permissions->>'announcements')::boolean,false),'reports',coalesce((v_permissions->>'reports')::boolean,false),
    'audit_view',coalesce((v_permissions->>'audit_view')::boolean,false),'settings_manage',coalesce((v_permissions->>'settings_manage')::boolean,false),
    'verification_reviews',coalesce((v_permissions->>'verification_reviews')::boolean,false));
   if not ((v_permissions->>'warnings')::boolean or (v_permissions->>'bans')::boolean or (v_permissions->>'announcements')::boolean or
    (v_permissions->>'reports')::boolean or (v_permissions->>'audit_view')::boolean or (v_permissions->>'settings_manage')::boolean or
    (v_permissions->>'verification_reviews')::boolean) then raise exception 'Attribue au moins une permission.'; end if;
   insert into public.sspace_moderator_team(user_id,role,active,permissions,added_by,updated_at)
   values(p_user_id,'moderator',true,v_permissions,v_actor,clock_timestamp())
   on conflict(user_id) do update set role='moderator',active=true,permissions=excluded.permissions,added_by=v_actor,updated_at=clock_timestamp();
   update auth.users set raw_app_meta_data=coalesce(raw_app_meta_data,'{}'::jsonb)||jsonb_build_object('role','moderator','moderation_access',true),updated_at=clock_timestamp() where id=p_user_id;
   perform private.sspace_write_audit(v_actor,'moderator_activated',p_user_id::text,jsonb_build_object('permissions',v_permissions));
   return jsonb_build_object('user_id',p_user_id,'active',true,'permissions',v_permissions,'requires_relogin',true);
 else
   update public.sspace_moderator_team set active=false,updated_at=clock_timestamp() where user_id=p_user_id and role='moderator';
   update auth.users set raw_app_meta_data=case when raw_app_meta_data->>'role'='moderator' then raw_app_meta_data-'role'-'moderation_access' else raw_app_meta_data end,updated_at=clock_timestamp() where id=p_user_id;
   perform private.sspace_write_audit(v_actor,'moderator_deactivated',p_user_id::text,'{}'::jsonb);
   return jsonb_build_object('user_id',p_user_id,'active',false,'requires_relogin',true);
 end if;
end;
$$;

create or replace function private.guard_verified_badges()
returns trigger language plpgsql security definer set search_path=''
as $$
declare v_old boolean; v_new boolean; v_old_at text; v_new_at text;
begin
 if current_setting('sspace.verification_review',true)='on' or auth.uid() is null then return new; end if;
 if tg_table_name='profiles' then
   if tg_op='INSERT' then
     v_new:=coalesce((to_jsonb(new)->>'is_verified_public_figure')::boolean,false); v_new_at:=to_jsonb(new)->>'verified_public_figure_at';
     if v_new or v_new_at is not null then raise exception 'Seule la modération peut attribuer le badge vérifié.' using errcode='42501'; end if;
   else
     v_old:=coalesce((to_jsonb(old)->>'is_verified_public_figure')::boolean,false); v_new:=coalesce((to_jsonb(new)->>'is_verified_public_figure')::boolean,false);
     v_old_at:=to_jsonb(old)->>'verified_public_figure_at'; v_new_at:=to_jsonb(new)->>'verified_public_figure_at';
     if v_old is distinct from v_new or v_old_at is distinct from v_new_at then raise exception 'Seule la modération peut modifier le badge vérifié.' using errcode='42501'; end if;
   end if;
 elsif tg_table_name='business_pages' then
   if tg_op='INSERT' then
     v_new:=coalesce((to_jsonb(new)->>'is_verified')::boolean,false); v_new_at:=to_jsonb(new)->>'verified_at';
     if v_new or v_new_at is not null then raise exception 'Seule la modération peut attribuer le badge vérifié.' using errcode='42501'; end if;
   else
     v_old:=coalesce((to_jsonb(old)->>'is_verified')::boolean,false); v_new:=coalesce((to_jsonb(new)->>'is_verified')::boolean,false);
     v_old_at:=to_jsonb(old)->>'verified_at'; v_new_at:=to_jsonb(new)->>'verified_at';
     if v_old is distinct from v_new or v_old_at is distinct from v_new_at then raise exception 'Seule la modération peut modifier le badge vérifié.' using errcode='42501'; end if;
   end if;
 end if;
 return new;
end;
$$;

drop trigger if exists guard_profile_verified_badge on public.profiles;
create trigger guard_profile_verified_badge before insert or update on public.profiles for each row execute function private.guard_verified_badges();
drop trigger if exists guard_business_page_verified_badge on public.business_pages;
create trigger guard_business_page_verified_badge before insert or update on public.business_pages for each row execute function private.guard_verified_badges();

drop function if exists public.modo_list_verification_requests(integer);
create function public.modo_list_verification_requests(p_limit integer default 50)
returns table (
 id uuid,page_id uuid,owner_id uuid,business_name text,business_type text,website_url text,contact_email text,proof_note text,proof_url text,
 status text,moderator_note text,created_at timestamptz,page_name text,page_slug text,page_category text,request_type text,
 profile_display_name text,profile_username text,business_page_id uuid
)
language plpgsql security definer set search_path=''
as $$
declare v_access jsonb;
begin
 if auth.uid() is null then raise exception 'Authentification requise'; end if;
 v_access:=private.modo_access_snapshot();
 if coalesce(v_access->>'role','member')<>'admin' and coalesce((v_access->'permissions'->>'verification_reviews')::boolean,false) is not true then raise exception 'Permission de vérification refusée'; end if;
 return query select r.id,r.page_id,r.owner_id,r.business_name,r.business_type,r.website_url,r.contact_email,r.proof_note,r.proof_url,r.status,r.moderator_note,r.created_at,
  bp.name,bp.slug,bp.category,r.request_type,pr.display_name,pr.username,r.business_page_id
 from public.sspace_creator_verification_requests r left join public.business_pages bp on bp.id=r.business_page_id
 left join public.profiles pr on pr.id=r.owner_id order by case when r.status='pending' then 0 else 1 end,r.created_at desc
 limit greatest(1,least(coalesce(p_limit,50),100));
end;
$$;

create or replace function public.modo_review_verification_request(p_request_id uuid,p_decision text,p_note text default null)
returns jsonb language plpgsql security definer set search_path=''
as $$
declare v_access jsonb; v_request public.sspace_creator_verification_requests%rowtype;
begin
 if auth.uid() is null then raise exception 'Authentification requise'; end if;
 v_access:=private.modo_access_snapshot();
 if coalesce(v_access->>'role','member')<>'admin' and coalesce((v_access->'permissions'->>'verification_reviews')::boolean,false) is not true then raise exception 'Permission de vérification refusée'; end if;
 if p_decision not in ('approved','rejected') then raise exception 'Décision invalide'; end if;
 select * into v_request from public.sspace_creator_verification_requests where id=p_request_id for update;
 if not found then raise exception 'Demande introuvable'; end if;
 if v_request.status<>'pending' then raise exception 'Cette demande a déjà été traitée'; end if;
 update public.sspace_creator_verification_requests set status=p_decision,moderator_note=nullif(left(coalesce(p_note,''),1000),''),reviewed_by=auth.uid(),reviewed_at=now() where id=p_request_id;
 perform set_config('sspace.verification_review','on',true);
 if v_request.request_type='profile' then
   update public.profiles set is_verified_public_figure=(p_decision='approved'),verified_public_figure_at=case when p_decision='approved' then now() else null end where id=v_request.owner_id;
 elsif v_request.business_page_id is not null then
   update public.business_pages set is_verified=(p_decision='approved'),verified_at=case when p_decision='approved' then now() else null end,updated_at=now() where id=v_request.business_page_id;
 end if;
 return jsonb_build_object('success',true,'status',p_decision,'request_type',v_request.request_type);
end;
$$;

revoke all on function public.modo_list_verification_requests(integer) from public,anon;
revoke all on function public.modo_review_verification_request(uuid,text,text) from public,anon;
grant execute on function public.modo_list_verification_requests(integer) to authenticated;
grant execute on function public.modo_review_verification_request(uuid,text,text) to authenticated;
