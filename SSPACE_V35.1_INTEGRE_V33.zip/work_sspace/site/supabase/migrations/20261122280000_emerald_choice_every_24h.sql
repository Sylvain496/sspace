-- SSPACE : remplacement du tirage aléatoire par un choix garanti d'une gemme manquante toutes les 24 heures.
-- À exécuter dans Supabase SQL Editor avant le déploiement.

create or replace function public.emerald_pickup_status()
returns jsonb
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  me uuid := (select auth.uid());
  last_pick timestamptz;
  next_pick timestamptz;
begin
  if me is null then raise exception 'Connexion requise'; end if;
  select max(created_at) into last_pick
  from public.emerald_pickups
  where user_id = me;
  next_pick := case when last_pick is null then null else last_pick + interval '24 hours' end;
  return jsonb_build_object(
    'available', (last_pick is null or now() >= next_pick),
    'next_at', next_pick
  );
end;
$$;
revoke all on function public.emerald_pickup_status() from public, anon;
grant execute on function public.emerald_pickup_status() to authenticated;

-- Supprime l'ancienne fonction sans paramètre : elle permettait encore le tirage au hasard.
drop function if exists public.emerald_pickup();

create or replace function public.emerald_pickup(p_emerald int)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $$
declare
  me uuid := (select auth.uid());
  last_pick timestamptz;
  next_pick timestamptz;
  nm text;
begin
  if me is null then raise exception 'Connexion requise'; end if;

  -- Verrou par compte pour empêcher plusieurs réclamations simultanées.
  perform pg_advisory_xact_lock(hashtextextended(me::text || ':emerald-choice-24h', 0));

  select max(created_at) into last_pick
  from public.emerald_pickups
  where user_id = me;
  if last_pick is not null and now() < last_pick + interval '24 hours' then
    raise exception 'Tu as déjà choisi une émeraude. Reviens après 24 heures.';
  end if;

  select name into nm from public.emerald_catalog where id = p_emerald;
  if nm is null then raise exception 'Émeraude inconnue.'; end if;

  if exists (
    select 1 from public.emerald_collection
    where user_id = me and emerald_id = p_emerald
  ) then
    raise exception 'Tu possèdes déjà cette émeraude. Choisis-en une autre qui te manque.';
  end if;

  insert into public.emerald_pickups(user_id, emerald_id) values (me, p_emerald);
  insert into public.emerald_collection(user_id, emerald_id, source)
  values (me, p_emerald, 'pickup');

  next_pick := now() + interval '24 hours';
  return jsonb_build_object(
    'emerald_id', p_emerald,
    'next_at', next_pick,
    'available', false
  );
end;
$$;
revoke all on function public.emerald_pickup(int) from public, anon;
grant execute on function public.emerald_pickup(int) to authenticated;
