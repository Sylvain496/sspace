# SSPACE V26 — Bowling, loupe et choix garanti des gemmes

## Changements
- Bowling 3D : correction de l'échelle de la boule pour qu'elle ne masque plus la piste; trous et reflets mieux définis.
- Barre du haut : icône de loupe 🔍 visible; le bouton ouvre le panneau de recherche déjà présent (comptes/membres et sujets/hashtags).
- Gemmes : suppression du champ de ramassage aléatoire et de la mission hebdomadaire qui donnait une gemme au hasard.
- Gemmes : l'utilisateur choisit explicitement une gemme manquante; une seule obtention garantie par période glissante de 24 heures.
- Contrôle côté serveur par Supabase pour empêcher les doubles réclamations et les contournements côté navigateur.

## Étape obligatoire avant déploiement
Exécuter une seule fois dans Supabase SQL Editor le fichier :
`site/supabase/migrations/20261122280000_emerald_choice_every_24h.sql`

Cette migration remplace l'ancienne fonction aléatoire `emerald_pickup()` par `emerald_pickup(p_emerald)` et ajoute `emerald_pickup_status()`.
Sans cette migration, le nouveau choix de gemme ne pourra pas fonctionner côté serveur.

Ensuite, redéployer le projet sur Vercel. Le bouton loupe et la correction visuelle du bowling sont côté fichiers et ne nécessitent pas de migration.
