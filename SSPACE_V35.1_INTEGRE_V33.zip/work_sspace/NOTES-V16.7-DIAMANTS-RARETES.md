# SSPACE V16.7 — Diamants par rareté

## Modifications
- Les 80 pierres de la collection utilisent maintenant une finition facettée plus brillante, avec des reflets et un cœur teinté selon la couleur propre à chaque pierre.
- Les carreaux indiquent explicitement leur famille de rareté : Classiques, Précieuses, Prismatiques, Cosmiques ou Légendaires.
- Chaque famille possède un traitement visuel distinct pour le fond et le contour des carreaux.
- Les pierres légendaires bénéficient d'une animation lumineuse dédiée et d'un éclat supplémentaire.
- Les pierres non collectées restent assombries afin de distinguer clairement les découvertes.
- La grille reste sur quatre colonnes et s'adapte aux petits écrans.

## Contrôles effectués
- Vérification syntaxique du JavaScript inline avec Node.js.
- Vérification de l'intégrité de l'archive ZIP.

Le fonctionnement connecté à Supabase et le rendu sur appareil réel doivent encore être testés après déploiement.

## V16.8 — missions hebdomadaires et recherche de demande
- Ajout d'une mission hebdomadaire « Double publication » : publier 2 publications avec image dans la semaine (heure de l'Est), puis recevoir au moins 1 J'aime d'un autre membre sur ces publications.
- La progression est calculée côté Supabase à partir des tables `posts` et `likes`; une récompense par semaine, réclamable depuis l'interface, débloque une émeraude manquante choisie au hasard.
- Au clic sur une émeraude verrouillée, l'utilisateur peut rechercher un ami par nom ou @pseudo. La liste ne montre que les amis acceptés qui possèdent réellement l'émeraude.
- L'envoi de la demande passe par `emerald_request_create`, qui revérifie les droits côté serveur et crée une notification SSPACE de type `emerald_request` pour le destinataire.
- Nouvelle migration à exécuter après `20261122240000_emerald_library.sql` : `site/supabase/migrations/20261122250000_emerald_weekly_missions.sql`.
- Vérification locale : syntaxe du JavaScript inline et intégrité ZIP. Le SQL et les flux connectés nécessitent une exécution sur le projet Supabase réel pour confirmer leur fonctionnement en production.
