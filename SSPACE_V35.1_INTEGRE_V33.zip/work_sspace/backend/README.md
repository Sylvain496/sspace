# SSPACE Profile API (Express + PostgreSQL)

Ce service ajoute des routes de profil et de médias sans toucher à l'authentification existante. Les identifiants utilisateurs restent les UUID déjà présents dans `auth.users` et `public.profiles` du projet Supabase SIKX.

## Sécurité et compatibilité

- Aucun endpoint d'inscription/connexion, aucun mot de passe local, aucun compte `users` parallèle, aucun JWT maison.
- Chaque route `/api/profil/*` exige `Authorization: Bearer <access_token>` et valide le jeton auprès de Supabase Auth (`/auth/v1/user`).
- PostgreSQL utilise `public.profiles.id` comme clé de compte; les profils existants ne sont pas recréés ni migrés.
- Les fichiers ne sont jamais exposés par `express.static`. Le téléchargement passe par une route authentifiée.
- Les types sont contrôlés par signature du fichier (JPEG, PNG, WebP, MP4, WebM). SVG et autres formats sont refusés.
- Limites par défaut : photo 8 Mo, vidéo 50 Mo. Rate limit, CORS, Helmet et réponses sans cache sont activés.
- Les tables de chat, amis, Messenger et les fonctions Supabase existantes ne sont ni modifiées ni remplacées.

## Installation

Depuis la racine du projet :

```bash
npm install
cp backend/.env.example backend/.env
# Remplir les variables de backend/.env
npm run api
```

Le serveur charge automatiquement `backend/.env`, quel que soit le dossier depuis lequel `npm run api` est lancé. Le chemin d'upload `./uploads` est relatif à `backend/` et reste hors du répertoire statique du site. Pour le frontend, ajoute `VITE_PROFILE_API_URL=https://api.ton-domaine.com` à l'environnement de build (en local : `http://localhost:3000`). Le module `messenger/src/lib/profileApi.ts` réutilise le jeton de la session Supabase déjà ouverte; il ne crée aucune session ni aucun compte.

## Migration à appliquer une seule fois

Dans le SQL Editor du projet Supabase SIKX, exécuter :

`supabase/migrations/20261123002000_profile_media_api.sql`

Cette migration crée uniquement `public.profile_media`, référencée à `public.profiles(id)`. Elle ne crée pas de table utilisateurs et ne modifie pas les données de profils. Le backend doit se connecter avec une URI PostgreSQL serveur (jamais une clé `service_role` dans le navigateur). Les rôles `anon` et `authenticated` n'ont aucun droit direct sur la table média.

## Variables serveur

Voir `.env.example`. `DATABASE_URL` est l'URI PostgreSQL de Supabase; `SUPABASE_URL` et `SUPABASE_ANON_KEY` servent à vérifier la session. La clé anon/publishable est publique par conception. Ne mets jamais `service_role`, un mot de passe DB ou un secret dans `VITE_*`, le frontend ou Git.

## Routes

Toutes les routes requièrent le jeton d'accès Supabase existant :

| Méthode | Route | Description |
|---|---|---|
| GET | `/health` | Santé du service |
| GET | `/api/profil/me` | Mon profil existant |
| GET | `/api/profil/:userId` | Profil public d'un membre (les profils privés restent réservés à leur propriétaire) |
| GET | `/api/profil/:userId/media` | Médias d'un profil public; les médias privés restent réservés à leur propriétaire |
| POST | `/api/profil/me/photo` | Upload `multipart/form-data`, champ `file` |
| POST | `/api/profil/me/video` | Upload `multipart/form-data`, champ `file` |
| GET | `/api/profil/media/:mediaId/content` | Lire un média après authentification |
| DELETE | `/api/profil/media/:mediaId` | Supprimer son propre média |

Exemple (le jeton vient de la session Supabase déjà ouverte dans SSPACE) :

```bash
curl https://api.ton-domaine.com/api/profil/me \
  -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN"

curl -X POST https://api.ton-domaine.com/api/profil/me/photo \
  -H "Authorization: Bearer $SUPABASE_ACCESS_TOKEN" \
  -F "file=@./photo.jpg"
```

## Déploiement

Le site actuel est publié en statique via Vercel/Netlify (`dist/`). Express doit tourner comme service Node séparé (VPS, VM ou plateforme Node persistante) et être exposé en HTTPS. Configure `FRONTEND_ORIGINS` avec les origines exactes du site. Configure `UPLOAD_DIR` sur un volume privé persistant et sauvegardé; ne place pas ce dossier dans le répertoire public du site. Les disques éphémères des fonctions serverless ne conviennent pas à ce stockage local.

L'API est prête côté serveur. Le frontend social actuel reste intact; son intégration UI doit utiliser l'URL de cette API et le `access_token` retourné par `supabase.auth.getSession()` sans créer de nouvelle session. Ne publie pas l'API en production avant d'avoir appliqué la migration et testé les permissions avec deux comptes SSPACE.
