La migration SQL à appliquer dans le projet Supabase SIKX est `../../supabase/migrations/20261123002000_profile_media_api.sql`.
