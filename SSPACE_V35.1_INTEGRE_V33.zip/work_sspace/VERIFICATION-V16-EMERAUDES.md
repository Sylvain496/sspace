# Vérification technique — V16 Bibliothèque d'émeraudes

## Résultats
- Le script JavaScript intégré à `site/index.html` passe `node --check`.
- Les fichiers JavaScript serveur `api/alex.js`, `netlify/functions/alex.mjs` et `scripts/copy-site.mjs` passent `node --check`.
- La migration V16 contient les tables, politiques RLS, fonctions RPC et déclencheur de dotation de départ.
- La migration a été ajustée pour créer elle-même `private.are_friends`, car cette fonction était absente du projet Supabase Sspace actuellement connecté.

## À faire avant l'ouverture
1. Appliquer ou confirmer les migrations suivantes dans cet ordre : `20261122180000_messenger_video_gif_attachments.sql`, `20261122200000_album_photo_likes_comments.sql`, `20261122220000_name_icon_and_more_text_effects.sql`. Le projet Supabase contrôlé ne possède pas encore les colonnes/tables/contraintes correspondantes.
2. Appliquer ensuite `20261122240000_emerald_library.sql` dans le projet Supabase Sspace.
3. Vérifier la présence des 80 entrées du catalogue et la dotation initiale des comptes existants.
4. Créer un compte de test, vérifier les 4 émeraudes de départ, puis tester ramassage quotidien, demande, cadeau et progression.
5. Tester les politiques RLS et les notifications en session authentifiée.

## Limites du contrôle effectué
Le ZIP a été contrôlé statiquement. Aucun test fonctionnel de l'application avec un compte utilisateur réel n'a été exécuté. Le build complet du projet n'a pas été exécuté : les dépendances Node ne sont pas incluses dans l'archive.
