# SSPACE V27.3 — Suite communautaire (7 modules)

Cette version ajoute les modules Blog, Blog Musical, Clans, chat temps réel de Clan, commentaires enrichis, Défis/Streaks et Boîte à Souvenirs. Ils utilisent les UUID de `auth.users` et le client/session Supabase déjà présent : aucun compte ni JWT parallèle.

## Activation obligatoire
1. Dans le projet Supabase associé à SSPACE, exécuter `supabase/migrations/20261123004000_sspace_community_suite.sql` (ou la copie `site/supabase/migrations/...`).
2. Vérifier que Supabase Storage est activé et que le bucket privé `sspace-community-media` est créé par la migration.
3. Redéployer le site statique.

## Modules ajoutés
- **Blog** : création, modification et suppression de ses articles, commentaires et Top 100 classé par vues puis commentaires.
- **Blog Musical** : téléversement audio jusqu’à 50 Mo, lecteur intégré et lien de téléchargement facultatif.
- **Clans** : création, adhésion/départ et chat temps réel. Les messages transitent par Supabase Realtime (WebSocket géré par Supabase) et les règles RLS vérifient l’appartenance au Clan.
- **Commentaires enrichis** : texte, note vocale navigateur plafonnée à 60 secondes, photo et sondage avec votes.
- **Défis / Streaks** : trois défis de départ. La publication d’un article, la fin d’écoute d’un morceau et les commentaires font progresser les défis correspondants; une validation manuelle reste disponible. La série quotidienne est affichée sans pénalité en cas de pause.
- **Boîte à Souvenirs** : rétrospective de l’année en cours alimentée par les nouveaux articles et morceaux publiés après activation.
- **Mood Feed** : une intention de type blogue ou musique ouvre l’onglet correspondant et filtre les contenus du module par thème quand un thème est détecté.

## Limites à connaître
- Le chat utilise Supabase Realtime plutôt qu’un serveur IRC autonome : cela évite de créer un deuxième système de connexion et conserve la session Supabase existante.
- Le Top 100 compte les vues enregistrées et les commentaires; ce n’est pas un classement anti-fraude avancé.
- Le contrôle « téléchargement autorisé » masque ou affiche le lien de téléchargement dans l’interface; il ne peut pas empêcher techniquement la capture d’un média lisible dans un navigateur.
- Les souvenirs ne reconstituent pas rétroactivement les anciennes publications ni les photos/écoutes historiques.
- Le filtre régional du Mood Feed reste indisponible tant que les profils ne disposent pas d’un champ de région fiable.
- Le ZIP ne modifie pas le projet Supabase distant. La migration doit être exécutée avant les tests réels. La politique d'adhésion est renforcée : un utilisateur ne peut s'inscrire qu'avec le rôle `membre`; seul le trigger crée le rôle `owner`.
- La syntaxe JavaScript et l’intégrité ZIP ont été vérifiées. Le build complet TypeScript/Vite et les tests de bout en bout n’ont pas pu être exécutés ici, car les dépendances racine `node_modules` ne sont pas présentes.

## Livraison Messenger séparée

Une archive `SSPACE_MESSENGER_STANDALONE.zip` est fournie séparément pour déployer Messenger comme PWA indépendante. Elle utilise le même projet Supabase et les mêmes comptes. Le dépôt principal conserve aussi la route `/messenger/` pour un déploiement combiné. Un domaine séparé exige une connexion manuelle au même compte SSPACE; le navigateur ne partage pas automatiquement la session entre origines.
