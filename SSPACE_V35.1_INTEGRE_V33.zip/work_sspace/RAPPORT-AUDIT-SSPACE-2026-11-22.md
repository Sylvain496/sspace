# Rapport d'audit SSPACE — 22 novembre 2026

## Correctifs intégrés

1. **Superposition des fenêtres et onglets**
   - Le header principal utilisait `z-index: 10250`, donc il pouvait passer devant des fenêtres modales, alors que le menu latéral (z-index 42) pouvait aussi se retrouver sous certains éléments collants.
   - Le header est maintenant à `z-index: 30`, le voile du menu à `900`, le menu à `910` et les modales ouvertes à `20000`.
   - Les modales fermées conservent explicitement `display:none`.
   - Le correctif s'applique aussi aux petits écrans Android.

2. **Mise à jour des caches PWA**
   - Cache du site : `sspace-static-v20a` → `sspace-static-v20b`.
   - Cache Messenger : `sspace-messenger-v3c` → `sspace-messenger-v3d`.
   - Cela force les appareils qui ont installé l'application à récupérer les ressources actualisées après le déploiement.

3. **Formulaires**
   - Les boutons de validation du nom d'utilisateur et de fin d'inscription ont maintenant `type="submit"` explicite.

4. **Synchronisation des fichiers publiables**
   - `dist/index.html` et `dist/sw.js` ont été synchronisés avec les sources de `site/`.
   - Le processus officiel `npm run build` reconstruit `dist/` puis compile Messenger dans `dist/messenger/`.

## Contrôles statiques exécutés

- Archive ZIP source : intégrité vérifiée avant extraction.
- HTML : 1 577 éléments, 524 identifiants, aucun identifiant dupliqué.
- Références DOM statiques : 445 références; les 4 identifiants non trouvés sont des éléments créés dynamiquement (fenêtres d'émeraudes et bannière LIVE), pas des éléments statiques oubliés.
- JavaScript inline : vérification syntaxique `node --check` réussie.
- Messenger : transpilation syntaxique TypeScript/TSX réussie sur 11 fichiers, aucune erreur de syntaxe.
- Ressources préchargées par le service worker : toutes présentes.
- Configurations Vercel/Netlify et script de build inspectés.

## Limites — tests non certifiés

- `npm install --no-audit --no-fund` a expiré dans l'environnement d'audit; les dépendances n'ont donc pas pu être installées.
- En conséquence, le build complet `tsc -b` + Vite n'a pas pu être certifié ici. L'essai TypeScript strict sans dépendances génère naturellement des erreurs de modules/types manquants; il ne prouve pas une erreur dans le code applicatif.
- Aucun navigateur connecté à Supabase ni deux comptes de test réels n'étaient disponibles. Les connexions, appels audio/vidéo, LIVE, pièces jointes, approbations MODO et droits RLS doivent encore être testés sur un déploiement HTTPS avec deux comptes.

## Recommandation avant production

Déployer d'abord une Preview avec `npm install` puis `npm run build`. Tester sur Android et ordinateur : ouvrir/fermer le menu, les modales, le profil, le formulaire de vérification, le panneau MODO, le clavardage, les appels et Messenger. Ne promouvoir en production qu'après validation avec deux comptes membres et un compte MODO.
