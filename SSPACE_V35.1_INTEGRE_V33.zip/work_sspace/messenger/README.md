# SSPACE Messenger

Application Messenger intégrée au même domaine Vercel que SSPACE Social, avec le même projet Supabase et les mêmes comptes.

## Fonctions
- Conversations et messages texte partagés avec SSPACE Social.
- Liaison de session via `postMessage`, nonce temporaire et vérification d’origine.
- Appels audio et vidéo WebRTC : capture micro/caméra, RTCPeerConnection, SDP offer/answer, ICE, mute, caméra et raccrochage.
- Signalisation via la table Supabase `public.call_signals`, protégée par RLS et Realtime.

## Conditions des appels
- HTTPS requis (fourni par Vercel).
- Les deux membres doivent être amis acceptés et autoriser micro/caméra.
- La migration `20261120130000_private_video_audio_call_signals.sql` doit être appliquée dans le projet Supabase SIKX si elle ne l’est pas déjà.
- STUN est configuré par défaut. TURN est recommandé pour les réseaux mobiles, Wi-Fi d’entreprise ou NAT restrictifs. Configure uniquement des identifiants TURN temporaires via les variables VITE_TURN_*. Ne mets jamais de clé service_role ou de secret permanent dans le frontend.

Les appels sont codés mais doivent être validés avec deux comptes distincts et deux appareils/navigateurs sur la version Preview Vercel avant publication.

## V11 — TURN, pièces jointes, émojis, GIF
- **TURN** : `src/lib/ice.ts`. Ordre : `VITE_TURN_API_URL` (identifiants temporaires) → réglages du navigateur (⚙ Paramètres Messenger → « Serveur TURN », même clé que SSPACE LIVE) → `VITE_TURN_URLS/USERNAME/CREDENTIAL`.
- **Trombone** : photos et vidéos (50 Mo max) → bucket privé `chat-attachments`, affichage via URL signée.
- **Émojis** : sélecteur dans la saisie (insertion à la position du curseur).
- **GIF** : onglet GIF (GIPHY). Ajouter `VITE_GIPHY_API_KEY` dans Vercel.
- **SQL à exécuter** : `site/supabase/migrations/20261122180000_messenger_video_gif_attachments.sql`.
