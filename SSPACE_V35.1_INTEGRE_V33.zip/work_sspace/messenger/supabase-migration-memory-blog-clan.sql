-- Weekly memory suggestions can now connect private memory keywords to published
-- blog articles and public clans/groups, while preserving per-user privacy.
create or replace function public.generate_memory_suggestion()
returns public.memory_suggestions
language plpgsql
security definer
set search_path = ''
as $function$
declare
  uid uuid := auth.uid();
  kws text[];
  blog_row record;
  clan_row record;
  ev record;
  outrow public.memory_suggestions;
begin
  if uid is null then raise exception 'Authentication required'; end if;

  select coalesce(array(
    select distinct x from (
      select unnest(b.keywords) as x
      from private.media_backstories b where b.user_id = uid
    ) t where x is not null and length(trim(x)) > 1 limit 40
  ), '{}'::text[]) into kws;

  select * into outrow from public.memory_suggestions
  where user_id = uid and week_start = date_trunc('week', now())::date limit 1;
  if found then return outrow; end if;

  -- Only published articles are considered. Clan-only articles are suggested
  -- only to an account that is already a member of that clan.
  if cardinality(kws) > 0 then
    select a.* into blog_row
    from public.memory_blog_articles a
    where a.published = true
      and a.keywords && kws
      and (a.clan_id is null or exists (
        select 1 from public.group_members gm
        where gm.group_id = a.clan_id and gm.user_id = uid and gm.status = 'accepted' and gm.status = 'accepted'
      ))
    order by a.created_at desc limit 1;
  end if;
  if found then
    insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
    values(uid, 'Un article de blog pourrait t’intéresser : ' || blog_row.title,
      array_to_string(kws, ', '), 'blog', blog_row.id, date_trunc('week',now())::date)
    returning * into outrow;
    return outrow;
  end if;

  -- Recommend only public groups the user has not joined yet.
  if cardinality(kws) > 0 then
    select g.* into clan_row
    from public.groups g
    where lower(coalesce(g.visibility,'')) = 'public'
      and not exists (select 1 from public.group_members gm where gm.group_id=g.id and gm.user_id=uid and gm.status='accepted' and gm.status='accepted')
      and exists (select 1 from unnest(kws) k where
        coalesce(g.name,'') ilike '%'||k||'%' or coalesce(g.description,'') ilike '%'||k||'%')
    order by g.created_at desc limit 1;
  end if;
  if found then
    insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
    values(uid, 'Un clan pourrait correspondre à tes centres d’intérêt : ' || clan_row.name,
      array_to_string(kws, ', '), 'clan', clan_row.id, date_trunc('week',now())::date)
    returning * into outrow;
    return outrow;
  end if;

  if cardinality(kws) > 0 then
    select e.* into ev from public.events e
    where e.keywords && kws and (e.event_date is null or e.event_date >= now())
    order by e.event_date nulls last limit 1;
  end if;
  if found then
    insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
    values(uid, 'Une activité pourrait te plaire : ' || ev.title,
      array_to_string(kws, ', '), 'event', ev.id, date_trunc('week',now())::date)
    returning * into outrow;
  else
    insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
    values(uid,
      case when cardinality(kws)>0 then 'Choisis une activité hors écran liée à tes souvenirs : '||array_to_string(kws[1:least(cardinality(kws),4)], ', ')
      else 'Ajoute une petite histoire privée à une photo ou une vidéo pour faire émerger des idées qui te ressemblent.' end,
      array_to_string(kws, ', '), 'none', null, date_trunc('week',now())::date)
    returning * into outrow;
  end if;
  return outrow;
end;
$function$;
revoke all on function public.generate_memory_suggestion() from public;
grant execute on function public.generate_memory_suggestion() to authenticated;
