# SSPACE Messenger — Android natif : bulles, notifications et appels

## Ce que le prototype Web peut faire
- Le clic sur Messenger dans Social affiche maintenant un écran de pré-installation/consentement.
- Le bouton Installer tente le mécanisme PWA `beforeinstallprompt` si le navigateur l'expose, sinon affiche les instructions d'installation manuelle.
- Le consentement explicite est requis avant la liaison automatique de session vers `/messenger/`.
- La liaison de session reste un transfert de tokens via fenêtre popup + `postMessage`, validé par origine, source et nonce.

## Limite importante
Une PWA/website ne peut pas créer une bulle persistante au-dessus de toutes les autres applications ni demander de force la permission d'affichage par-dessus les applications. Cela requiert une application Android native, permissions système, notifications Android et services appropriés. Les bulles Android Conversation sont soumises au contrôle utilisateur/système.

## Éléments à implémenter dans le wrapper Android
1. Utiliser Capacitor ou un wrapper Android natif avec activité dédiée pour Messenger.
2. Déclarer les activités ConversationBubble avec `allowEmbedded=true`, `resizeableActivity=true`, lancement multiple.
3. Créer des notifications `MessagingStyle`, raccourcis dynamiques `Person`/`ShortcutInfo`, et `BubbleMetadata` pour chaque conversation.
4. Créer un canal d'appel avec `CATEGORY_CALL`, notifications d'appel entrant, actions accepter/refuser, et activité d'appel.
5. Demander la permission de notification à l'utilisateur; proposer le réglage de bulles Android et, si une fonctionnalité overlay spécifique est retenue, `Settings.ACTION_MANAGE_OVERLAY_PERMISSION` après une explication claire. Ne jamais ouvrir cette permission sans action volontaire.
6. Prévoir un service foreground de call uniquement pour une tâche légitime et visible, avec notification persistante et arrêt lorsque l'appel se termine.
7. Tester sur Android 11+ et plusieurs fabricants (Samsung notamment); les réglages OEM et l'économie batterie peuvent interrompre certaines fonctionnalités.

## Parcours souhaité
Social > bouton Messenger > installation PWA/wrapper > conditions/consentement > authentification/liaison de session > permissions notifications > réglages de bulles > conversation/calls.

## iPhone
La PWA peut être ajoutée à l'écran d'accueil et recevoir des notifications Web push dans les versions compatibles. Les bulles persistantes par-dessus les autres applications ne sont pas autorisées comme sur Android; les appels doivent utiliser les APIs iOS appropriées et les limites système.
