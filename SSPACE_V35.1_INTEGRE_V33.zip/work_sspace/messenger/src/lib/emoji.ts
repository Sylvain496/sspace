export const EMOJI_CATEGORIES: { id: string; icon: string; label: string; items: string[] }[] = [
  { id: 'smileys', icon: '😀', label: 'Smileys', items: '😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🤫 🫠 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 👽 🤖'.split(' ') },
  { id: 'gestures', icon: '👍', label: 'Gestes', items: '👍 👎 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ ✋ 🤚 🖐️ 🖖 👋 🤝 🙏 👏 🙌 🫶 👐 🤲 💪 🦾 ✍️ 💅 🤳 🫵 👀 👁️ 👅 👄 🧠 🫀'.split(' ') },
  { id: 'hearts', icon: '❤️', label: 'Cœurs', items: '❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❤️‍🔥 ❤️‍🩹 💕 💞 💓 💗 💖 💘 💝 💟 ♥️ 😻 💌 💋 🔥 ✨ ⭐ 🌟 💫 💥 💯 ✅ ❌ ❓ ❗'.split(' ') },
  { id: 'nature', icon: '🌍', label: 'Espace & nature', items: '🌍 🌎 🌏 🌕 🌖 🌗 🌘 🌑 🌙 ☀️ ⭐ 🌟 ✨ ☄️ 🪐 🚀 🛸 🛰️ 👨‍🚀 👩‍🚀 🌌 🌠 🌈 ☁️ ⛈️ ❄️ 🔥 💧 🌊 🌸 🌹 🌻 🌲 🍀 🐶 🐱 🐭 🐰 🦊 🐻 🐼 🐨 🦁 🐸 🐵 🦄 🐢 🐙 🦋'.split(' ') },
  { id: 'food', icon: '🍕', label: 'Nourriture', items: '🍎 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥝 🍅 🥑 🌽 🥕 🍞 🧀 🍳 🥞 🍔 🍟 🍕 🌭 🌮 🌯 🍣 🍜 🍝 🍦 🍩 🍪 🎂 🍰 🍫 🍿 ☕ 🍵 🍺 🍻 🥂 🍷 🥤'.split(' ') },
  { id: 'activities', icon: '🎉', label: 'Activités', items: '⚽ 🏀 🏈 ⚾ 🎾 🏐 🏒 🥊 🎯 🎮 🕹️ 🎲 🎵 🎶 🎤 🎧 🎸 🥁 🎬 🎉 🎊 🎁 🏆 🥇 🚗 🚕 ✈️ 🚁 🏠 📱 💻 📷 🎥 💡 💰 🔔 📌'.split(' ') },
];
