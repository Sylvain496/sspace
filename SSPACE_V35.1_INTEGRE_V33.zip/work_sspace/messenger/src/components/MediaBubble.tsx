import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const urlCache = new Map<string, { url: string; exp: number }>();

export default function MediaBubble({ type, path, linkUrl }: { type: string; path?: string | null; linkUrl?: string | null }) {
  const [src, setSrc] = useState<string | null>(type === 'gif' ? linkUrl ?? null : null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (type === 'gif') { setSrc(linkUrl ?? null); return; }
    if (!path || !supabase) return;
    const hit = urlCache.get(path);
    if (hit && hit.exp > Date.now()) { setSrc(hit.url); return; }
    let alive = true;
    supabase.storage.from('chat-attachments').createSignedUrl(path, 3600).then(({ data, error }) => {
      if (!alive) return;
      if (error || !data?.signedUrl) { setFailed(true); return; }
      urlCache.set(path, { url: data.signedUrl, exp: Date.now() + 50 * 60_000 });
      setSrc(data.signedUrl);
    });
    return () => { alive = false; };
  }, [type, path, linkUrl]);

  if (failed) return <div className="media-fallback">Média indisponible</div>;
  if (!src) return <div className="media-fallback">Chargement du média…</div>;
  if (type === 'video') return <video className="chat-media" src={src} controls playsInline preload="metadata" />;
  if (type === 'audio') return <audio className="chat-audio" src={src} controls />;
  return <a href={src} target="_blank" rel="noreferrer"><img className="chat-media" src={src} alt={type === 'gif' ? 'GIF' : 'Photo'} loading="lazy" /></a>;
}
