import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

// Messenger entry lives in this directory. Keep the main SSPACE site in dist/ intact.
const messengerRoot = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  root: messengerRoot,
  base: '/messenger/',
  plugins: [react()],
  build: {
    outDir: '../dist/messenger',
    emptyOutDir: false,
  },
});
