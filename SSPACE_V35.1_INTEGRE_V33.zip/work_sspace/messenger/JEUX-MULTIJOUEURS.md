# SSPACE Messenger — jeux à deux

Les invitations de jeu sont des messages Messenger `game_invite` avec un lien de salle `sspace-game:<UUID>`. Les salles sont privées et limitées aux deux membres de la conversation. Le canal Realtime `game-room:<UUID>` utilise Broadcast et Presence privés, avec autorisation vérifiée par RLS.

## Jeux disponibles
- Street Racing : course arcade en perspective, simulation autoritaire côté hôte, commandes tactiles accélérer/freiner/direction.
- Kart Racing : course arcade utilisant le même moteur de course que Street Racing (différence visuelle encore limitée).
- Bowling : jeu à tour de rôle à 10 frames, deux lancers par joueur, score synchronisé et victoire/égalité.

## Transparence sur le rendu
Les scènes sont dessinées sur Canvas 2D avec perspective. Ce ne sont pas encore des scènes WebGL/Three.js et la physique reste arcade/simplifiée. Le zoom du jeu est réglable sans agrandir toute la fenêtre. L'interface Messenger a aussi un zoom global de 80 à 120 % dans Paramètres.

## Migration
Appliquer dans l'ordre les migrations `supabase/migrations/20261123010000_messenger_private_multiplayer_games.sql`, `20261123011000_private_memory_backstories.sql`, puis `20261123011100_private_memory_and_game_invites_hardening.sql` au projet Supabase SSPACE partagé. Le dossier `messenger/` contient aussi des copies des deux migrations mémoire/hardening pour le déploiement indépendant.

## Limites de validation
Les politiques et fonctions SQL ont été appliquées/vérifiées sur le projet Supabase. Le build Vite/TypeScript et les tests sur deux appareils n'ont pas pu être exécutés ici : les dépendances npm ne se sont pas installées avant expiration du délai. Il faut donc exécuter `npm ci && npm run build`, puis tester deux comptes distincts et deux appareils avant de déclarer la version validée en production.
