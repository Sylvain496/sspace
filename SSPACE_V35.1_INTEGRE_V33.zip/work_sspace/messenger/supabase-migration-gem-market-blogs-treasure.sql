-- SSPACE V32: marché d'émeraudes, blogs/commentaires et indices de chasse.
-- Adapté au schéma Supabase réel : auth.users UUID, profiles UUID,
-- emerald_catalog + emerald_collection (collection unique, pas de quantité).
create extension if not exists pgcrypto;

-- Familles facultatives pour filtrer les demandes d'échange.
alter table public.emerald_catalog add column if not exists family text;
alter table public.emerald_catalog add column if not exists rarity text;
alter table public.emerald_catalog add column if not exists emoji text default '💎';
update public.emerald_catalog set family = case page when 1 then 'Classiques' when 2 then 'Précieuses' when 3 then 'Prismatiques' when 4 then 'Cosmiques' else 'Légendaires' end where family is null;
update public.emerald_catalog set rarity = case page when 1 then 'Commune' when 2 then 'Peu commune' when 3 then 'Rare' when 4 then 'Épique' else 'Légendaire' end where rarity is null;
alter table public.emerald_collection drop constraint if exists emerald_collection_source_check;
alter table public.emerald_collection add constraint emerald_collection_source_check check(source = any(array['start','welcome','pickup','gift','trade','trade_return']::text[]));

create table if not exists public.gem_trades (
 id uuid primary key default gen_random_uuid(),
 seller_id uuid not null references auth.users(id) on delete cascade,
 gem_id smallint not null references public.emerald_catalog(id) on delete restrict,
 quantity smallint not null default 1 check(quantity = 1),
 want_family text,
 want_gem_id smallint references public.emerald_catalog(id) on delete set null,
 status text not null default 'open' check(status in ('open','done','cancelled')),
 created_at timestamptz not null default now(),
 completed_at timestamptz
);
create index if not exists idx_trades_open on public.gem_trades(status,created_at desc) where status='open';
create index if not exists idx_trades_seller on public.gem_trades(seller_id,status);
create table if not exists public.gem_trade_history (
 id uuid primary key default gen_random_uuid(),
 trade_id uuid references public.gem_trades(id) on delete set null,
 seller_id uuid not null references auth.users(id) on delete restrict,
 buyer_id uuid not null references auth.users(id) on delete restrict,
 gem_id smallint not null references public.emerald_catalog(id) on delete restrict,
 buyer_gem_id smallint references public.emerald_catalog(id) on delete set null,
 quantity smallint not null default 1 check(quantity=1),
 exchanged_at timestamptz not null default now()
);
alter table public.gem_trades enable row level security;
alter table public.gem_trade_history enable row level security;
grant select on public.gem_trades,public.gem_trade_history to authenticated;
drop policy if exists gem_trades_read_open on public.gem_trades;
create policy gem_trades_read_open on public.gem_trades for select to authenticated using(status='open' or seller_id=auth.uid());
drop policy if exists gem_trade_history_participant on public.gem_trade_history;
create policy gem_trade_history_participant on public.gem_trade_history for select to authenticated using(seller_id=auth.uid() or buyer_id=auth.uid());
revoke insert,update,delete on public.gem_trades,public.gem_trade_history from anon,authenticated;

create or replace function public.gem_trade_create(p_gem_id smallint,p_want_family text default null,p_want_gem_id smallint default null)
returns uuid language plpgsql security definer set search_path='' as $$
declare me uuid:=auth.uid(); tid uuid;
begin
 if me is null then raise exception 'Connexion requise'; end if;
 if p_gem_id is null or not exists(select 1 from public.emerald_catalog where id=p_gem_id) then raise exception 'Émeraude invalide'; end if;
 if p_want_gem_id=p_gem_id then raise exception 'Une émeraude ne peut pas être demandée en échange d’elle-même'; end if;
 if p_want_gem_id is not null and not exists(select 1 from public.emerald_catalog where id=p_want_gem_id) then raise exception 'Émeraude demandée invalide'; end if;
 delete from public.emerald_collection where user_id=me and emerald_id=p_gem_id;
 if not found then raise exception 'Tu ne possèdes pas cette émeraude'; end if;
 insert into public.gem_trades(seller_id,gem_id,want_family,want_gem_id) values(me,p_gem_id,nullif(left(trim(coalesce(p_want_family,'')),40),''),p_want_gem_id) returning id into tid;
 return tid;
exception when others then raise;
end $$;

create or replace function public.gem_trade_accept(p_trade_id uuid)
returns jsonb language plpgsql security definer set search_path='' as $$
declare me uuid:=auth.uid(); t public.gem_trades; buyer_gem smallint;
begin
 if me is null then raise exception 'Connexion requise'; end if;
 select * into t from public.gem_trades where id=p_trade_id and status='open' for update;
 if not found then raise exception 'Offre introuvable ou déjà traitée'; end if;
 if t.seller_id=me then raise exception 'Tu ne peux pas accepter ta propre offre'; end if;
 if t.want_gem_id is not null then buyer_gem:=t.want_gem_id;
 elsif t.want_family is not null then
  select c.id into buyer_gem from public.emerald_collection ec join public.emerald_catalog c on c.id=ec.emerald_id
  where ec.user_id=me and c.family=t.want_family order by c.id limit 1;
  if buyer_gem is null then raise exception 'Tu ne possèdes aucune émeraude de la famille demandée'; end if;
 end if;
 if buyer_gem is not null then
  delete from public.emerald_collection where user_id=me and emerald_id=buyer_gem;
  if not found then raise exception 'Tu ne possèdes pas l’émeraude demandée'; end if;
  insert into public.emerald_collection(user_id,emerald_id,source) values(t.seller_id,buyer_gem,'trade') on conflict do nothing;
  if not found then raise exception 'Le vendeur possède déjà cette émeraude'; end if;
 end if;
 insert into public.emerald_collection(user_id,emerald_id,source) values(me,t.gem_id,'trade') on conflict do nothing;
 if not found then raise exception 'Tu possèdes déjà cette émeraude'; end if;
 update public.gem_trades set status='done',completed_at=now() where id=t.id;
 insert into public.gem_trade_history(trade_id,seller_id,buyer_id,gem_id,buyer_gem_id,quantity) values(t.id,t.seller_id,me,t.gem_id,buyer_gem,1);
 return jsonb_build_object('ok',true,'gem_id',t.gem_id,'received_gem_id',buyer_gem);
end $$;

create or replace function public.gem_trade_cancel(p_trade_id uuid)
returns void language plpgsql security definer set search_path='' as $$
declare me uuid:=auth.uid(); t public.gem_trades;
begin
 if me is null then raise exception 'Connexion requise'; end if;
 select * into t from public.gem_trades where id=p_trade_id and seller_id=me and status='open' for update;
 if not found then raise exception 'Offre introuvable'; end if;
 insert into public.emerald_collection(user_id,emerald_id,source) values(me,t.gem_id,'trade_return') on conflict do nothing;
 update public.gem_trades set status='cancelled' where id=t.id;
end $$;
revoke all on function public.gem_trade_create(smallint,text,smallint),public.gem_trade_accept(uuid),public.gem_trade_cancel(uuid) from public,anon;
grant execute on function public.gem_trade_create(smallint,text,smallint),public.gem_trade_accept(uuid),public.gem_trade_cancel(uuid) to authenticated;

-- Blogues et commentaires : tables dédiées, avec UUID et clans SSPACE existants.
create table if not exists public.blogs (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 clan_id uuid references public.groups(id) on delete set null,
 title text not null check(char_length(trim(title)) between 1 and 180),
 content text not null default '', theme varchar(30), views integer not null default 0 check(views>=0),
 published boolean not null default true, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.blog_comments (
 id uuid primary key default gen_random_uuid(),
 blog_id uuid not null references public.blogs(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 content text not null check(char_length(trim(content)) between 1 and 2000),
 created_at timestamptz not null default now()
);
create index if not exists idx_blogs_created on public.blogs(created_at desc);
create index if not exists idx_blogs_views on public.blogs(views desc);
create index if not exists idx_blog_comments_recent on public.blog_comments(blog_id,created_at);
alter table public.blogs enable row level security;
alter table public.blog_comments enable row level security;
grant select,insert,update,delete on public.blogs,public.blog_comments to authenticated;
drop policy if exists blogs_read_published on public.blogs;
create policy blogs_read_published on public.blogs for select to authenticated using(published or user_id=auth.uid() or (clan_id is not null and exists(select 1 from public.group_members gm where gm.group_id=clan_id and gm.user_id=auth.uid() and gm.status='accepted')));
drop policy if exists blogs_insert_own on public.blogs;
create policy blogs_insert_own on public.blogs for insert to authenticated with check(user_id=auth.uid() and (clan_id is null or exists(select 1 from public.group_members gm where gm.group_id=clan_id and gm.user_id=auth.uid() and gm.status='accepted')));
drop policy if exists blogs_update_own on public.blogs;
create policy blogs_update_own on public.blogs for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
drop policy if exists blogs_delete_own on public.blogs;
create policy blogs_delete_own on public.blogs for delete to authenticated using(user_id=auth.uid());
drop policy if exists blog_comments_read on public.blog_comments;
create policy blog_comments_read on public.blog_comments for select to authenticated using(exists(select 1 from public.blogs b where b.id=blog_id and (b.published or b.user_id=auth.uid() or (b.clan_id is not null and exists(select 1 from public.group_members gm where gm.group_id=b.clan_id and gm.user_id=auth.uid() and gm.status='accepted')))));
drop policy if exists blog_comments_insert on public.blog_comments;
create policy blog_comments_insert on public.blog_comments for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.blogs b where b.id=blog_id and b.published));
drop policy if exists blog_comments_delete on public.blog_comments;
create policy blog_comments_delete on public.blog_comments for delete to authenticated using(user_id=auth.uid() or exists(select 1 from public.blogs b where b.id=blog_id and b.user_id=auth.uid()));

create or replace function public.blog_increment_view(p_blog_id uuid) returns void language sql security definer set search_path='' as $$
 update public.blogs set views=views+1 where id=p_blog_id and published=true
$$;
revoke all on function public.blog_increment_view(uuid) from public,anon;
grant execute on function public.blog_increment_view(uuid) to authenticated;

-- Messages de groupe (clans) : accès réservé aux membres acceptés.
create table if not exists public.group_messages (
 id uuid primary key default gen_random_uuid(), group_id uuid not null references public.groups(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 content text not null check(char_length(trim(content)) between 1 and 2000), created_at timestamptz not null default now());
create index if not exists group_messages_recent on public.group_messages(group_id,created_at desc);
alter table public.group_messages enable row level security;
grant select,insert,delete on public.group_messages to authenticated;
drop policy if exists group_messages_member_read on public.group_messages;
create policy group_messages_member_read on public.group_messages for select to authenticated using(exists(select 1 from public.group_members gm where gm.group_id=group_messages.group_id and gm.user_id=auth.uid() and gm.status='accepted'));
drop policy if exists group_messages_member_insert on public.group_messages;
create policy group_messages_member_insert on public.group_messages for insert to authenticated with check(user_id=auth.uid() and exists(select 1 from public.group_members gm where gm.group_id=group_messages.group_id and gm.user_id=auth.uid() and gm.status='accepted'));
drop policy if exists group_messages_own_delete on public.group_messages;
create policy group_messages_own_delete on public.group_messages for delete to authenticated using(user_id=auth.uid());

-- Chasse hebdomadaire et indices progressifs (cibles UUID, sans table users(id)).
create table if not exists public.treasure_events (
 id uuid primary key default gen_random_uuid(), week_start date not null unique,
 status text not null default 'active' check(status in ('active','closed')), created_at timestamptz not null default now()
);
create table if not exists public.treasure_gems (
 id uuid primary key default gen_random_uuid(), event_id uuid not null references public.treasure_events(id) on delete cascade,
 hint text not null, current_hint text not null, target_type text not null check(target_type in ('blog','profil','clan_message')),
 target_id uuid not null, found_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now(), unique(event_id,target_type,target_id)
);
create table if not exists public.treasure_hint_unlocks (
 id uuid primary key default gen_random_uuid(), treasure_gem_id uuid not null references public.treasure_gems(id) on delete cascade,
 extra_hint text not null, unlock_day smallint not null check(unlock_day between 0 and 6), created_at timestamptz not null default now(), unique(treasure_gem_id,unlock_day)
);
alter table public.treasure_events enable row level security;
alter table public.treasure_gems enable row level security;
alter table public.treasure_hint_unlocks enable row level security;
grant select on public.treasure_events,public.treasure_gems,public.treasure_hint_unlocks to authenticated;
drop policy if exists treasure_events_read on public.treasure_events;
create policy treasure_events_read on public.treasure_events for select to authenticated using(status='active');
drop policy if exists treasure_gems_read on public.treasure_gems;
create policy treasure_gems_read on public.treasure_gems for select to authenticated using(exists(select 1 from public.treasure_events e where e.id=event_id and e.status='active'));
drop policy if exists treasure_hints_read on public.treasure_hint_unlocks;
create policy treasure_hints_read on public.treasure_hint_unlocks for select to authenticated using(exists(select 1 from public.treasure_gems g join public.treasure_events e on e.id=g.event_id where g.id=treasure_gem_id and e.status='active'));

create or replace function public.treasure_refresh_hints() returns integer language plpgsql security definer set search_path='' as $$
declare wk date:=date_trunc('week',now() at time zone 'America/Toronto')::date; eid uuid; day_no int; rec record; n int:=0; target_label text; hint_text text; hint_count int;
begin
 insert into public.treasure_events(week_start,status) values(wk,'active') on conflict(week_start) do update set status='active' returning id into eid;
 insert into public.treasure_gems(event_id,hint,current_hint,target_type,target_id)
 select eid,'Trouve le contenu communautaire correspondant.','Trouve le contenu communautaire correspondant.','blog',b.id from public.blogs b where b.published=true order by b.created_at desc limit 4 on conflict do nothing;
 insert into public.treasure_gems(event_id,hint,current_hint,target_type,target_id)
 select eid,'Retrouve ce membre SSPACE.','Retrouve ce membre SSPACE.','profil',p.id from public.profiles p where p.is_ai_profile=false order by p.created_at desc limit 4 on conflict do nothing;
 insert into public.treasure_gems(event_id,hint,current_hint,target_type,target_id)
 select eid,'Retrouve ce message de groupe.','Retrouve ce message de groupe.','clan_message',m.id from public.group_messages m order by m.created_at desc limit 4 on conflict do nothing;
 day_no:=extract(isodow from (now() at time zone 'America/Toronto'))::int-1;
 for rec in select g.* from public.treasure_gems g where g.event_id=eid and g.found_by is null loop
  select count(*)::int into hint_count from public.treasure_hint_unlocks u where u.treasure_gem_id=rec.id;
  if hint_count >= least(3,floor(day_no/2.0)::int) then continue; end if;
  target_label:=null;
  if rec.target_type='blog' then select title into target_label from public.blogs where id=rec.target_id and published=true;
  elsif rec.target_type='profil' then select coalesce(display_name,username) into target_label from public.profiles where id=rec.target_id;
  elsif rec.target_type='clan_message' then select content into target_label from public.group_messages where id=rec.target_id; end if;
  if target_label is null then continue; end if;
  if hint_count=0 then hint_text:=case rec.target_type when 'blog' then 'La cible est un article de blogue.' when 'profil' then 'La cible est un profil SSPACE.' else 'La cible est un message de groupe.' end;
  elsif hint_count=1 then hint_text:='Le titre ou nom commence par « '||left(target_label,1)||' ».';
  else hint_text:='Le titre ou nom comporte '||char_length(target_label)||' caractères.'; end if;
  insert into public.treasure_hint_unlocks(treasure_gem_id,extra_hint,unlock_day) values(rec.id,hint_text,day_no) on conflict do nothing;
  update public.treasure_gems set current_hint=hint_text where id=rec.id; n:=n+1;
 end loop;
 return n;
end $$;
revoke all on function public.treasure_refresh_hints() from public,anon,authenticated;
-- Cron appelle la fonction en contexte privilégié.
do $$ begin
 if exists(select 1 from pg_extension where extname='pg_cron') then
  perform cron.unschedule(jobid) from cron.job where jobname='sspace-treasure-hints-daily';
  perform cron.schedule('sspace-treasure-hints-daily','0 8 * * *',$cmd$select public.treasure_refresh_hints();$cmd$);
 end if;
exception when undefined_table or undefined_function then null; end $$;

-- Suggestions hebdomadaires : articles blogs (nouvelle table) + archive de compatibilité + groupes publics.
create or replace function public.generate_memory_suggestion()
returns public.memory_suggestions language plpgsql security definer set search_path='' as $function$
declare uid uuid:=auth.uid(); kws text[]; blog_row record; clan_row record; ev record; outrow public.memory_suggestions;
begin
 if uid is null then raise exception 'Authentication required'; end if;
 select coalesce(array(select distinct x from (select unnest(b.keywords) x from private.media_backstories b where b.user_id=uid) t where x is not null and length(trim(x))>1 limit 40),'{}'::text[]) into kws;
 select * into outrow from public.memory_suggestions where user_id=uid and week_start=date_trunc('week',now())::date limit 1;
 if found then return outrow; end if;
 if cardinality(kws)>0 then
  select z.id,z.title,z.created_at into blog_row from (
   select a.id,a.title,a.created_at from public.memory_blog_articles a where a.published=true and a.keywords && kws and (a.clan_id is null or exists(select 1 from public.group_members gm where gm.group_id=a.clan_id and gm.user_id=uid and gm.status='accepted'))
   union all
   select b.id,b.title,b.created_at from public.blogs b where b.published=true and exists(select 1 from unnest(kws) k where coalesce(b.title,'') ilike '%'||k||'%' or coalesce(b.content,'') ilike '%'||k||'%' or coalesce(b.theme,'') ilike '%'||k||'%') and (b.clan_id is null or exists(select 1 from public.group_members gm where gm.group_id=b.clan_id and gm.user_id=uid and gm.status='accepted'))
  ) z order by z.created_at desc limit 1;
 end if;
 if found then insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start) values(uid,'Un article de blog pourrait t’intéresser : '||blog_row.title,array_to_string(kws,', '),'blog',blog_row.id,date_trunc('week',now())::date) returning * into outrow; return outrow; end if;
 if cardinality(kws)>0 then select g.* into clan_row from public.groups g where lower(coalesce(g.visibility,''))='public' and not exists(select 1 from public.group_members gm where gm.group_id=g.id and gm.user_id=uid and gm.status='accepted') and exists(select 1 from unnest(kws) k where coalesce(g.name,'') ilike '%'||k||'%' or coalesce(g.description,'') ilike '%'||k||'%') order by g.created_at desc limit 1; end if;
 if found then insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start) values(uid,'Un clan pourrait correspondre à tes centres d’intérêt : '||clan_row.name,array_to_string(kws,', '),'clan',clan_row.id,date_trunc('week',now())::date) returning * into outrow; return outrow; end if;
 if cardinality(kws)>0 then select e.* into ev from public.events e where e.keywords && kws and (e.event_date is null or e.event_date>=now()) order by e.event_date nulls last limit 1; end if;
 if found then insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start) values(uid,'Une activité pourrait te plaire : '||ev.title,array_to_string(kws,', '),'event',ev.id,date_trunc('week',now())::date) returning * into outrow;
 else insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start) values(uid,case when cardinality(kws)>0 then 'Choisis une activité hors écran liée à tes souvenirs : '||array_to_string(kws[1:least(cardinality(kws),4)],', ') else 'Ajoute une petite histoire privée à une photo ou une vidéo pour faire émerger des idées qui te ressemblent.' end,array_to_string(kws,', '),'none',null,date_trunc('week',now())::date) returning * into outrow; end if;
 return outrow;
end; $function$;
revoke all on function public.generate_memory_suggestion() from public,anon;
grant execute on function public.generate_memory_suggestion() to authenticated;
