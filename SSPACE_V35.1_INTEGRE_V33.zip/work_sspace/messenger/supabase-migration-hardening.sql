-- Enforce one generated suggestion per user per calendar week.
alter table public.memory_suggestions add column if not exists week_start date not null default (date_trunc('week',now())::date);
create unique index if not exists memory_suggestions_one_per_week on public.memory_suggestions(user_id,week_start);

-- Keep private narratives out of ordinary public media SELECT responses.
create schema if not exists private;
revoke all on schema private from public,anon,authenticated;
create table if not exists private.media_backstories(
 media_table text not null check(media_table in ('posts','profile_album_photos')),
 media_id uuid not null,
 user_id uuid not null references public.profiles(id) on delete cascade,
 backstory text not null,
 keywords text[] not null default '{}',
 updated_at timestamptz not null default now(),
 primary key(media_table,media_id)
);
alter table private.media_backstories enable row level security;
revoke all on private.media_backstories from public,anon,authenticated;

create or replace function public.set_media_backstory(p_table text,p_media_id uuid,p_backstory text)
returns table(media_id uuid,keywords text[]) language plpgsql security definer set search_path='' as $$
declare k text[]; owned boolean;
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 if p_backstory is null or length(p_backstory)>5000 then raise exception 'Backstory must be 0-5000 characters'; end if;
 if p_table='posts' then select exists(select 1 from public.posts where id=p_media_id and user_id=auth.uid()) into owned;
 elsif p_table='profile_album_photos' then select exists(select 1 from public.profile_album_photos where id=p_media_id and user_id=auth.uid()) into owned;
 else raise exception 'Unsupported media table'; end if;
 if not owned then raise exception 'Media not found or not owned by user'; end if;
 k:=public.sspace_extract_memory_keywords(p_backstory);
 insert into private.media_backstories(media_table,media_id,user_id,backstory,keywords,updated_at)
 values(p_table,p_media_id,auth.uid(),p_backstory,k,now())
 on conflict(media_table,media_id) do update set backstory=excluded.backstory,keywords=excluded.keywords,updated_at=now()
 where private.media_backstories.user_id=auth.uid();
 return query select p_media_id,k;
end; $$;
create or replace function public.get_media_backstory(p_table text,p_media_id uuid)
returns table(media_id uuid,backstory text,keywords text[]) language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null then raise exception 'Authentication required'; end if;
 return query select b.media_id,b.backstory,b.keywords from private.media_backstories b
 where b.media_table=p_table and b.media_id=p_media_id and b.user_id=auth.uid();
end; $$;
create or replace function public.generate_memory_suggestion()
returns public.memory_suggestions language plpgsql security definer set search_path='' as $$
declare uid uuid:=auth.uid(); kws text[]; ev record; outrow public.memory_suggestions;
begin
 if uid is null then raise exception 'Authentication required'; end if;
 select coalesce(array(select distinct x from (select unnest(b.keywords) x from private.media_backstories b where b.user_id=uid) t limit 40),'{}'::text[]) into kws;
 select * into outrow from public.memory_suggestions where user_id=uid and week_start=date_trunc('week',now())::date limit 1;
 if found then return outrow; end if;
 select e.* into ev from public.events e where cardinality(kws)>0 and e.keywords && kws and (e.event_date is null or e.event_date>=now()) order by e.event_date nulls last limit 1;
 if found then
  insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
  values(uid,'Une activité pourrait te plaire : '||ev.title,array_to_string(kws,', '),'event',ev.id,date_trunc('week',now())::date) returning * into outrow;
 else
  insert into public.memory_suggestions(user_id,suggestion,reason,link_type,link_id,week_start)
  values(uid,case when cardinality(kws)>0 then 'Choisis une activité hors écran liée à tes souvenirs : '||array_to_string(kws[1:least(cardinality(kws),4)],', ') else 'Ajoute une petite histoire privée à une photo ou une vidéo pour faire émerger des idées qui te ressemblent.' end,array_to_string(kws,', '),'none',null,date_trunc('week',now())::date) returning * into outrow;
 end if;
 return outrow;
end; $$;
revoke all on function public.set_media_backstory(text,uuid,text) from public,anon;
revoke all on function public.get_media_backstory(text,uuid) from public,anon;
revoke all on function public.generate_memory_suggestion() from public,anon;
grant execute on function public.set_media_backstory(text,uuid,text) to authenticated;
grant execute on function public.get_media_backstory(text,uuid) to authenticated;
grant execute on function public.generate_memory_suggestion() to authenticated;

-- Allow the Messenger game invitation message type and its opaque room deep-link.
alter table public.messages drop constraint if exists messages_message_type_check;
alter table public.messages add constraint messages_message_type_check
 check(message_type=any(array['text','image','audio','link','video','gif','game_invite']));
alter table public.messages drop constraint if exists messages_link_url_check;
alter table public.messages add constraint messages_link_url_check check(
 link_url is null or (length(link_url)<=2048 and (link_url ~ '^https?://' or link_url ~ '^sspace-game:[0-9a-fA-F-]{36}$'))
);

-- Private presence + broadcast channels are authorized only for the room's two players.
drop policy if exists messenger_game_room_broadcast_read on realtime.messages;
create policy messenger_game_room_broadcast_read on realtime.messages for select to authenticated
using(extension in ('broadcast','presence') and exists(
 select 1 from public.game_rooms r where realtime.topic()='game-room:'||r.id::text and auth.uid() in(r.player_one,r.player_two)
));
drop policy if exists messenger_game_room_broadcast_write on realtime.messages;
create policy messenger_game_room_broadcast_write on realtime.messages for insert to authenticated
with check(extension in ('broadcast','presence') and exists(
 select 1 from public.game_rooms r where realtime.topic()='game-room:'||r.id::text and auth.uid() in(r.player_one,r.player_two)
));

-- Weekly generator, Monday 03:00 UTC, respecting profiles.memories_enabled.
create or replace function public.run_weekly_memory_suggestions()
returns void language plpgsql security definer set search_path='' as $$
declare p record;
begin
 for p in select id from public.profiles where memories_enabled=true loop
  perform set_config('request.jwt.claim.sub',p.id::text,true);
  perform public.generate_memory_suggestion();
 end loop;
end; $$;
revoke all on function public.run_weekly_memory_suggestions() from public,anon,authenticated;
do $$
declare j record;
begin
 for j in select jobid from cron.job where jobname='sspace-memory-suggestions-weekly' loop
  perform cron.unschedule(j.jobid);
 end loop;
 perform cron.schedule('sspace-memory-suggestions-weekly','0 3 * * 1','select public.run_weekly_memory_suggestions();');
end; $$;
