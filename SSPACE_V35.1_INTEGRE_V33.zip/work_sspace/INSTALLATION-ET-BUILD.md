# Correction du build / installation

Les dépendances du serveur (Express, CORS, dotenv, rate-limit, file-type, Helmet, Multer et pg) ont été retirées du package.json racine : elles sont déclarées dans `backend/package.json` et ne sont pas requises pour compiler le client Vite/Messenger. Cela réduit l'installation du build frontend et évite d'installer deux fois ces paquets au niveau racine.

Commande de build racine : `node scripts/copy-site.mjs && tsc -b messenger/tsconfig.json && vite build --config messenger/vite.config.ts`

Le build n'a pas été exécuté avec succès ici : l'installation npm a expiré. Cette modification réduit les dépendances racine, mais ne constitue pas une confirmation de build.
