# SSPACE V28 — Street Racing 3D

Ajout de `jeux-espace/street-racing-3d.html` et lien depuis le hub des jeux.

Fonctions : circuit fermé urbain de nuit, voitures 3D détaillées, trafic rival IA, accélération/freinage/direction/nitro, collisions, gestion de sortie de piste, 3 tours, chronomètre et commandes tactiles/clavier. Rendu Three.js optimisé avec pixel ratio plafonné à 1.5, ombres 1024 et éclairages locaux.

Le jeu charge Three.js depuis jsDelivr : connexion Internet requise. Les essais statiques (structure HTML, syntaxe JavaScript) sont effectués au packaging; aucune validation de performance sur téléphone Android physique ni déploiement en ligne n'est revendiqué.
