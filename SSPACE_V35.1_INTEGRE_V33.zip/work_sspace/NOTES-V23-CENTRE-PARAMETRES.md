# SSPACE V23 — Centre de paramètres

## Ajouts
- Centre de contrôle visuel intégré à la page Paramètres existante.
- Recherche locale par mots-clés (thème, langue, accessibilité, bio, courriel, pseudo, présence, blocages, publications masquées, vérification).
- Résultats cliquables qui font défiler vers la rubrique correspondante.
- Raccourcis vers Apparence & langue, Profil & compte, Confidentialité et Vérification.
- Mise en page responsive et prise en compte de `prefers-reduced-motion`.

## Conservation
- Aucun champ, bouton, identifiant ou gestionnaire existant n'a été supprimé.
- La colonne latérale de navigation est conservée.
- Les contrôles existants gardent leurs identifiants afin de préserver les intégrations JavaScript/Supabase.

## Limites de validation
- Vérifier les scripts JavaScript intégrés et l'intégrité de l'archive.
- Les interactions liées à Supabase nécessitent une connexion réelle et des tests dans l'environnement déployé.
