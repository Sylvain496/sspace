# SSPACE V17.3 — Vérification officielle

- Ajoute aux Paramètres de l’app un formulaire pour demander le badge du profil public ou d’une page entreprise/créateur.
- Les demandes sont visibles dans le Centre MODO Gold avec liens de preuve, approbation/refus et note du modérateur.
- Affiche un compteur rouge près du menu MODO pour les demandes en attente (rafraîchi toutes les 30 secondes).
- Ajoute la permission MODO « Vérification des badges » pour les modérateurs délégués.
- Le badge bleu apparaît sur les profils et pages approuvés.
- La base protège les champs de vérification : un membre ne peut pas s’attribuer lui-même un badge.

La migration `20261123000500_sspace_verification_workflow.sql` est déjà appliquée au projet Supabase SIKX et les objets ont été vérifiés. Le JavaScript inline et les identifiants HTML ont été vérifiés. Les essais réels d’envoi, de notification MODO et d’approbation nécessitent deux comptes distincts et doivent être effectués après publication.


## Livraison unifiée avec Messenger

- Le code Messenger Vite/React a été synchronisé avec la version comprenant l’intro fusée et la présence Realtime SSPACE.
- Le déploiement racine produit `dist/` pour le site social et `dist/messenger/` pour Messenger dans la même compilation.
- Aucun deuxième projet ou domaine n’est nécessaire; les routes restent `/` et `/messenger/`.
- La compilation complète doit être exécutée par l’hébergeur (`npm install` puis `npm run build`). Elle n’a pas pu être exécutée dans cet environnement faute de `node_modules` et de dépendances installées.
