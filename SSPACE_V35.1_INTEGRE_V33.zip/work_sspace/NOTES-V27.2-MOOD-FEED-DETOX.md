# SSPACE V27.2 — Mood Feed et Mode Détox

## Ajouts
- Mood Feed en langage naturel avec durée réglable : 1 h, 24 h, 3 jours ou 7 jours.
- Filtres locaux pour période, thème, photos, vidéos, audio, blogs/liens et membres ayant publié récemment.
- Désactivation du Mood en un clic et expiration enregistrée dans Supabase.
- Mode Détox : masquage des compteurs J’aime, pagination manuelle et rappel après 30 minutes.

## Garde-fous
- Authentification Supabase existante conservée.
- `mood_feeds.user_id` référence `auth.users(id)`; RLS limite chaque membre à ses propres préférences.
- Aucun moteur de connexion parallèle et aucune modification des comptes, messages, amis ou appels.
- Le filtre régional est volontairement signalé comme non actif : le schéma actuel ne fournit pas de région fiable.
- « Profils actifs cette semaine » est approché par les membres ayant publié durant les sept derniers jours; ce n’est pas un relevé de présence.

## Migration
Appliquer `site/supabase/migrations/20261123003000_mood_feed_preferences.sql` une seule fois dans le projet Supabase SSPACE.

## Vérifications
JavaScript inline vérifié avec `node --check`. Build Vite/TypeScript et tests de bout en bout non certifiés dans cet environnement.
