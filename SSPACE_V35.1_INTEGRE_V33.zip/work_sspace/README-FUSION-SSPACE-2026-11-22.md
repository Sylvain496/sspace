# SSPACE V10 — fusion des fonctions demandées

Cette archive fusionne le code de la version FUSION-COMPLETE avec les éléments du ZIP communautaire Collections/Messenger/Thèmes.

## Inclus
- Site SSPACE et intégration LIVE / chat LIVE par salle présents dans la base FUSION-COMPLETE.
- Messenger : appels audio/vidéo WebRTC, bulles individuelles, thèmes de conversation, thèmes de couleur, animations, apparence sombre/clair/automatique, paramètres de présence (invisible 15 min, 1 h, 8 h, 24 h ou jusqu'à réactivation), dernière activité affichée.
- Hub communautaire : chat global, collection de départ, demandes d'objets, cadeaux de doubles et migration SQL restaurée.
- Alex, jeux, site, configuration Vercel/Netlify conservés.

## Avant déploiement
1. Garder la version actuellement en production en sauvegarde.
2. Dans Supabase SQL Editor, exécuter le fichier `site/supabase/migrations/20261122120000_community_hub_collections.sql` pour créer les tables/RPC du hub Collection.
3. Configurer les variables Vite Messenger et les variables de l'API Alex selon les README d'origine. Ne jamais mettre de clé `service_role` dans le navigateur.
4. Déployer avec les paramètres du projet racine; le build complet n'a pas pu être validé dans cet environnement parce que les dépendances npm ne sont pas installées et le registre npm est inaccessible.

## Limites vérifiées
- L'option invisible en Messenger met à jour `profiles.show_online` et programme le retour automatique sur cet appareil. Une minuterie navigateur n'est pas un système serveur fiable si le navigateur est fermé; la durée « jusqu'à réactivation » reste persistante localement.
- Les appels WebRTC peuvent nécessiter des serveurs TURN sur certains réseaux; configurer `VITE_TURN_URLS`, `VITE_TURN_USERNAME`, `VITE_TURN_CREDENTIAL`.
- La diffusion vidéo LIVE P2P ne remplace pas une infrastructure de streaming pour les grands auditoires.

## V12 — nom doré en halo, GIF de publication, albums
- Nom de profil : cadre doré retiré, halo lumineux doré animé autour des lettres.
- Fenêtre GIF (Publier / Blogue) : remontée au premier plan, recherche + suggestions (Tendances, Bravo, Rire…).
- Albums : clic sur une photo → visionneuse avec j'aime et commentaires. SQL à exécuter : `site/supabase/migrations/20261122200000_album_photo_likes_comments.sql`.

## V13 — icône du nom, effets de texte, présence
- Icône du nom : le profil permet de remplacer 👑 par un objet/emoji au choix (`profiles.name_icon`).
- 12 nouveaux effets de texte pour les publications (Halo, Feu, Glace, Or, Glitch, Pulsation, Secousse, Étincelles, Dégradé, Électrique, Contour, Rétro 3D).
- Présence : point vert (en ligne) ou mini bulle « 5 min / 2 h / 3 j » (temps depuis la déconnexion) sur les avatars du site et de Messenger.
- SQL à exécuter : `site/supabase/migrations/20261122220000_name_icon_and_more_text_effects.sql` (avec la migration V12 des albums si pas déjà faite).

## V14 — bulles de profil dans les conversations
- Site (discussion principale, lanceur, fenêtres flottantes) et Messenger : la photo de profil du contact et la tienne apparaissent à côté des messages (sur le dernier message d'une série). Le contact a aussi le point vert s'il est en ligne ; toucher sa bulle ouvre son profil sur le site.

## V14 — correctifs album + choix d'icône du nom
- Album (profil + profil public) : les boutons ♡ J'aime et 💬 commentaires étaient coupés hors de la vignette (image à 100 % de hauteur + overflow caché). Ils sont maintenant superposés en bas de la photo. Marge par défaut du `<figure>` retirée. Visionneuse : le champ de commentaire n'est plus coupé.
- Clic sur l'icône à côté du nom (sur ton profil) : ouvre une fenêtre avec objets et emblèmes, emoji personnalisé, « Par défaut » (👑) et « Aucune ».
- Prérequis Supabase : migrations 20261122200000 (j'aime/commentaires) et 20261122220000 (name_icon).

## V16 — Bibliothèque d'émeraudes 4D (remplace la collection de gemmes V15)
- Menu « 📚 Bibliothèque d'émeraudes » : 80 émeraudes uniques en 5 pages de 16 (Classiques, Précieuses, Prismatiques, Cosmiques, Légendaires). Colorées si débloquées, sombres sinon.
- Nouveau compte : 4 émeraudes différentes au hasard (page 1). Comptes existants : 13 émeraudes différentes au hasard (page 1), une seule fois.
- Clic sur une émeraude sombre : fenêtre pour la demander à un ami qui l'a (notification ; l'ami est amené directement dans sa bibliothèque).
- Clic sur une des siennes : liste des amis qui ne l'ont pas ; l'envoi apparaît tout de suite dans leur bibliothèque (on garde la sienne).
- Bibliothèques des membres avec % en temps réel ; bouton « 📚 Bibliothèque » dans les profils publics.
- Champ d'étincelles : 10 ramassages par jour pour trouver des émeraudes (pages avancées plus rares).
- Prérequis Supabase : exécuter `supabase/migrations/20261122240000_emerald_library.sql` (la migration V15 des gemmes est supprimée).

## V16.8 — missions et demandes de gemmes
- Mission hebdomadaire Double publication : 2 publications avec image + au moins 1 J'aime d'un autre membre, récompense d'une émeraude manquante.
- Recherche d'un ami par nom ou @pseudo depuis une gemme verrouillée; seuls les amis acceptés possédant la gemme sont proposés.
- Une demande crée une notification SSPACE au destinataire et peut être traitée depuis sa bibliothèque.
- Appliquer dans Supabase, après la migration de la bibliothèque d'émeraudes : `site/supabase/migrations/20261122250000_emerald_weekly_missions.sql`.
