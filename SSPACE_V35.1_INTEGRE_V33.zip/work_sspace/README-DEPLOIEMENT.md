# SSPACE V10 — paquet unifié Vercel (Social + Messenger + Jeux)

Ce dépôt conserve l'application sociale SSPACE et ses appels WebRTC existants, et ajoute Messenger sur le même domaine avec de vrais appels audio/vidéo WebRTC. L'Espace de jeux est publié sous `/jeux-espace/`.

## Version V17.3 — Vérification + Messenger sur le même déploiement

Le site principal inclut maintenant le formulaire de demande de badge dans les Paramètres, la file de révision au Centre MODO et les badges après approbation. Messenger est intégré au même build et publié sous `/messenger/` sur le même domaine. Son code comprend l’intro fusée SSPACE et la présence Realtime partagée avec le site principal.

Le build racine exécute `node scripts/copy-site.mjs`, compile Messenger avec TypeScript puis génère `dist/messenger` avec Vite. Il faut donc déployer **le dossier racine complet** de ce ZIP (pas seulement `site/` ni seulement `messenger/`). Les chemins `/`, `/messenger/` et `/jeux-espace/` sont servis par le même déploiement.

## Structure publiée

- Social : `/`
- Messenger : `/messenger/`
- Espace de jeux : `/jeux-espace/`
- Signalisation WebRTC : table Supabase existante `public.call_signals`

## Déploiement Vercel

1. Fais une sauvegarde ou crée une branche de prévisualisation dans GitHub. Ne supprime pas ton ancienne version.
2. Copie le contenu de ce dossier à la racine du dépôt GitHub relié à Vercel (pas le dossier parent `SSPACE-V10-VERCEL` lui-même).
3. Dans Vercel, garde **Root Directory** à la racine du dépôt.
4. Install command : `npm install`
5. Build command : `npm run build`
6. Output directory : `dist`
7. Déploie d'abord en **Preview**, puis teste les pages et les appels avant de promouvoir en production.

## WebRTC — voix et vidéo réelles

- Les appels audio/vidéo déjà présents dans Social sont conservés.
- Messenger possède maintenant la négociation WebRTC : `getUserMedia`, `RTCPeerConnection`, SDP offer/answer, échange des candidats ICE, lecture des pistes distantes, mute, caméra et raccrochage.
- Les deux interfaces utilisent la même table `call_signals` Supabase et la même règle d'amis acceptés.
- Le site doit être servi en HTTPS et les deux personnes doivent autoriser le micro/la caméra.
- STUN Google est configuré par défaut. STUN seul ne traverse pas tous les NAT/réseaux. Pour une fiabilité élevée, configure un serveur TURN avec des identifiants temporaires/éphémères. Ne publie jamais une clé `service_role` ni un secret TURN permanent dans le frontend.

### Migration Supabase

Le fichier `site/supabase/migrations/20261120130000_private_video_audio_call_signals.sql` crée la table `call_signals`, ses index, les règles RLS et active Realtime. Vérifie dans Supabase si cette migration a déjà été appliquée. Si la table n'existe pas, applique cette migration une seule fois dans le bon projet SIKX. Ne réinitialise pas la base et ne relance pas toutes les migrations historiques.

## V16.9 — Profils LIVE, visites et réputation communautaire

- Les profils affichent le nombre de visiteurs uniques, les pouces positifs/négatifs et le pourcentage positif sous la couverture.
- Une visite d’un autre membre crée une notification SSPACE avec un œil; elle est limitée à une notification par visiteur et par profil toutes les 24 heures.
- La notification ouvre le profil du visiteur lorsqu’on la sélectionne.
- Un membre peut voter 👍 ou 👎 sur le contenu d’un profil, avec un seul vote par profil; il peut modifier son vote.
- Migrations : `20261122260000_profile_views_and_reputation.sql` et `20261122261000_profile_views_fk_indexes.sql`. La migration principale et les index ont été appliqués au projet Supabase SIKX.
- Vérifications : fonctions RPC testées dans une transaction annulée, tables/contraintes présentes et JavaScript inline vérifié avec `node --check`. Les essais de bout en bout avec deux comptes restent à faire après déploiement Vercel.

## Liaison de session

Social ouvre `/messenger/` sur la même origine Vercel et transmet la session Supabase avec un nonce temporaire et une vérification stricte de l'origine et de la fenêtre source. Aucun deuxième compte n'est créé.

## Variables optionnelles

Messenger utilise les variables `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` présentes dans `messenger/.env.production`. Pour TURN, `VITE_TURN_URLS`, `VITE_TURN_USERNAME` et `VITE_TURN_CREDENTIAL` sont facultatives. Les credentials TURN exposés au navigateur doivent être temporaires et renouvelables.

## Limites à connaître

Le code et la configuration sont préparés, mais un vrai appel ne peut être certifié sans deux comptes SSPACE distincts, deux appareils/navigateurs, la migration appliquée et un déploiement HTTPS. Le réseau mobile peut nécessiter TURN. Les pièces jointes Messenger, messages vocaux Messenger et notifications push fiables hors ligne ne sont pas ajoutés dans cette livraison.

## Dépannage de la connexion Messenger (V10)

L'écran Messenger propose maintenant quatre méthodes : mot de passe, création de compte, lien de connexion par courriel (sans mot de passe), et récupération du mot de passe. Le bouton Google est disponible dans l'interface, mais Google OAuth doit être activé et configuré dans Supabase (Authentication > Providers > Google) avec les URL de retour autorisées du site. Les liens de courriel et la récupération nécessitent aussi que le service Email de Supabase soit fonctionnel et que l'URL du site soit autorisée dans Authentication > URL Configuration.

Le Messenger utilise la même authentification Supabase et les mêmes comptes SSPACE; il ne crée pas de compte Messenger séparé. Si la connexion par mot de passe échoue, essayer « Connexion par lien courriel ». Si Google affiche un fournisseur non activé, utiliser le lien courriel jusqu'à la configuration OAuth.

## Alex — assistant intégré

- Le bouton Alex est disponible après l'ouverture d'une session SSPACE; il ne modifie pas les formulaires, l'authentification Supabase ni les sessions.
- En mode local, Alex guide vers les fonctions du site et propose des raccourcis (Fil, composer, Messenger, profil, membres, notifications, blogue, paramètres, support, boutique et jeux).
- Pour activer les réponses IA, ajoute dans les variables d'environnement Vercel (Production et Preview si souhaité) : `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `OPENAI_API_KEY` et, facultativement, `ALEX_MODEL` (défaut `gpt-4.1-mini`). Ces variables ne doivent pas être ajoutées au HTML ni commitées.
- `/api/alex` vérifie le jeton de session auprès de Supabase avant d'appeler le fournisseur IA. Alex ne reçoit que les messages de la conversation envoyés par le client; il ne lit pas les messages privés ni les données du profil. Sans clé IA, l'assistant local demeure fonctionnel et le backend renvoie une indisponibilité contrôlée.
- Après ajout des variables, redéploie Vercel. Teste en Preview avant la Production.

## Réintégration LIVE / Fil / Messenger

Les détails et les limites de la nouvelle version sont consignés dans la section « Fusion complète des fonctions demandées » plus bas.

## Fusion complète des fonctions demandées

- **Fil personnalisé** : catégories texte/photos/vidéos/sondages/blogues filtrables; mode compact; paramètres conservés dans le navigateur.
- **SSPACE LIVE** : aperçu caméra/micro, démarrage/fin d'une diffusion, répertoire de directs, rejoindre/quitter, diffusion vidéo et audio par WebRTC, chat isolé par identifiant de LIVE, présence des spectateurs et réactions/messages textuels du chat.
- **Signalisation LIVE** : Supabase Realtime Broadcast + Presence, pas de table de messages créée. Le chat est temporaire et n'est pas sauvegardé en base.
- **Transport vidéo** : WebRTC P2P (un lien par spectateur). Convient à de petits directs; la bande passante du diffuseur augmente avec chaque spectateur. Pour un LIVE public à grande échelle, remplacer par un service SFU/streaming (ex. LiveKit/MediaMTX) et ne pas considérer le maillage comme scalable.
- **TURN** : les serveurs STUN publics sont préconfigurés. Un serveur TURN est configurable dans l'écran LIVE, et ses identifiants sont conservés localement. Un serveur TURN externe est requis pour fiabiliser les réseaux NAT stricts. Ne partage pas de credentials permanents.
- **Messenger bulles** : les conversations peuvent être réduites en bulles flottantes individuelles dans Messenger puis rouvertes sans quitter la messagerie. Les bulles ne sont pas un overlay Android système; elles fonctionnent dans l'application/web.
- **Alex** : endpoints Vercel et Netlify présents. Réponses IA nécessitent les variables serveur décrites plus haut.

### Déploiement Netlify (racine du ZIP)

Le fichier `netlify.toml` racine utilise `npm run build`, publie `dist`, route `/messenger/*` vers Messenger et `/api/alex` vers la fonction Netlify. Configure dans Netlify les variables `SUPABASE_URL`, `SUPABASE_ANON_KEY` et `OPENAI_API_KEY` (optionnel pour l'IA d'Alex). Ne configure jamais une clé `service_role` dans le frontend.

### Tests à effectuer après le déploiement HTTPS

1. Connexion et inscription sur le site principal, puis ouvrir Messenger et confirmer la session partagée.
2. Deux comptes amis acceptés : envoyer/recevoir des messages; réduire chaque conversation en bulle et la restaurer.
3. Appel audio puis vidéo entre deux appareils; vérifier micro/caméra et raccrochage. Vérifier TURN sur réseau mobile/Wi-Fi séparément.
4. Deux appareils : le premier lance LIVE; le second le voit, rejoint, reçoit la vidéo et envoie un message. Tester plusieurs spectateurs, quitter et terminer le direct.
5. Fil : masquer/réafficher les types et basculer Compact; recharger pour confirmer la préférence.
6. Alex : tester aide locale, puis réponse IA après configuration des variables serveur.
7. Espace jeux, notifications, profil et publications existantes.

**État de validation de cette archive :** vérification syntaxique du JavaScript inline du site et intégrité de l'archive; installation des dépendances/compilation TypeScript-Vite non exécutées avec succès dans l'environnement de préparation, car l'accès au registre npm a échoué (DNS `EAI_AGAIN`). La validation fonctionnelle des appels et du LIVE nécessite deux appareils/comptes et un déploiement HTTPS. Les pages d'authentification originales ne sont pas volontairement modifiées.

## V25 — Stockage cloud additionnel désactivé

La migration V24 qui ajoutait les buckets `profile-media`, `album-media`, `user-files` et `user-backups` a été retirée. Ne pas exécuter cette migration. Le coffre IndexedDB local et les optimisations média de V19 sont conservés. Les intégrations Supabase historiques de l’application (authentification, données sociales, Messenger et certains médias) restent présentes pour ne pas casser les fonctions existantes : V25 n’est donc pas une version entièrement hors ligne.

## V27.1 — Salon public SSPACE LIVE, réputation et badge animé

- **Salon public** : une deuxième tuile compacte est placée à côté du bandeau des membres sur l’accueil. Elle ouvre un salon public plein écran, avec historique (100 derniers messages), messages texte, émojis, GIF, présence des membres, profils cliquables, sourdine personnelle, blocage et signalements.
- **Modération LIVE** : les signalements sont présentés dans le Centre MODO aux membres ayant la permission `reports`; les décisions « examiné » et « classé sans suite » sont enregistrées.
- **Votes de profil** : le système `profile_reputation_votes` existant reste la source de vérité (un vote par membre/profil, modifiable). Les boutons ont un effet lumineux vert/rouge et les deux pourcentages sont affichés.
- **Likes d’albums** : la visionneuse affiche maintenant le nombre de J’aime et les noms cliquables des membres qui ont aimé la photo. Les commentaires restent accessibles.
- **Badge vérifié** : mini-crochet arc-en-ciel rotatif avec reflet blanc animé, sans texte à côté du nom. La demande reste soumise à l’approbation MODO; les triggers SQL empêchent le membre de modifier lui-même le badge. Une notification est envoyée après acceptation ou refus.

### Migration Supabase V27.1 obligatoire

Applique une seule fois `site/supabase/migrations/20261123001000_sspace_live_chat_and_verification_notifications.sql` dans le projet Supabase SIKX utilisé par SSPACE. Cette migration crée les tables du salon et des signalements, active Realtime, ajoute les fonctions de consultation MODO et les notifications de décision du badge. Les migrations précédentes `20261122200000_album_photo_likes_comments.sql`, `20261122260000_profile_views_and_reputation.sql` et `20261123000500_sspace_verification_workflow.sql` doivent aussi être appliquées (elles ne sont pas remplacées par V27.1).

Le salon LIVE affichera un message de configuration tant que sa migration n’aura pas été appliquée. Les essais multi-comptes et le build complet doivent être validés sur une Preview HTTPS avant la Production.

## API Express complémentaire — profils et médias

Le service `backend/` ajoute des routes protégées pour consulter les profils SSPACE et téléverser/supprimer les photos et vidéos. Il réutilise les UUID de `public.profiles` et vérifie chaque jeton d'accès avec Supabase Auth; il ne crée ni comptes, ni mots de passe, ni JWT parallèles.

- Configuration serveur : `backend/.env.example` (copier vers `backend/.env`).
- Démarrage local depuis la racine : `npm run api`.
- Migration à appliquer une fois dans Supabase : `supabase/migrations/20261123002000_profile_media_api.sql`.
- URL API frontend : `VITE_PROFILE_API_URL`.
- Client TypeScript réutilisant la session Supabase existante : `messenger/src/lib/profileApi.ts`.

L'API Express doit être déployée comme service Node séparé, avec HTTPS et un volume privé persistant pour `backend/uploads`. Le frontend statique et Messenger restent déployés comme avant. Les profils marqués privés et leurs médias ne sont accessibles qu'à leur propriétaire via cette API. Messenger, les amis et les tables de chat ne sont pas modifiés.


## Procédure finale pour activer l'API Express

1. Déployer le frontend Social/Messenger comme avant (Vercel ou Netlify, commande `npm run build`, sortie `dist`). Ne remplace pas le déploiement actuel avant un test Preview.
2. Déployer le dossier `backend/` comme service Node persistant séparé (pas comme fonction serverless avec disque éphémère). Utiliser Node 18.17+ ou 20+.
3. Dans le service API, installer les dépendances depuis `backend/package.json` (`npm install`) et définir les variables serveur depuis `backend/.env.example` : `DATABASE_URL` (URI PostgreSQL du projet Supabase SIKX avec SSL), `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `FRONTEND_ORIGINS` (origines HTTPS exactes), `UPLOAD_DIR=/chemin/volume-prive/sspace-uploads`, `PORT` fourni par la plateforme.
4. Attacher un volume persistant privé à `UPLOAD_DIR`. Ne jamais exposer ce dossier avec un serveur statique, ni placer un secret dans une variable `VITE_*`.
5. Dans le SQL Editor du projet Supabase SIKX, appliquer une seule fois `supabase/migrations/20261123002000_profile_media_api.sql`. Ne pas recréer `auth.users` ni `public.profiles`.
6. Vérifier `https://adresse-api/health`, puis tester `/api/profil/me` avec un access token SSPACE existant. Tester un upload, une lecture et une suppression avec le propriétaire; vérifier qu'un second compte ne peut pas lire les médias d'un profil privé ni supprimer le média d'autrui.
7. Configurer `VITE_PROFILE_API_URL=https://adresse-api` dans l'environnement de build du frontend Messenger si le client TypeScript est utilisé, puis reconstruire et publier le frontend.

**Ce qui n'est pas fait automatiquement :** aucune migration n'est appliquée à distance, aucun service d'hébergement n'est créé, aucun secret ou mot de passe de base n'est généré et aucun déploiement Vercel/Netlify n'est lancé depuis cette archive. Ces opérations exigent l'accès au projet Supabase et au compte d'hébergement du propriétaire.


## V27.2 — Mood Feed et Mode Détox

- **Mood Feed** : le membre décrit en français le contenu qu’il souhaite retrouver et choisit une durée (1 h, 24 h, 3 jours ou 7 jours). La préférence est liée à son compte Supabase existant et expire automatiquement côté application.
- **Filtres actuellement pris en charge** : période, publications contenant un thème (musique, photo, vidéo, cuisine, sport, art, jeu, lecture), photos, vidéos, audio et publications de membres ayant publié récemment. Le filtre « ma région » est reconnu comme intention mais n’est pas appliqué tant que les profils ne disposent pas d’un champ régional fiable. « Profils actifs » signifie ici membres ayant publié durant la période choisie, pas une mesure de présence en ligne.
- **Mode Détox** : masque les compteurs/boutons de J’aime dans le fil, désactive le chargement automatique et impose une action « Voir plus de publications ». Un rappel de pause s’affiche après 30 minutes d’utilisation continue du mode.
- Les préférences Mood sont privées par RLS et rattachées à `auth.users`; aucune table `users` parallèle, aucun nouvel identifiant et aucune modification de la connexion Supabase. Le Mode Détox est conservé localement sur l’appareil.

### Migration à appliquer

Applique une seule fois `site/supabase/migrations/20261123003000_mood_feed_preferences.sql` dans le projet Supabase utilisé par SSPACE. N’exécute pas de réinitialisation globale. Si la migration n’est pas appliquée, le fil classique reste disponible et l’interface indique que le Mood n’est pas configuré.

### Limites et validation

Le Mood filtre les publications déjà accessibles dans le fil SSPACE; il ne crée pas encore de catalogue Blog indépendant ni de moteur de recommandation IA. Le filtre régional nécessite un champ de région normalisé et une politique de confidentialité dédiée. Les filtres actifs sont appliqués à mesure que les pages sont chargées. Vérifications effectuées sur cette archive : syntaxe de tous les scripts JavaScript inline, syntaxe des fichiers Node du backend, présence de la migration et intégrité ZIP. La compilation complète Vite/TypeScript et les essais Supabase en direct restent à faire dans l’environnement de déploiement, avec les variables et le projet réels.


## V27.3 — Suite de 7 modules communautaires

Appliquer `supabase/migrations/20261123004000_sspace_community_suite.sql` dans le projet Supabase avant le déploiement. Détails et limites : `NOTES-V27.3-7-MODULES-COMMUNAUTAIRES.md`.

## V27.3 — Suite de 7 modules communautaires

Appliquer `supabase/migrations/20261123004000_sspace_community_suite.sql` dans le projet Supabase avant le déploiement. Détails des fonctions et limites : `NOTES-V27.3-7-MODULES-COMMUNAUTAIRES.md`.

## V27.3 — pré-déploiement communautaire + Messenger séparé

- La migration communautaire est `supabase/migrations/20261123004000_sspace_community_suite.sql`. La règle d'adhésion Clan impose maintenant `role='membre'`; le rôle `owner` est attribué uniquement par le trigger lors de la création du Clan.
- Après application, exécuter `supabase/VERIFICATION-V27.3.sql` (lecture seule) pour vérifier les tables, la vue Top 100, le bucket Storage et l'abonnement Realtime du chat des Clans.
- Le chat des Clans utilise Supabase Realtime/Postgres Changes sur `public.sspace_clan_messages`; aucun serveur IRC ou JWT parallèle n'est nécessaire.
- La migration n'est pas exécutée automatiquement par le build du site. Elle doit être appliquée une fois sur le bon projet Supabase, après vérification du projet et sauvegarde. Ne relance pas les migrations historiques en bloc.
- **App 1 — SSPACE Social** reste l'application réseau social. **App 2 — SSPACE Messenger** dispose aussi d'une archive indépendante `SSPACE_MESSENGER_STANDALONE.zip` (PWA installable); elle pointe vers le même projet Supabase et utilise les mêmes comptes. Le dépôt principal conserve également `/messenger/` pour le déploiement combiné.
- Si Messenger est hébergé sur un domaine séparé, les utilisateurs se connectent avec leur compte SSPACE dans Messenger. La session navigateur n'est pas partagée automatiquement entre domaines.
- Les souvenirs anciens ne sont pas reconstitués rétroactivement. Le filtre régional n'utilise pas les informations privées de `profile_private_details`; il reste désactivé tant qu'un champ public de région avec consentement explicite n'est pas ajouté.

### État de validation V27.3

- Vérification syntaxique JavaScript et intégrité ZIP déjà effectuées sur la livraison précédente.
- Une tentative de build Messenger a échoué ici car les dépendances npm ne sont pas installées; la tentative `npm install` a expiré. Le build complet TypeScript/Vite et les tests réels restent donc à faire dans l'environnement de déploiement.
- La base distante n'a pas été modifiée dans cette session : l'accès au projet Supabase doit être connecté avant d'appliquer la migration.

## Livraison consolidée — SSPACE Social + Messenger (App 2)

Le dossier `messenger/` fait partie intégrante du dépôt et est inclus dans l'archive principale. Il ne faut pas le supprimer ni le déplacer hors du projet : le bouton « ↗ Messenger » de SSPACE ouvre `/messenger/` et transmet la session Supabase existante au moyen d'un nonce temporaire vérifié des deux côtés (`postMessage`, même origine). Messenger conserve aussi son interface et son cycle de build propres.

- **Build combiné** : depuis la racine, `npm install`, puis `npm run build`. Le script copie le site social dans `dist/`, compile TypeScript et construit Messenger dans `dist/messenger/` sans effacer le site.
- **Déploiement combiné** : publier le dossier `dist/` avec la configuration racine `netlify.toml` (ou l'équivalent Vercel). Les routes `/messenger/` et `/messenger/*` servent l'application Messenger.
- **Téléchargement/install séparé** : Messenger peut être installé comme PWA depuis son URL `/messenger/` (HTTPS requis). Son code source est également isolé dans `messenger/`; il n'est pas fusionné dans le bundle SSPACE Social.
- **Identité** : les deux applications utilisent le même projet Supabase et les mêmes UUID `auth.users`. Le lien depuis SSPACE transmet une session; en ouverture directe, Messenger demande une connexion avec le compte SSPACE. Aucun compte utilisateur parallèle n'est créé.
- **Archive source** : les fichiers `.env*`, `node_modules/` et `.git/` ne sont pas distribués. Les variables de déploiement doivent être définies dans l'hébergeur; seules les clés publiques Supabase sont utilisables côté navigateur.

Le build complet et les tests réels multi-comptes/appels doivent encore être exécutés dans l'environnement de déploiement avant la production.
