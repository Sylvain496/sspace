# SSPACE V22 — Paramètres regroupés

## Objectif
Regrouper les réglages qui portent sur le même sujet, sans supprimer les options existantes ni modifier les identifiants utilisés par le JavaScript.

## Organisation
- **Apparence et langue** : thème, langue et préférences visuelles/accessibilité.
- **Notifications et sons** : son des messages privés.
- **Profil et compte** : biographie, informations personnelles, courriel, nom d’utilisateur et déconnexion.
- **Confidentialité et sécurité** : statut en ligne, membres bloqués, publications masquées et demande de vérification.

## Conservation et vérifications
- Les identifiants HTML des contrôles existants ont été conservés.
- Aucun identifiant du document n'est dupliqué.
- Les trois scripts JavaScript intégrés passent `node --check`.
- La colonne latérale et les autres fichiers du projet V21 sont conservés; seul `dist/index.html` a été réorganisé et cette note a été ajoutée.
- Le comportement connecté à Supabase et l'interface en production nécessitent encore des tests dans l'environnement déployé.
