# SSPACE V31 — galerie de souvenirs, suggestions et bowling

## Intégrations réalisées
- Messenger reste une application indépendante, avec la même session/identité Supabase que SSPACE.
- Le centre de mémoire permet maintenant de choisir un média dans la galerie de l'utilisateur : `profile_album_photos` ou ses publications `posts`. L'UUID n'est plus saisi manuellement.
- Les photos d'album sont résolues via le bucket `profile-albums`; les publications photo/vidéo sont lues depuis `posts`. Les appels RPC de backstory conservent l'identifiant interne sélectionné et la vérification de propriété côté base.
- `generate_memory_suggestion()` fait maintenant correspondre les mots-clés privés avec les articles publiés de `memory_blog_articles`, les groupes publics de `groups` et les adhésions acceptées dans `group_members`, puis les événements en solution de repli. Les articles associés à un clan ne sont proposés qu'aux membres acceptés de ce clan. L'exécution anonyme est révoquée; `authenticated` conserve EXECUTE.
- Le bowling calcule maintenant le score selon les règles officielles de strike/spare, avec bonus de rolls suivants et troisième boule au dixième frame lorsque requise. Les lancers restent une approximation aléatoire basée sur la puissance; ce n'est pas une simulation physique de quilles.

## Limites encore présentes — à ne pas masquer
- Les scènes de jeu utilisent toujours Canvas 2D en perspective, pas WebGL/Three.js.
- Street Racing et Kart Racing partagent encore le même moteur de course. Les véhicules/circuits et comportements propres au kart restent à développer.
- Le bowling n'a pas encore de vraie physique des quilles (collisions, friction, rotations, animation physique). Seul le calcul de score officiel est intégré.
- Les suggestions blog/clan sont branchées sur les tables présentes, mais la requête de vérification n'a trouvé aucun article ni groupe dans ces tables au moment du contrôle. Les recommandations apparaîtront quand les données seront renseignées.
- Le moteur de mots-clés reste basé sur des règles simples, pas sur un modèle IA.
- Les suggestions restent limitées à une entrée par utilisateur et par semaine.

## Contrôles effectués
- Le schéma réel a été vérifié : `memory_blog_articles`, `groups`, `group_members`, `posts`, `profile_album_photos` existent.
- La fonction SQL a été remplacée sur le projet Supabase `sikxoyylihsigzirewmi`; contrôle effectué : fonction présente, matching blog et groupe détecté, EXECUTE autorisé pour `authenticated` et refusé pour `anon`.
- La galerie utilise la politique d'accès des médias existante et filtre les lignes sur `user_id` du compte courant.
- L'analyse TypeScript locale n'a pas pu valider les types ni le build : `react`, `@supabase/supabase-js`, `lucide-react` et les autres dépendances ne sont pas installées dans ce runtime. Aucun build Vite ni test multi-appareils n'est revendiqué.
