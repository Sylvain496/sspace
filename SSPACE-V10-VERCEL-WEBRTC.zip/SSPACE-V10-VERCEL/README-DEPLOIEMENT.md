# SSPACE V10 — paquet unifié Vercel (Social + Messenger + Jeux)

Ce dépôt conserve l'application sociale SSPACE et ses appels WebRTC existants, et ajoute Messenger sur le même domaine avec de vrais appels audio/vidéo WebRTC. L'Espace de jeux est publié sous `/jeux-espace/`.

## Structure publiée

- Social : `/`
- Messenger : `/messenger/`
- Espace de jeux : `/jeux-espace/`
- Signalisation WebRTC : table Supabase existante `public.call_signals`

## Déploiement Vercel

1. Fais une sauvegarde ou crée une branche de prévisualisation dans GitHub. Ne supprime pas ton ancienne version.
2. Copie le contenu de ce dossier à la racine du dépôt GitHub relié à Vercel (pas le dossier parent `SSPACE-V10-VERCEL` lui-même).
3. Dans Vercel, garde **Root Directory** à la racine du dépôt.
4. Install command : `npm install`
5. Build command : `npm run build`
6. Output directory : `dist`
7. Déploie d'abord en **Preview**, puis teste les pages et les appels avant de promouvoir en production.

## WebRTC — voix et vidéo réelles

- Les appels audio/vidéo déjà présents dans Social sont conservés.
- Messenger possède maintenant la négociation WebRTC : `getUserMedia`, `RTCPeerConnection`, SDP offer/answer, échange des candidats ICE, lecture des pistes distantes, mute, caméra et raccrochage.
- Les deux interfaces utilisent la même table `call_signals` Supabase et la même règle d'amis acceptés.
- Le site doit être servi en HTTPS et les deux personnes doivent autoriser le micro/la caméra.
- STUN Google est configuré par défaut. STUN seul ne traverse pas tous les NAT/réseaux. Pour une fiabilité élevée, configure un serveur TURN avec des identifiants temporaires/éphémères. Ne publie jamais une clé `service_role` ni un secret TURN permanent dans le frontend.

### Migration Supabase

Le fichier `site/supabase/migrations/20261120130000_private_video_audio_call_signals.sql` crée la table `call_signals`, ses index, les règles RLS et active Realtime. Vérifie dans Supabase si cette migration a déjà été appliquée. Si la table n'existe pas, applique cette migration une seule fois dans le bon projet SIKX. Ne réinitialise pas la base et ne relance pas toutes les migrations historiques.

## Liaison de session

Social ouvre `/messenger/` sur la même origine Vercel et transmet la session Supabase avec un nonce temporaire et une vérification stricte de l'origine et de la fenêtre source. Aucun deuxième compte n'est créé.

## Variables optionnelles

Messenger utilise les variables `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` présentes dans `messenger/.env.production`. Pour TURN, `VITE_TURN_URLS`, `VITE_TURN_USERNAME` et `VITE_TURN_CREDENTIAL` sont facultatives. Les credentials TURN exposés au navigateur doivent être temporaires et renouvelables.

## Limites à connaître

Le code et la configuration sont préparés, mais un vrai appel ne peut être certifié sans deux comptes SSPACE distincts, deux appareils/navigateurs, la migration appliquée et un déploiement HTTPS. Le réseau mobile peut nécessiter TURN. Les pièces jointes Messenger, messages vocaux Messenger et notifications push fiables hors ligne ne sont pas ajoutés dans cette livraison.
